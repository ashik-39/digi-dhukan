package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.scanner.CameraBarcodeScannerDialog
import com.example.ui.MainViewModel
import com.example.ui.components.AddCustomerDueDialog
import com.example.ui.components.AddEditProductDialog
import com.example.ui.components.AddEditSupplierMemoDialog
import com.example.ui.components.AppLockScreen
import com.example.ui.components.AppUpdateDialog
import com.example.ui.components.BarcodeGeneratorDialog
import com.example.ui.components.CustomerDueDetailDialog
import com.example.ui.components.FullScreenImageViewerDialog
import com.example.ui.components.GoogleDriveBackupDialog
import com.example.ui.components.NotificationCenterDialog
import com.example.ui.components.PinSecurityDialog
import com.example.ui.components.ProfileSettingsDialog
import com.example.ui.components.ReceiptDialog
import com.example.ui.components.ScannedProductActionDialog
import com.example.ui.components.TopStoreHeader
import com.example.ui.screens.CartModal
import com.example.ui.screens.DueBookTab
import com.example.ui.screens.InventoryTab
import com.example.ui.screens.MemoSlipsTab
import com.example.ui.screens.SalesReportTab
import com.example.ui.theme.BkashPink
import com.example.ui.theme.MyApplicationTheme
import com.example.util.AppStrings

enum class MainTab {
    INVENTORY,
    DUE_BOOK,
    MEMO_SLIPS,
    SALES_REPORT
}

class MainActivity : androidx.fragment.app.FragmentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsState()
            MyApplicationTheme(darkTheme = isDarkMode) {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        viewModel.onAppBackgrounded()
    }

    override fun onStart() {
        super.onStart()
        viewModel.onAppForegrounded()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(MainTab.INVENTORY) }

    val storeProfile by viewModel.storeProfile.collectAsState()
    val userRole by viewModel.userRole.collectAsState()
    val cart by viewModel.cart.collectAsState()
    val isEnglish by viewModel.isEnglish.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val isLiveChartEnabled by viewModel.isLiveChartEnabled.collectAsState()

    val isAppLocked by viewModel.isAppLocked.collectAsState()
    val isMasterLockEnabled by viewModel.isAppLockMasterEnabled.collectAsState()
    val launchLockPriority by viewModel.launchLockPriority.collectAsState()

    // Dialog state collections
    val isScannerOpen by viewModel.isScannerOpen.collectAsState()
    val isCartOpen by viewModel.isCartOpen.collectAsState()
    val isAddProductOpen by viewModel.isAddProductOpen.collectAsState()
    val isAddDueOpen by viewModel.isAddDueOpen.collectAsState()
    val isAddEditMemoOpen by viewModel.isAddEditMemoOpen.collectAsState()
    val isProfileOpen by viewModel.isProfileOpen.collectAsState()
    val isPinSettingsOpen by viewModel.isPinSettingsOpen.collectAsState()
    val isBarcodeGenOpen by viewModel.isBarcodeGenOpen.collectAsState()
    val isReceiptOpen by viewModel.isReceiptOpen.collectAsState()
    val isScanActionDialogOpen by viewModel.isScanActionDialogOpen.collectAsState()
    val scannedProductForAction by viewModel.scannedProductForAction.collectAsState()
    val isDueDetailOpen by viewModel.isDueDetailOpen.collectAsState()
    val selectedDueForDetail by viewModel.selectedDueForDetail.collectAsState()
    val editingProduct by viewModel.editingProduct.collectAsState()
    val editingMemo by viewModel.editingMemo.collectAsState()
    val scannedBarcodeForProduct by viewModel.scannedBarcodeForProduct.collectAsState()
    val lastGeneratedReceipt by viewModel.lastGeneratedReceipt.collectAsState()
    val fullScreenImageUri by viewModel.fullScreenImageUri.collectAsState()

    // Feature Dialog States
    val isNotificationCenterOpen by viewModel.isNotificationCenterOpen.collectAsState()
    val unreadNotifCount by viewModel.unreadNotificationCount.collectAsState()
    val isUpdateDialogOpen by viewModel.isUpdateDialogOpen.collectAsState()
    val appUpdateInfo by viewModel.appUpdateInfo.collectAsState()
    val isGoogleDriveBackupOpen by viewModel.isGoogleDriveBackupOpen.collectAsState()

    val isCloudConnected by viewModel.isCloudConnected.collectAsState()
    val isCloudSyncing by viewModel.isCloudSyncing.collectAsState()
    val isLiveScanMode by viewModel.isLiveScanMode.collectAsState()
    val scanHistory by viewModel.scanHistory.collectAsState()

    val isBiometricEnabled by viewModel.isBiometricEnabled.collectAsState()
    val autoLockMinutes by viewModel.autoLockMinutes.collectAsState()
    val autoLockType by viewModel.autoLockType.collectAsState()
    val isRefreshing by viewModel.isRefreshing.collectAsState()

    val isBiometricAvailable = remember(context) { com.example.util.BiometricAuthHelper.isBiometricAvailable(context) }

    // Push notification permission request launcher for Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { /* result handled */ }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // Handle back button if any sub-dialog or tab is active
    BackHandler(
        enabled = fullScreenImageUri != null || isScannerOpen || isCartOpen ||
                isScanActionDialogOpen || isDueDetailOpen || isAddProductOpen ||
                isAddDueOpen || isAddEditMemoOpen || isProfileOpen ||
                isPinSettingsOpen || isBarcodeGenOpen || isReceiptOpen ||
                isNotificationCenterOpen || isUpdateDialogOpen || isGoogleDriveBackupOpen ||
                selectedTab != MainTab.INVENTORY
    ) {
        when {
            fullScreenImageUri != null -> viewModel.fullScreenImageUri.value = null
            isNotificationCenterOpen -> viewModel.isNotificationCenterOpen.value = false
            isUpdateDialogOpen -> viewModel.isUpdateDialogOpen.value = false
            isGoogleDriveBackupOpen -> viewModel.isGoogleDriveBackupOpen.value = false
            isDueDetailOpen -> viewModel.isDueDetailOpen.value = false
            isScanActionDialogOpen -> viewModel.isScanActionDialogOpen.value = false
            isScannerOpen -> viewModel.isScannerOpen.value = false
            isCartOpen -> viewModel.isCartOpen.value = false
            isAddProductOpen -> viewModel.isAddProductOpen.value = false
            isAddDueOpen -> viewModel.isAddDueOpen.value = false
            isAddEditMemoOpen -> {
                viewModel.isAddEditMemoOpen.value = false
                viewModel.editingMemo.value = null
            }
            isProfileOpen -> viewModel.isProfileOpen.value = false
            isPinSettingsOpen -> viewModel.isPinSettingsOpen.value = false
            isBarcodeGenOpen -> viewModel.isBarcodeGenOpen.value = false
            isReceiptOpen -> viewModel.isReceiptOpen.value = false
            selectedTab != MainTab.INVENTORY -> selectedTab = MainTab.INVENTORY
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                TopStoreHeader(
                    storeProfile = storeProfile,
                    userRole = userRole,
                    cartItemCount = cart.sumOf { it.quantity },
                    notificationCount = unreadNotifCount,
                    isLiveChartEnabled = isLiveChartEnabled,
                    isDarkMode = isDarkMode,
                    isEnglish = isEnglish,
                    isCloudConnected = isCloudConnected,
                    isCloudSyncing = isCloudSyncing,
                    isRefreshing = isRefreshing,
                    onOpenCart = { viewModel.isCartOpen.value = true },
                    onOpenNotifications = { viewModel.isNotificationCenterOpen.value = true },
                    onOpenProfile = { viewModel.isProfileOpen.value = true },
                    onOpenBarcodeGen = { viewModel.isBarcodeGenOpen.value = true },
                    onOpenPinSettings = { viewModel.isPinSettingsOpen.value = true },
                    onCheckForUpdates = { viewModel.checkForAppUpdates(isManualCheck = true) },
                    onOpenGoogleDriveBackup = { viewModel.isGoogleDriveBackupOpen.value = true },
                    onToggleLiveChart = { viewModel.toggleLiveChart() },
                    onToggleDarkMode = { viewModel.toggleDarkMode() },
                    onToggleLanguage = { viewModel.toggleLanguage() },
                    onLockApp = { viewModel.lockAppSession() },
                    onRefreshApp = { viewModel.refreshAppData() },
                    onSyncCloud = { viewModel.syncAllDataToCloud() },
                    onOfflineBackup = { viewModel.exportOfflineBackupJson(context) }
                )
            },
            bottomBar = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Transparent)
                ) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 8.dp,
                        modifier = Modifier.height(68.dp)
                    ) {
                        // 1. Inventory Tab
                        NavigationBarItem(
                            selected = selectedTab == MainTab.INVENTORY,
                            onClick = { selectedTab = MainTab.INVENTORY },
                            icon = { Icon(Icons.Default.Inventory, contentDescription = AppStrings.tabInventory(isEnglish)) },
                            label = { Text(AppStrings.tabInventory(isEnglish), fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BkashPink,
                                selectedTextColor = BkashPink,
                                indicatorColor = BkashPink.copy(alpha = 0.15f)
                            )
                        )

                        // 2. Due Book Tab
                        NavigationBarItem(
                            selected = selectedTab == MainTab.DUE_BOOK,
                            onClick = { selectedTab = MainTab.DUE_BOOK },
                            icon = { Icon(Icons.Default.Book, contentDescription = AppStrings.tabDueBook(isEnglish)) },
                            label = { Text(AppStrings.tabDueBook(isEnglish), fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BkashPink,
                                selectedTextColor = BkashPink,
                                indicatorColor = BkashPink.copy(alpha = 0.15f)
                            )
                        )

                        // Center spacer for Floating Action Button
                        Spacer(modifier = Modifier.weight(1f))

                        // 3. Wholesale Memo Slips Tab
                        NavigationBarItem(
                            selected = selectedTab == MainTab.MEMO_SLIPS,
                            onClick = { selectedTab = MainTab.MEMO_SLIPS },
                            icon = { Icon(Icons.Default.ReceiptLong, contentDescription = AppStrings.tabMemoSlips(isEnglish)) },
                            label = { Text(AppStrings.tabMemoSlips(isEnglish), fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BkashPink,
                                selectedTextColor = BkashPink,
                                indicatorColor = BkashPink.copy(alpha = 0.15f)
                            )
                        )

                        // 4. Sales Report Tab
                        NavigationBarItem(
                            selected = selectedTab == MainTab.SALES_REPORT,
                            onClick = { selectedTab = MainTab.SALES_REPORT },
                            icon = { Icon(Icons.Default.Assessment, contentDescription = AppStrings.tabSalesReport(isEnglish)) },
                            label = { Text(AppStrings.tabSalesReport(isEnglish), fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BkashPink,
                                selectedTextColor = BkashPink,
                                indicatorColor = BkashPink.copy(alpha = 0.15f)
                            )
                        )
                    }

                    // Floating Center Scan Button
                    FloatingActionButton(
                        onClick = { viewModel.isScannerOpen.value = true },
                        containerColor = BkashPink,
                        contentColor = Color.White,
                        shape = CircleShape,
                        elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 6.dp),
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .offset(y = (-20).dp)
                            .size(56.dp)
                            .border(3.dp, MaterialTheme.colorScheme.surface, CircleShape)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = AppStrings.scan(isEnglish),
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = AppStrings.scan(isEnglish),
                                fontSize = 8.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }
        ) { paddingValues ->
            PullToRefreshBox(
                isRefreshing = isRefreshing,
                onRefresh = { viewModel.refreshAppData() },
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                when (selectedTab) {
                    MainTab.INVENTORY -> InventoryTab(
                        viewModel = viewModel,
                        isDarkMode = isDarkMode,
                        isEnglish = isEnglish,
                        onOpenScanner = { viewModel.isScannerOpen.value = true },
                        onOpenAddProduct = { viewModel.isAddProductOpen.value = true }
                    )
                    MainTab.DUE_BOOK -> DueBookTab(
                        viewModel = viewModel,
                        isDarkMode = isDarkMode,
                        isEnglish = isEnglish,
                        onOpenAddDue = { viewModel.isAddDueOpen.value = true }
                    )
                    MainTab.MEMO_SLIPS -> MemoSlipsTab(
                        viewModel = viewModel,
                        isDarkMode = isDarkMode,
                        isEnglish = isEnglish,
                        onOpenAddMemo = {
                            viewModel.editingMemo.value = null
                            viewModel.isAddEditMemoOpen.value = true
                        },
                        onOpenEditMemo = { memo ->
                            viewModel.editingMemo.value = memo
                            viewModel.isAddEditMemoOpen.value = true
                        }
                    )
                    MainTab.SALES_REPORT -> SalesReportTab(
                        viewModel = viewModel,
                        isDarkMode = isDarkMode,
                        isEnglish = isEnglish
                    )
                }
            }
        }

        // REQUIREMENT 9: PASSWORD LOCK SCREEN WITH LAUNCH PRIORITY & BIOMETRIC
        AppLockScreen(
            isLocked = isAppLocked,
            isMasterLockEnabled = isMasterLockEnabled,
            isEnglish = isEnglish,
            shopName = storeProfile.shopName,
            securityQuestion = storeProfile.securityQuestion,
            isBiometricAvailable = isBiometricAvailable,
            isBiometricEnabled = isBiometricEnabled,
            launchLockPriority = launchLockPriority,
            onBiometricRequested = {
                val act = context as? androidx.fragment.app.FragmentActivity
                if (act != null) {
                    com.example.util.BiometricAuthHelper.showBiometricPrompt(
                        activity = act,
                        isEnglish = isEnglish,
                        onSuccess = { viewModel.unlockWithBiometric() },
                        onError = { /* fallback to custom in-app PIN keypad */ }
                    )
                }
            },
            onVerifyPin = { pin -> viewModel.unlockApp(pin) },
            onVerifySecurityAnswer = { ans -> viewModel.verifySecurityAnswer(ans) },
            onResetPin = { newPin -> viewModel.resetPin(newPin) },
            onUnlocked = { /* unlocked */ }
        )
    }

    // --- DIALOGS ---

    // 1. Camera Barcode Scanner
    CameraBarcodeScannerDialog(
        isOpen = isScannerOpen,
        isEnglish = isEnglish,
        continuousScan = isLiveScanMode,
        scanHistory = scanHistory,
        onDismiss = { viewModel.isScannerOpen.value = false },
        onBarcodeScanned = { barcode ->
            viewModel.handleScannedBarcode(barcode, keepScannerOpenIfLive = true)
        },
        onClearHistory = { viewModel.clearScanHistory() }
    )

    // 1.1 Scanned Product Action Dialog
    ScannedProductActionDialog(
        isOpen = isScanActionDialogOpen,
        product = scannedProductForAction,
        userRole = userRole,
        isDarkMode = isDarkMode,
        isEnglish = isEnglish,
        onDismiss = { viewModel.isScanActionDialogOpen.value = false },
        onOpenFullScreen = { uri ->
            viewModel.fullScreenImageUri.value = uri
        },
        onAddToCart = { product, qty ->
            viewModel.addToCartWithQty(product, qty)
        },
        onDirectSell = { product, qty, phone ->
            viewModel.directQuickSell(product, qty, phone)
        },
        onAddStock = { productId, amount ->
            viewModel.addStockToProduct(productId, amount)
        },
        onEditProduct = { product ->
            viewModel.editingProduct.value = product
            viewModel.isAddProductOpen.value = true
        },
        onScanNextItem = {
            viewModel.resumeLiveScannerForNextItem()
        }
    )

    // 1.2 Full Screen Image Viewer Dialog
    FullScreenImageViewerDialog(
        imageUri = fullScreenImageUri,
        onDismiss = { viewModel.fullScreenImageUri.value = null }
    )

    // 2. Customer Due Detailed Timeline & +/- Adjustment Dialog
    CustomerDueDetailDialog(
        isOpen = isDueDetailOpen,
        due = selectedDueForDetail,
        isDarkMode = isDarkMode,
        isEnglish = isEnglish,
        onDismiss = { viewModel.isDueDetailOpen.value = false },
        onAdjustDue = { due, amount, note, isPayment ->
            viewModel.adjustCustomerDue(due, if (isPayment) -amount else amount, note)
        },
        onAddNote = { due, noteItem ->
            viewModel.adjustCustomerDue(due, 0.0, noteItem)
        },
        onUpdateCustomerInfo = { due, name, phone, amount, note ->
            viewModel.updateCustomerDueDetails(due.id, name, phone, amount, note)
        },
        onSettleFull = { due ->
            viewModel.settleFullDue(due)
        }
    )

    // 3. Cart & Billing Modal
    CartModal(
        viewModel = viewModel,
        isOpen = isCartOpen,
        isDarkMode = isDarkMode,
        isEnglish = isEnglish,
        onDismiss = { viewModel.isCartOpen.value = false }
    )

    // 4. Receipt Dialog
    ReceiptDialog(
        receipt = lastGeneratedReceipt,
        isOpen = isReceiptOpen,
        isDarkMode = isDarkMode,
        isEnglish = isEnglish,
        onDismiss = { viewModel.isReceiptOpen.value = false }
    )

    // 5. Custom Barcode Generator Dialog
    BarcodeGeneratorDialog(
        isOpen = isBarcodeGenOpen,
        shopName = storeProfile.shopName,
        isDarkMode = isDarkMode,
        isEnglish = isEnglish,
        onDismiss = { viewModel.isBarcodeGenOpen.value = false }
    )

    // 6. Add / Edit Product Dialog
    AddEditProductDialog(
        isOpen = isAddProductOpen,
        productToEdit = editingProduct,
        prefilledBarcode = scannedBarcodeForProduct,
        userRole = userRole,
        isDarkMode = isDarkMode,
        isEnglish = isEnglish,
        onDismiss = {
            viewModel.isAddProductOpen.value = false
            viewModel.editingProduct.value = null
            viewModel.scannedBarcodeForProduct.value = ""
        },
        onScanRequested = {
            viewModel.isScannerOpen.value = true
        },
        onSave = { product ->
            viewModel.saveProduct(product)
        }
    )

    // 7. Add Customer Due Dialog
    AddCustomerDueDialog(
        isOpen = isAddDueOpen,
        isDarkMode = isDarkMode,
        isEnglish = isEnglish,
        onDismiss = { viewModel.isAddDueOpen.value = false },
        onSave = { name, phone, amount, note ->
            viewModel.addDue(name, phone, amount, note)
        }
    )

    // 8. Add / Edit Supplier Memo Dialog
    AddEditSupplierMemoDialog(
        isOpen = isAddEditMemoOpen,
        memoToEdit = editingMemo,
        isDarkMode = isDarkMode,
        isEnglish = isEnglish,
        onDismiss = {
            viewModel.isAddEditMemoOpen.value = false
            viewModel.editingMemo.value = null
        },
        onSave = { id, supplier, memoNo, amount, photoUri, note, memoDate ->
            viewModel.saveSupplierMemo(id, supplier, memoNo, amount, photoUri = photoUri, note = note, manualDate = memoDate)
        }
    )

    // 9. Profile & Store Settings Dialog
    ProfileSettingsDialog(
        isOpen = isProfileOpen,
        currentProfile = storeProfile,
        isDarkMode = isDarkMode,
        isEnglish = isEnglish,
        onDismiss = { viewModel.isProfileOpen.value = false },
        onSave = { newProfile ->
            viewModel.updateStoreProfile(newProfile)
        }
    )

    // 10. PIN Security, Master Toggle & Configurable Auto-Lock Dialog
    PinSecurityDialog(
        isOpen = isPinSettingsOpen,
        currentRole = userRole,
        isDarkMode = isDarkMode,
        isEnglish = isEnglish,
        isMasterLockEnabled = isMasterLockEnabled,
        currentQuestion = storeProfile.securityQuestion,
        currentAnswer = storeProfile.securityAnswer,
        isBiometricAvailable = isBiometricAvailable,
        isBiometricEnabled = isBiometricEnabled,
        currentAutoLockMinutes = autoLockMinutes,
        currentAutoLockType = autoLockType,
        currentLaunchPriority = launchLockPriority,
        onDismiss = { viewModel.isPinSettingsOpen.value = false },
        onChangePin = { oldPin, newPin ->
            if (viewModel.verifyPin(oldPin) && newPin.length == 4) {
                viewModel.updatePin(newPin)
                true
            } else false
        },
        onSaveSecuritySettings = { newPin, question, answer, masterLockEnabled, biometricEnabled, autoLockTime, lockType, launchPriority ->
            viewModel.updateSecuritySettings(newPin, question, answer, masterLockEnabled, biometricEnabled, autoLockTime, lockType, launchPriority)
        }
    )

    // REQUIREMENT 10: Notification Center Dialog
    NotificationCenterDialog(
        viewModel = viewModel,
        isOpen = isNotificationCenterOpen,
        isDarkMode = isDarkMode,
        isEnglish = isEnglish,
        onDismiss = { viewModel.isNotificationCenterOpen.value = false }
    )

    // REQUIREMENT 2: In-App Update Dialog
    AppUpdateDialog(
        isOpen = isUpdateDialogOpen,
        updateInfo = appUpdateInfo,
        isDarkMode = isDarkMode,
        isEnglish = isEnglish,
        onDismiss = { viewModel.isUpdateDialogOpen.value = false }
    )

    // REQUIREMENT 3: Google Drive & Isolated Cloud Backup Dialog
    GoogleDriveBackupDialog(
        viewModel = viewModel,
        isOpen = isGoogleDriveBackupOpen,
        isDarkMode = isDarkMode,
        isEnglish = isEnglish,
        onDismiss = { viewModel.isGoogleDriveBackupOpen.value = false }
    )
}
