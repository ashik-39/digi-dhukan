package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val barcode: String,
    val name: String,
    val buyPrice: Double = 0.0,
    val sellPrice: Double = 0.0,
    val stock: Int = 0,
    val category: String = "মুদি (Grocery)",
    val imageUri: String = "",
    val lastAddedQty: Int = 0
)

@Entity(tableName = "customer_dues")
data class CustomerDue(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerName: String,
    val phone: String,
    val amount: Double,
    val note: String = "",
    val date: String,
    val historyNotes: String = ""
) {
    fun getHistoryList(): List<String> {
        if (historyNotes.isBlank()) {
            return if (note.isNotBlank()) listOf("বাকি তৈরি: $note ($date)") else emptyList()
        }
        return historyNotes.split("||").filter { it.isNotBlank() }
    }
}

@Entity(tableName = "supplier_memos")
data class SupplierMemo(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val supplierName: String,
    val memoNo: String,
    val amount: Double,
    val date: String,
    val photoUri: String = "",
    val note: String = ""
)

@Entity(tableName = "sale_transactions")
data class SaleTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val totalAmount: Double,
    val totalProfit: Double,
    val itemsSummary: String,
    val customerPhone: String = "",
    val dateFormatted: String
)

@Entity(tableName = "store_notifications")
data class StoreNotification(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val type: String = "ALERT", // "LOW_STOCK", "SALE", "PURCHASE", "SETTLED", "EXPORT", "SYSTEM"
    val dateFormatted: String = "",
    val isRead: Boolean = false
)

data class CartItem(
    val product: Product,
    var quantity: Int
) {
    val totalCost: Double
        get() = product.sellPrice * quantity

    val totalProfit: Double
        get() = (product.sellPrice - product.buyPrice) * quantity
}

data class StoreProfile(
    val shopName: String = "Digi Dhukan",
    val address: String = "দোকানের ঠিকানা লিখুন",
    val bossName: String = "দোকান মালিক",
    val phone: String = "01700000000",
    val email: String = "",
    val userUid: String = "default_owner",
    val pin: String = "1234",
    val securityQuestion: String = "What is your pet's name?",
    val securityAnswer: String = "admin",
    val isAppLockMasterEnabled: Boolean = true,
    val launchLockPriority: String = "FINGERPRINT_FIRST" // "FINGERPRINT_FIRST" or "PIN_FIRST"
)

data class AppUpdateInfo(
    val isUpdateAvailable: Boolean = false,
    val latestVersionCode: Int = 1,
    val latestVersionName: String = "1.0",
    val releaseNotes: String = "",
    val downloadUrl: String = "https://play.google.com/store/apps/details?id=com.aistudio.digidhukan.app",
    val isMandatory: Boolean = false
)

data class OfflineBackupData(
    val exportDate: String,
    val profile: StoreProfile,
    val products: List<Product>,
    val dues: List<CustomerDue>,
    val memos: List<SupplierMemo>,
    val transactions: List<SaleTransaction>
)
