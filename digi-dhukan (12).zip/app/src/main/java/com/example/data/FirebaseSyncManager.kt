package com.example.data

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object FirebaseSyncManager {
    private const val TAG = "FirebaseSyncManager"
    private var database: FirebaseDatabase? = null
    private var auth: FirebaseAuth? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    // User authentication state
    private val _currentUser = MutableStateFlow<FirebaseUser?>(null)
    val currentUser: StateFlow<FirebaseUser?> = _currentUser.asStateFlow()

    private var activeUid: String = "default_owner"

    private val _isCloudConnected = MutableStateFlow(false)
    val isCloudConnected: StateFlow<Boolean> = _isCloudConnected.asStateFlow()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _lastSyncTime = MutableStateFlow("")
    val lastSyncTime: StateFlow<String> = _lastSyncTime.asStateFlow()

    // Remote In-App Update state
    private val _appUpdateInfo = MutableStateFlow(AppUpdateInfo())
    val appUpdateInfo: StateFlow<AppUpdateInfo> = _appUpdateInfo.asStateFlow()

    private var isInitialized = false

    private fun getRootNode(): String {
        return "users/$activeUid"
    }

    fun init(userUid: String? = null) {
        if (userUid != null && userUid.isNotBlank()) {
            activeUid = userUid.replace(".", "_").replace("#", "_").replace("$", "_").replace("[", "_").replace("]", "_")
        }
        if (isInitialized) return
        try {
            auth = try { FirebaseAuth.getInstance() } catch (e: Exception) { null }
            _currentUser.value = auth?.currentUser

            val db = try {
                FirebaseDatabase.getInstance("https://digi-dhukan-default-rtdb.firebaseio.com")
            } catch (e: Exception) {
                try {
                    FirebaseDatabase.getInstance("https://digi-dhukan.firebaseio.com")
                } catch (e2: Exception) {
                    FirebaseDatabase.getInstance()
                }
            }
            try {
                db.setPersistenceEnabled(true)
            } catch (e: Exception) {
                // Persistence can only be enabled once
            }
            database = db

            // Listen to connectivity
            val connectedRef = db.getReference(".info/connected")
            connectedRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val connected = snapshot.getValue(Boolean::class.java) ?: false
                    _isCloudConnected.value = connected
                    Log.d(TAG, "Firebase connection status: $connected")
                }
                override fun onCancelled(error: DatabaseError) {
                    Log.w(TAG, "Connection listener cancelled: ${error.message}")
                }
            })

            // Listen for In-App Updates in Firebase
            listenForAppUpdates()

            isInitialized = true
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing Firebase Realtime Database: ${e.message}", e)
        }
    }

    fun switchUser(uid: String, email: String? = null) {
        activeUid = if (uid.isNotBlank()) uid.replace(".", "_").replace("#", "_").replace("$", "_").replace("[", "_").replace("]", "_") else "default_owner"
        _currentUser.value = auth?.currentUser
    }

    private fun listenForAppUpdates() {
        val db = database ?: return
        db.getReference("system/app_update").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    try {
                        val latestCode = (snapshot.child("latest_version_code").value as? Number)?.toInt() ?: 1
                        val latestName = snapshot.child("latest_version_name").getValue(String::class.java) ?: "1.0"
                        val notes = snapshot.child("release_notes").getValue(String::class.java) ?: ""
                        val url = snapshot.child("download_url").getValue(String::class.java) ?: "https://play.google.com/store/apps/details?id=com.aistudio.digidhukan.app"
                        val isMandatory = snapshot.child("is_mandatory").getValue(Boolean::class.java) ?: false

                        // Check if remote version > current app version (code 1)
                        val isAvailable = latestCode > 1
                        _appUpdateInfo.value = AppUpdateInfo(
                            isUpdateAvailable = isAvailable,
                            latestVersionCode = latestCode,
                            latestVersionName = latestName,
                            releaseNotes = notes,
                            downloadUrl = url,
                            isMandatory = isMandatory
                        )
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to parse update info: ${e.message}")
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    // Push local changes to Firebase Realtime Database (Isolated under users/$activeUid)
    fun syncProduct(product: Product) {
        init()
        try {
            val root = getRootNode()
            val ref = database?.getReference("$root/products/${product.id}")
            val data = mapOf(
                "id" to product.id,
                "barcode" to product.barcode,
                "name" to product.name,
                "buyPrice" to product.buyPrice,
                "sellPrice" to product.sellPrice,
                "stock" to product.stock,
                "category" to product.category,
                "imageUri" to product.imageUri,
                "lastAddedQty" to product.lastAddedQty
            )
            ref?.setValue(data)
            updateSyncTimestamp()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to sync product ${product.id}: ${e.message}")
        }
    }

    fun deleteProduct(productId: Long) {
        init()
        try {
            val root = getRootNode()
            database?.getReference("$root/products/$productId")?.removeValue()
            updateSyncTimestamp()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to delete product $productId: ${e.message}")
        }
    }

    fun updateProductStock(productId: Long, newStock: Int, lastAddedQty: Int = 0) {
        init()
        try {
            val root = getRootNode()
            val map = mutableMapOf<String, Any>("stock" to newStock)
            if (lastAddedQty > 0) {
                map["lastAddedQty"] = lastAddedQty
            }
            database?.getReference("$root/products/$productId")?.updateChildren(map)
            updateSyncTimestamp()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update stock: ${e.message}")
        }
    }

    fun syncCustomerDue(due: CustomerDue) {
        init()
        try {
            val root = getRootNode()
            val ref = database?.getReference("$root/dues/${due.id}")
            val data = mapOf(
                "id" to due.id,
                "customerName" to due.customerName,
                "phone" to due.phone,
                "amount" to due.amount,
                "note" to due.note,
                "date" to due.date,
                "historyNotes" to due.historyNotes
            )
            ref?.setValue(data)
            updateSyncTimestamp()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to sync customer due: ${e.message}")
        }
    }

    fun deleteCustomerDue(dueId: Long) {
        init()
        try {
            val root = getRootNode()
            database?.getReference("$root/dues/$dueId")?.removeValue()
            updateSyncTimestamp()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to delete due $dueId: ${e.message}")
        }
    }

    fun syncSupplierMemo(memo: SupplierMemo) {
        init()
        try {
            val root = getRootNode()
            val ref = database?.getReference("$root/memos/${memo.id}")
            val data = mapOf(
                "id" to memo.id,
                "supplierName" to memo.supplierName,
                "memoNo" to memo.memoNo,
                "amount" to memo.amount,
                "date" to memo.date,
                "photoUri" to memo.photoUri,
                "note" to memo.note
            )
            ref?.setValue(data)
            updateSyncTimestamp()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to sync memo: ${e.message}")
        }
    }

    fun deleteSupplierMemo(memoId: Long) {
        init()
        try {
            val root = getRootNode()
            database?.getReference("$root/memos/$memoId")?.removeValue()
            updateSyncTimestamp()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to delete memo $memoId: ${e.message}")
        }
    }

    fun syncSaleTransaction(txn: SaleTransaction) {
        init()
        try {
            val root = getRootNode()
            val ref = database?.getReference("$root/transactions/${txn.id}")
            val data = mapOf(
                "id" to txn.id,
                "timestamp" to txn.timestamp,
                "totalAmount" to txn.totalAmount,
                "totalProfit" to txn.totalProfit,
                "itemsSummary" to txn.itemsSummary,
                "customerPhone" to txn.customerPhone,
                "dateFormatted" to txn.dateFormatted
            )
            ref?.setValue(data)
            updateSyncTimestamp()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to sync transaction: ${e.message}")
        }
    }

    fun deleteSaleTransaction(txnId: Long) {
        init()
        try {
            val root = getRootNode()
            database?.getReference("$root/transactions/$txnId")?.removeValue()
            updateSyncTimestamp()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to delete transaction $txnId: ${e.message}")
        }
    }

    fun syncStoreProfile(profile: StoreProfile) {
        init()
        try {
            val root = getRootNode()
            val ref = database?.getReference("$root/profile")
            val data = mapOf(
                "shopName" to profile.shopName,
                "address" to profile.address,
                "bossName" to profile.bossName,
                "phone" to profile.phone,
                "email" to profile.email,
                "userUid" to profile.userUid,
                "pin" to profile.pin,
                "securityQuestion" to profile.securityQuestion,
                "securityAnswer" to profile.securityAnswer,
                "isAppLockMasterEnabled" to profile.isAppLockMasterEnabled,
                "launchLockPriority" to profile.launchLockPriority
            )
            ref?.setValue(data)
            updateSyncTimestamp()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to sync profile: ${e.message}")
        }
    }

    // Two-way listeners for real-time changes across devices
    fun startRealtimeSync(
        onProductsUpdated: suspend (List<Product>) -> Unit,
        onDuesUpdated: suspend (List<CustomerDue>) -> Unit,
        onMemosUpdated: suspend (List<SupplierMemo>) -> Unit,
        onTransactionsUpdated: suspend (List<SaleTransaction>) -> Unit,
        onProfileUpdated: suspend (StoreProfile) -> Unit
    ) {
        init()
        val db = database ?: return
        val root = getRootNode()

        // 1. Products Listener
        db.getReference("$root/products").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<Product>()
                for (child in snapshot.children) {
                    try {
                        val id = (child.child("id").value as? Number)?.toLong() ?: child.key?.toLongOrNull() ?: continue
                        val barcode = child.child("barcode").getValue(String::class.java) ?: ""
                        val name = child.child("name").getValue(String::class.java) ?: ""
                        val buyPrice = (child.child("buyPrice").value as? Number)?.toDouble() ?: 0.0
                        val sellPrice = (child.child("sellPrice").value as? Number)?.toDouble() ?: 0.0
                        val stock = (child.child("stock").value as? Number)?.toInt() ?: 0
                        val category = child.child("category").getValue(String::class.java) ?: "মুদি (Grocery)"
                        val imageUri = child.child("imageUri").getValue(String::class.java) ?: ""
                        val lastAdded = (child.child("lastAddedQty").value as? Number)?.toInt() ?: 0
                        list.add(Product(id = id, barcode = barcode, name = name, buyPrice = buyPrice, sellPrice = sellPrice, stock = stock, category = category, imageUri = imageUri, lastAddedQty = lastAdded))
                    } catch (e: Exception) {
                        Log.e(TAG, "Error parsing product: ${e.message}")
                    }
                }
                if (list.isNotEmpty()) {
                    scope.launch { onProductsUpdated(list) }
                    updateSyncTimestamp()
                }
            }
            override fun onCancelled(error: DatabaseError) {
                Log.w(TAG, "Products listener cancelled: ${error.message}")
            }
        })

        // 2. Customer Dues Listener
        db.getReference("$root/dues").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<CustomerDue>()
                for (child in snapshot.children) {
                    try {
                        val id = (child.child("id").value as? Number)?.toLong() ?: child.key?.toLongOrNull() ?: continue
                        val customerName = child.child("customerName").getValue(String::class.java) ?: ""
                        val phone = child.child("phone").getValue(String::class.java) ?: ""
                        val amount = (child.child("amount").value as? Number)?.toDouble() ?: 0.0
                        val note = child.child("note").getValue(String::class.java) ?: ""
                        val date = child.child("date").getValue(String::class.java) ?: ""
                        val historyNotes = child.child("historyNotes").getValue(String::class.java) ?: ""
                        list.add(CustomerDue(id = id, customerName = customerName, phone = phone, amount = amount, note = note, date = date, historyNotes = historyNotes))
                    } catch (e: Exception) {
                        Log.e(TAG, "Error parsing due: ${e.message}")
                    }
                }
                if (list.isNotEmpty()) {
                    scope.launch { onDuesUpdated(list) }
                    updateSyncTimestamp()
                }
            }
            override fun onCancelled(error: DatabaseError) {
                Log.w(TAG, "Dues listener cancelled: ${error.message}")
            }
        })

        // 3. Supplier Memos Listener
        db.getReference("$root/memos").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<SupplierMemo>()
                for (child in snapshot.children) {
                    try {
                        val id = (child.child("id").value as? Number)?.toLong() ?: child.key?.toLongOrNull() ?: continue
                        val supplierName = child.child("supplierName").getValue(String::class.java) ?: ""
                        val memoNo = child.child("memoNo").getValue(String::class.java) ?: ""
                        val amount = (child.child("amount").value as? Number)?.toDouble() ?: 0.0
                        val date = child.child("date").getValue(String::class.java) ?: ""
                        val photoUri = child.child("photoUri").getValue(String::class.java) ?: ""
                        val note = child.child("note").getValue(String::class.java) ?: ""
                        list.add(SupplierMemo(id = id, supplierName = supplierName, memoNo = memoNo, amount = amount, date = date, photoUri = photoUri, note = note))
                    } catch (e: Exception) {
                        Log.e(TAG, "Error parsing memo: ${e.message}")
                    }
                }
                if (list.isNotEmpty()) {
                    scope.launch { onMemosUpdated(list) }
                    updateSyncTimestamp()
                }
            }
            override fun onCancelled(error: DatabaseError) {
                Log.w(TAG, "Memos listener cancelled: ${error.message}")
            }
        })

        // 4. Transactions Listener
        db.getReference("$root/transactions").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<SaleTransaction>()
                for (child in snapshot.children) {
                    try {
                        val id = (child.child("id").value as? Number)?.toLong() ?: child.key?.toLongOrNull() ?: continue
                        val timestamp = (child.child("timestamp").value as? Number)?.toLong() ?: 0L
                        val totalAmount = (child.child("totalAmount").value as? Number)?.toDouble() ?: 0.0
                        val totalProfit = (child.child("totalProfit").value as? Number)?.toDouble() ?: 0.0
                        val itemsSummary = child.child("itemsSummary").getValue(String::class.java) ?: ""
                        val customerPhone = child.child("customerPhone").getValue(String::class.java) ?: ""
                        val dateFormatted = child.child("dateFormatted").getValue(String::class.java) ?: ""
                        list.add(SaleTransaction(id = id, timestamp = timestamp, totalAmount = totalAmount, totalProfit = totalProfit, itemsSummary = itemsSummary, customerPhone = customerPhone, dateFormatted = dateFormatted))
                    } catch (e: Exception) {
                        Log.e(TAG, "Error parsing transaction: ${e.message}")
                    }
                }
                if (list.isNotEmpty()) {
                    scope.launch { onTransactionsUpdated(list) }
                    updateSyncTimestamp()
                }
            }
            override fun onCancelled(error: DatabaseError) {
                Log.w(TAG, "Transactions listener cancelled: ${error.message}")
            }
        })

        // 5. Profile Listener
        db.getReference("$root/profile").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    try {
                        val shopName = snapshot.child("shopName").getValue(String::class.java) ?: "Digi Dhukan"
                        val address = snapshot.child("address").getValue(String::class.java) ?: ""
                        val bossName = snapshot.child("bossName").getValue(String::class.java) ?: ""
                        val phone = snapshot.child("phone").getValue(String::class.java) ?: ""
                        val email = snapshot.child("email").getValue(String::class.java) ?: ""
                        val userUid = snapshot.child("userUid").getValue(String::class.java) ?: activeUid
                        val pin = snapshot.child("pin").getValue(String::class.java) ?: "1234"
                        val securityQuestion = snapshot.child("securityQuestion").getValue(String::class.java) ?: "What is your pet's name?"
                        val securityAnswer = snapshot.child("securityAnswer").getValue(String::class.java) ?: ""
                        val isAppLockMaster = snapshot.child("isAppLockMasterEnabled").getValue(Boolean::class.java) ?: true
                        val launchPriority = snapshot.child("launchLockPriority").getValue(String::class.java) ?: "FINGERPRINT_FIRST"
                        val profile = StoreProfile(
                            shopName = shopName,
                            address = address,
                            bossName = bossName,
                            phone = phone,
                            email = email,
                            userUid = userUid,
                            pin = pin,
                            securityQuestion = securityQuestion,
                            securityAnswer = securityAnswer,
                            isAppLockMasterEnabled = isAppLockMaster,
                            launchLockPriority = launchPriority
                        )
                        scope.launch { onProfileUpdated(profile) }
                    } catch (e: Exception) {
                        Log.e(TAG, "Error parsing profile: ${e.message}")
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    fun pushAllLocalToCloud(
        products: List<Product>,
        dues: List<CustomerDue>,
        memos: List<SupplierMemo>,
        transactions: List<SaleTransaction>,
        profile: StoreProfile,
        onComplete: (Boolean) -> Unit = {}
    ) {
        init()
        val db = database
        if (db == null) {
            onComplete(false)
            return
        }
        _isSyncing.value = true
        scope.launch {
            try {
                val root = getRootNode()
                val rootRef = db.getReference(root)

                val productsMap = mutableMapOf<String, Any>()
                products.forEach { p ->
                    productsMap[p.id.toString()] = mapOf(
                        "id" to p.id,
                        "barcode" to p.barcode,
                        "name" to p.name,
                        "buyPrice" to p.buyPrice,
                        "sellPrice" to p.sellPrice,
                        "stock" to p.stock,
                        "category" to p.category,
                        "imageUri" to p.imageUri,
                        "lastAddedQty" to p.lastAddedQty
                    )
                }
                rootRef.child("products").updateChildren(productsMap)

                val duesMap = mutableMapOf<String, Any>()
                dues.forEach { d ->
                    duesMap[d.id.toString()] = mapOf(
                        "id" to d.id,
                        "customerName" to d.customerName,
                        "phone" to d.phone,
                        "amount" to d.amount,
                        "note" to d.note,
                        "date" to d.date,
                        "historyNotes" to d.historyNotes
                    )
                }
                rootRef.child("dues").updateChildren(duesMap)

                val memosMap = mutableMapOf<String, Any>()
                memos.forEach { m ->
                    memosMap[m.id.toString()] = mapOf(
                        "id" to m.id,
                        "supplierName" to m.supplierName,
                        "memoNo" to m.memoNo,
                        "amount" to m.amount,
                        "date" to m.date,
                        "photoUri" to m.photoUri,
                        "note" to m.note
                    )
                }
                rootRef.child("memos").updateChildren(memosMap)

                val txnMap = mutableMapOf<String, Any>()
                transactions.forEach { t ->
                    txnMap[t.id.toString()] = mapOf(
                        "id" to t.id,
                        "timestamp" to t.timestamp,
                        "totalAmount" to t.totalAmount,
                        "totalProfit" to t.totalProfit,
                        "itemsSummary" to t.itemsSummary,
                        "customerPhone" to t.customerPhone,
                        "dateFormatted" to t.dateFormatted
                    )
                }
                rootRef.child("transactions").updateChildren(txnMap)

                rootRef.child("profile").setValue(
                    mapOf(
                        "shopName" to profile.shopName,
                        "address" to profile.address,
                        "bossName" to profile.bossName,
                        "phone" to profile.phone,
                        "email" to profile.email,
                        "userUid" to profile.userUid,
                        "pin" to profile.pin,
                        "securityQuestion" to profile.securityQuestion,
                        "securityAnswer" to profile.securityAnswer,
                        "isAppLockMasterEnabled" to profile.isAppLockMasterEnabled,
                        "launchLockPriority" to profile.launchLockPriority
                    )
                )

                _isSyncing.value = false
                updateSyncTimestamp()
                onComplete(true)
            } catch (e: Exception) {
                Log.e(TAG, "Error pushing all data: ${e.message}")
                _isSyncing.value = false
                onComplete(false)
            }
        }
    }

    private fun updateSyncTimestamp() {
        val timeStr = SimpleDateFormat("hh:mm a, dd MMM", Locale.getDefault()).format(Date())
        _lastSyncTime.value = timeStr
    }
}
