package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name ASC")
    fun getAllProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE barcode = :barcode LIMIT 1")
    suspend fun getProductByBarcode(barcode: String): Product?

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    suspend fun getProductById(id: Long): Product?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: Product): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(products: List<Product>)

    @Update
    suspend fun updateProduct(product: Product)

    @Delete
    suspend fun deleteProduct(product: Product)

    @Query("DELETE FROM products WHERE id IN (:ids)")
    suspend fun deleteProductsByIds(ids: List<Long>)

    @Query("DELETE FROM products")
    suspend fun deleteAllProducts()

    @Query("UPDATE products SET stock = :newStock WHERE id = :id")
    suspend fun updateStock(id: Long, newStock: Int)

    @Query("UPDATE products SET stock = :newStock, lastAddedQty = :lastAdded WHERE id = :id")
    suspend fun updateStockAndLastAdded(id: Long, newStock: Int, lastAdded: Int)

    @Query("SELECT COUNT(*) FROM products")
    suspend fun getProductCount(): Int
}

@Dao
interface CustomerDueDao {
    @Query("SELECT * FROM customer_dues ORDER BY id DESC")
    fun getAllDues(): Flow<List<CustomerDue>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDue(due: CustomerDue): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(dues: List<CustomerDue>)

    @Update
    suspend fun updateDue(due: CustomerDue)

    @Delete
    suspend fun deleteDue(due: CustomerDue)

    @Query("DELETE FROM customer_dues WHERE id = :id")
    suspend fun deleteDueById(id: Long)

    @Query("DELETE FROM customer_dues WHERE id IN (:ids)")
    suspend fun deleteDuesByIds(ids: List<Long>)

    @Query("DELETE FROM customer_dues")
    suspend fun deleteAllDues()

    @Query("SELECT * FROM customer_dues WHERE phone = :phone LIMIT 1")
    suspend fun getDueByPhone(phone: String): CustomerDue?
}

@Dao
interface SupplierMemoDao {
    @Query("SELECT * FROM supplier_memos ORDER BY id DESC")
    fun getAllMemos(): Flow<List<SupplierMemo>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemo(memo: SupplierMemo): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(memos: List<SupplierMemo>)

    @Update
    suspend fun updateMemo(memo: SupplierMemo)

    @Delete
    suspend fun deleteMemo(memo: SupplierMemo)

    @Query("DELETE FROM supplier_memos WHERE id IN (:ids)")
    suspend fun deleteMemosByIds(ids: List<Long>)

    @Query("DELETE FROM supplier_memos")
    suspend fun deleteAllMemos()
}

@Dao
interface SaleTransactionDao {
    @Query("SELECT * FROM sale_transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<SaleTransaction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: SaleTransaction): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(transactions: List<SaleTransaction>)

    @Delete
    suspend fun deleteTransaction(transaction: SaleTransaction)

    @Query("DELETE FROM sale_transactions WHERE id = :id")
    suspend fun deleteTransactionById(id: Long)

    @Query("DELETE FROM sale_transactions WHERE id IN (:ids)")
    suspend fun deleteTransactionsByIds(ids: List<Long>)

    @Query("DELETE FROM sale_transactions")
    suspend fun deleteAllTransactions()

    @Query("SELECT * FROM sale_transactions ORDER BY timestamp DESC LIMIT 100")
    suspend fun getRecentTransactions(): List<SaleTransaction>
}

@Dao
interface StoreNotificationDao {
    @Query("SELECT * FROM store_notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<StoreNotification>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: StoreNotification): Long

    @Delete
    suspend fun deleteNotification(notification: StoreNotification)

    @Query("DELETE FROM store_notifications WHERE id IN (:ids)")
    suspend fun deleteNotificationsByIds(ids: List<Long>)

    @Query("DELETE FROM store_notifications")
    suspend fun deleteAllNotifications()

    @Query("UPDATE store_notifications SET isRead = 1")
    suspend fun markAllAsRead()

    @Query("SELECT COUNT(*) FROM store_notifications WHERE isRead = 0")
    fun getUnreadCount(): Flow<Int>
}

@Database(
    entities = [Product::class, CustomerDue::class, SupplierMemo::class, SaleTransaction::class, StoreNotification::class],
    version = 8,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun customerDueDao(): CustomerDueDao
    abstract fun supplierMemoDao(): SupplierMemoDao
    abstract fun saleTransactionDao(): SaleTransactionDao
    abstract fun storeNotificationDao(): StoreNotificationDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "digi_dhukan_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
