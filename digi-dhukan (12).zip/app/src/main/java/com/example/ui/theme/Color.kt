package com.example.ui.theme

import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// bKash Pink Brand Palette
val BkashPink = Color(0xFFE2136E)
val BkashPinkDark = Color(0xFFB00050)
val BkashPinkLight = Color(0xFFFF4081)
val BkashPinkContainer = Color(0xFFFFD8E4)
val BkashOnPinkContainer = Color(0xFF3D001D)

val AccentPurple = Color(0xFF8E24AA)
val AccentPurpleContainer = Color(0xFFF3E5F5)

val SuccessGreen = Color(0xFF2E7D32)
val SuccessGreenLight = Color(0xFF4CAF50)
val SuccessGreenContainer = Color(0xFFE8F5E9)

val WarningOrange = Color(0xFFEF6C00)
val AlertRed = Color(0xFFD32F2F)
val AlertRedContainer = Color(0xFFFFEBEE)

val SurfaceBgLight = Color(0xFFF8F9FA)
val CardBgLight = Color(0xFFFFFFFF)

// Dark Mode Palette
val DarkBg = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val DarkCard = Color(0xFF252525)
val DarkBorder = Color(0xFF383838)

// Advance High-Contrast Typography Palette (Light Mode)
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF334155)
val TextMuted = Color(0xFF64748B)

// REQUIREMENT 8: Universal high-contrast text field colors (#000000 Light / #FFFFFF Dark)
@Composable
fun universalTextFieldColors(isDarkMode: Boolean = false) = OutlinedTextFieldDefaults.colors(
    focusedTextColor = if (isDarkMode) Color(0xFFFFFFFF) else Color(0xFF000000),
    unfocusedTextColor = if (isDarkMode) Color(0xFFFFFFFF) else Color(0xFF000000),
    disabledTextColor = if (isDarkMode) Color(0xFFAAAAAA) else Color(0xFF333333),
    focusedLabelColor = BkashPink,
    unfocusedLabelColor = if (isDarkMode) Color(0xFFE2E8F0) else Color(0xFF1E293B),
    focusedPlaceholderColor = if (isDarkMode) Color(0xFFB0B0B0) else Color(0xFF64748B),
    unfocusedPlaceholderColor = if (isDarkMode) Color(0xFFB0B0B0) else Color(0xFF64748B),
    focusedBorderColor = BkashPink,
    unfocusedBorderColor = if (isDarkMode) Color(0xFF718096) else Color(0xFF475569),
    focusedContainerColor = if (isDarkMode) Color(0xFF1E1E1E) else Color.White,
    unfocusedContainerColor = if (isDarkMode) Color(0xFF1E1E1E) else Color.White,
    cursorColor = BkashPink
)
