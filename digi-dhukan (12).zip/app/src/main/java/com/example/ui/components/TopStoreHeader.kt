package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBasket
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.StoreProfile
import com.example.ui.theme.BkashPink
import com.example.util.AppStrings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopStoreHeader(
    storeProfile: StoreProfile,
    userRole: String,
    cartItemCount: Int,
    notificationCount: Int = 0,
    isLiveChartEnabled: Boolean,
    isDarkMode: Boolean = false,
    isEnglish: Boolean = false,
    isCloudConnected: Boolean = true,
    isCloudSyncing: Boolean = false,
    isRefreshing: Boolean = false,
    onOpenCart: () -> Unit,
    onOpenNotifications: () -> Unit = {},
    onOpenProfile: () -> Unit,
    onOpenPinSettings: () -> Unit,
    onOpenBarcodeGen: () -> Unit,
    onCheckForUpdates: () -> Unit = {},
    onOpenGoogleDriveBackup: () -> Unit = {},
    onToggleLiveChart: () -> Unit,
    onToggleDarkMode: () -> Unit,
    onToggleLanguage: () -> Unit,
    onLockApp: () -> Unit,
    onRefreshApp: () -> Unit = {},
    onSyncCloud: () -> Unit = {},
    onOfflineBackup: () -> Unit = {}
) {
    var menuExpanded by remember { mutableStateOf(false) }

    TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = if (isDarkMode) Color(0xFF1E1E1E) else BkashPink,
            titleContentColor = Color.White
        ),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // 1. Far Left: Store Avatar/Icon with small Cloud Status badge ('● Cloud') directly below it
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onSyncCloud() }
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.White.copy(alpha = 0.25f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.digi_dhukan_icon),
                            contentDescription = "Digi Dhukan App Icon",
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    // Small Cloud Status badge ('● Cloud') below avatar
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color.Black.copy(alpha = 0.26f)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(5.dp)
                                    .background(
                                        if (isCloudSyncing) Color(0xFFFFEB3B)
                                        else if (isCloudConnected) Color(0xFF4CAF50)
                                        else Color(0xFFFF9800),
                                        CircleShape
                                    )
                            )
                            Spacer(modifier = Modifier.width(2.5.dp))
                            Text(
                                text = if (isCloudSyncing) {
                                    if (isEnglish) "Sync..." else "সিঙ্ক..."
                                } else if (isCloudConnected) {
                                    "Cloud"
                                } else {
                                    if (isEnglish) "Off" else "অফলাইন"
                                },
                                fontSize = 7.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White.copy(alpha = 0.95f)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // 2. Middle Section:
                // - Prominent Store Name on top row with dynamic auto-sizing fontSize
                // - Owner Badge (★ মালিক), Phone Number, and Store Address ('ঠিকানা:') directly below in compact rows
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 4.dp)
                        .clickable { onOpenProfile() }
                ) {
                    val storeName = storeProfile.shopName.ifBlank {
                        if (isEnglish) "Digi Dhukan" else "ডিজি দোকান"
                    }

                    // Dynamic Auto-Sizing Store Name
                    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                        val availableWidth = maxWidth
                        val calculatedFontSize = when {
                            availableWidth < 120.dp || storeName.length > 32 -> 11.5.sp
                            availableWidth < 150.dp || storeName.length > 24 -> 12.5.sp
                            availableWidth < 180.dp || storeName.length > 17 -> 14.sp
                            storeName.length > 12 -> 15.sp
                            else -> 16.5.sp
                        }

                        Text(
                            text = storeName,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = calculatedFontSize,
                            color = Color.White,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    // Row 1: Owner Badge + Phone
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = Color(0xFF5E35B1),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = if (isEnglish) "★ Owner" else "★ মালিক",
                                fontSize = 9.sp,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = storeProfile.phone.ifBlank { "01700000000" },
                            fontSize = 10.sp,
                            color = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.height(1.dp))

                    // Row 2: Address
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (isEnglish) "Address: " else "ঠিকানা: ",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                        Text(
                            text = storeProfile.address.ifBlank { if (isEnglish) "Not set" else "দেওয়া হয়নি" },
                            fontSize = 9.sp,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.height(1.dp))

                    // Row 3: Owner Name
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (isEnglish) "Owner Name: " else "মালিকের নাম: ",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                        Text(
                            text = storeProfile.bossName.ifBlank { if (isEnglish) "Not set" else "দেওয়া হয়নি" },
                            fontSize = 9.sp,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        },
        actions = {
            // Top-right corner actions:
            // 1. Language switcher ('বাং | EN')
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color.Black.copy(alpha = 0.22f),
                modifier = Modifier.padding(end = 2.dp)
            ) {
                Row(
                    modifier = Modifier.padding(2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (!isEnglish) Color.White else Color.Transparent,
                        modifier = Modifier.clickable {
                            if (isEnglish) onToggleLanguage()
                        }
                    ) {
                        Text(
                            text = "বাং",
                            color = if (!isEnglish) BkashPink else Color.White.copy(alpha = 0.85f),
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isEnglish) Color.White else Color.Transparent,
                        modifier = Modifier.clickable {
                            if (!isEnglish) onToggleLanguage()
                        }
                    ) {
                        Text(
                            text = "EN",
                            color = if (isEnglish) BkashPink else Color.White.copy(alpha = 0.85f),
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            // 2. Notification Bell with Badge
            IconButton(
                onClick = onOpenNotifications,
                modifier = Modifier.size(36.dp)
            ) {
                BadgedBox(
                    badge = {
                        if (notificationCount > 0) {
                            Badge(
                                containerColor = Color(0xFFFFD600),
                                contentColor = Color.Black
                            ) {
                                Text(
                                    text = "$notificationCount",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = AppStrings.notificationCenter(isEnglish),
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // 3. Cart Icon with live badge
            IconButton(
                onClick = onOpenCart,
                modifier = Modifier.size(36.dp)
            ) {
                BadgedBox(
                    badge = {
                        if (cartItemCount > 0) {
                            Badge(
                                containerColor = Color(0xFFD32F2F),
                                contentColor = Color.White
                            ) {
                                Text(
                                    text = "$cartItemCount",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.ShoppingBasket,
                        contentDescription = "Cart",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // 4. 3-Dot Overflow Menu (...) containing Manual Refresh, Dark/Light Mode, and settings
            Box {
                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Options",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                    modifier = Modifier.background(MaterialTheme.colorScheme.surface)
                ) {
                    // A. Manual Refresh / Reload Data option
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(AppStrings.refreshApp(isEnglish), fontWeight = FontWeight.Bold)
                                Text(
                                    if (isEnglish) "Reload inventory, dues & memos" else "ডাটা রিলোড ও রিফ্রেশ করুন",
                                    fontSize = 9.5.sp,
                                    color = Color.Gray
                                )
                            }
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = null,
                                tint = if (isRefreshing) Color(0xFFFF9800) else BkashPink
                            )
                        },
                        onClick = {
                            menuExpanded = false
                            onRefreshApp()
                        }
                    )

                    // B. Dark Mode / Light Mode Theme Toggle
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(
                                    AppStrings.toggleDarkMode(isEnglish, isDarkMode),
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    if (isDarkMode) (if (isEnglish) "Switch to light theme" else "উজ্জ্বল থিমে পরিবর্তন")
                                    else (if (isEnglish) "Switch to dark theme" else "অন্ধকার বা নাইট থিমে পরিবর্তন"),
                                    fontSize = 9.5.sp,
                                    color = Color.Gray
                                )
                            }
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = null,
                                tint = if (isDarkMode) Color(0xFFFFB300) else Color(0xFF5E35B1)
                            )
                        },
                        onClick = {
                            menuExpanded = false
                            onToggleDarkMode()
                        }
                    )

                    HorizontalDivider()

                    // C. In-App Update Checker
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(AppStrings.checkForUpdates(isEnglish), fontWeight = FontWeight.Bold)
                                Text(
                                    if (isEnglish) "Check for new APK releases" else "নতুন আপডেট পরীক্ষা করুন",
                                    fontSize = 9.5.sp,
                                    color = Color.Gray
                                )
                            }
                        },
                        leadingIcon = {
                            Icon(Icons.Default.SystemUpdate, contentDescription = null, tint = Color(0xFF1976D2))
                        },
                        onClick = {
                            menuExpanded = false
                            onCheckForUpdates()
                        }
                    )

                    // D. Google Drive Cloud Backup
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(AppStrings.googleDriveBackup(isEnglish), fontWeight = FontWeight.Bold)
                                Text(
                                    if (isEnglish) "Backup data to personal Google Drive" else "ব্যক্তিগত গুগল ড্রাইভে ব্যাকআপ",
                                    fontSize = 9.5.sp,
                                    color = Color.Gray
                                )
                            }
                        },
                        leadingIcon = {
                            Icon(Icons.Default.CloudDone, contentDescription = null, tint = Color(0xFF00897B))
                        },
                        onClick = {
                            menuExpanded = false
                            onOpenGoogleDriveBackup()
                        }
                    )

                    // E. Cloud Sync All Data
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(AppStrings.cloudSync(isEnglish), fontWeight = FontWeight.Bold)
                                Text(
                                    if (isEnglish) "Sync products, dues & memos" else "ক্লাউডে সকল ডাটা আপলোড ও সিঙ্ক",
                                    fontSize = 9.5.sp,
                                    color = Color.Gray
                                )
                            }
                        },
                        leadingIcon = {
                            Icon(Icons.Default.CloudSync, contentDescription = null, tint = BkashPink)
                        },
                        onClick = {
                            menuExpanded = false
                            onSyncCloud()
                        }
                    )

                    // F. Offline Database Backup (JSON)
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(AppStrings.offlineBackup(isEnglish), fontWeight = FontWeight.Bold)
                                Text(
                                    if (isEnglish) "Export full JSON database backup" else "ডিভাইসে সম্পূর্ণ ব্যাকআপ ফাইল সেভ",
                                    fontSize = 9.5.sp,
                                    color = Color.Gray
                                )
                            }
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Download, contentDescription = null, tint = Color(0xFF00796B))
                        },
                        onClick = {
                            menuExpanded = false
                            onOfflineBackup()
                        }
                    )

                    // G. Store & Profile Settings
                    DropdownMenuItem(
                        text = { Text(AppStrings.profileSettings(isEnglish)) },
                        leadingIcon = {
                            Icon(Icons.Default.Settings, contentDescription = null, tint = BkashPink)
                        },
                        onClick = {
                            menuExpanded = false
                            onOpenProfile()
                        }
                    )

                    // H. App Lock & Security Settings
                    DropdownMenuItem(
                        text = { Text(AppStrings.appLockSettings(isEnglish), fontWeight = FontWeight.Bold) },
                        leadingIcon = {
                            Icon(Icons.Default.Key, contentDescription = null, tint = BkashPink)
                        },
                        onClick = {
                            menuExpanded = false
                            onOpenPinSettings()
                        }
                    )

                    // I. Custom Barcode Generator
                    DropdownMenuItem(
                        text = { Text(AppStrings.customBarcodeGen(isEnglish)) },
                        leadingIcon = {
                            Icon(Icons.Default.QrCode, contentDescription = null, tint = BkashPink)
                        },
                        onClick = {
                            menuExpanded = false
                            onOpenBarcodeGen()
                        }
                    )

                    // J. Toggle Live Profit/Sales Chart
                    DropdownMenuItem(
                        text = {
                            Text(
                                text = AppStrings.toggleLiveChart(isEnglish, isLiveChartEnabled),
                                fontWeight = FontWeight.Bold,
                                color = if (isLiveChartEnabled) Color(0xFF2E7D32) else Color.DarkGray
                            )
                        },
                        leadingIcon = {
                            Icon(
                                Icons.Default.AutoGraph,
                                contentDescription = null,
                                tint = if (isLiveChartEnabled) Color(0xFF2E7D32) else Color.Gray
                            )
                        },
                        onClick = {
                            menuExpanded = false
                            onToggleLiveChart()
                        }
                    )

                    HorizontalDivider()

                    // K. Lock App Session
                    DropdownMenuItem(
                        text = {
                            Text(
                                AppStrings.lockApp(isEnglish),
                                color = Color(0xFFD32F2F),
                                fontWeight = FontWeight.Bold
                            )
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFFD32F2F))
                        },
                        onClick = {
                            menuExpanded = false
                            onLockApp()
                        }
                    )
                }
            }
        }
    )
}
