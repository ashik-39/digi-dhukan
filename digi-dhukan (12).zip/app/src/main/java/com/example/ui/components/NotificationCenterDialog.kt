package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.StoreNotification
import com.example.ui.MainViewModel
import com.example.ui.theme.AlertRed
import com.example.ui.theme.BkashPink
import com.example.ui.theme.SuccessGreen
import com.example.util.AppStrings

@Composable
fun NotificationCenterDialog(
    viewModel: MainViewModel,
    isOpen: Boolean,
    isDarkMode: Boolean = false,
    isEnglish: Boolean = false,
    onDismiss: () -> Unit
) {
    if (!isOpen) return

    val notifications by viewModel.notifications.collectAsState()
    var selectedIds by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var showClearAllConfirmation by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Top Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = BkashPink.copy(alpha = 0.15f),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Notifications,
                                    contentDescription = null,
                                    tint = BkashPink,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = AppStrings.notificationCenter(isEnglish),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = BkashPink
                                )
                                if (notifications.isNotEmpty()) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = BkashPink
                                    ) {
                                        Text(
                                            text = "${notifications.size}",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }
                            Text(
                                text = if (isEnglish) "System alerts, sales & stock warnings" else "বিক্রয়, কম স্টক ও সিস্টেম এলার্ট",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Toolbar: Select All, Bulk Delete, Clear All, Mark as Read
                if (notifications.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                if (isDarkMode) Color(0xFF242424) else Color(0xFFF1F5F9),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = selectedIds.isNotEmpty() && selectedIds.size == notifications.size,
                                onCheckedChange = { isChecked ->
                                    selectedIds = if (isChecked) notifications.map { it.id }.toSet() else emptySet()
                                },
                                colors = CheckboxDefaults.colors(checkedColor = BkashPink)
                            )
                            Text(
                                text = if (isEnglish) "Select All (${notifications.size})" else "সব সিলেক্ট (${notifications.size})",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            // Bulk Delete Selected
                            AnimatedVisibility(visible = selectedIds.isNotEmpty()) {
                                Button(
                                    onClick = {
                                        viewModel.deleteNotifications(selectedIds.toList())
                                        selectedIds = emptySet()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "${selectedIds.size}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Mark All Read
                            IconButton(
                                onClick = { viewModel.markAllNotificationsAsRead() },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DoneAll,
                                    contentDescription = AppStrings.markAllRead(isEnglish),
                                    tint = SuccessGreen,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            // Clear / Delete All
                            OutlinedButton(
                                onClick = { showClearAllConfirmation = true },
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = AlertRed),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Text(AppStrings.clearAllNotifications(isEnglish), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Notification items list
                if (notifications.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.NotificationsOff,
                                contentDescription = null,
                                tint = Color.Gray,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (isEnglish) "No notifications recorded yet" else "কোন নোটিফিকেশন জমা নেই",
                                fontSize = 13.sp,
                                color = Color.Gray,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(340.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(notifications, key = { it.id }) { notif ->
                            val isSelected = selectedIds.contains(notif.id)
                            NotificationItemRow(
                                notif = notif,
                                isSelected = isSelected,
                                isDarkMode = isDarkMode,
                                onToggleSelect = {
                                    selectedIds = if (isSelected) {
                                        selectedIds - notif.id
                                    } else {
                                        selectedIds + notif.id
                                    }
                                },
                                onDelete = { viewModel.deleteNotification(notif.id) }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showClearAllConfirmation) {
        AlertDialog(
            onDismissRequest = { showClearAllConfirmation = false },
            title = { Text(if (isEnglish) "Clear All Notifications?" else "সব নোটিফিকেশন মুছবেন?") },
            text = {
                Text(
                    if (isEnglish)
                        "Are you sure you want to clear all ${notifications.size} system notifications?"
                    else
                        "আপনি কি নিশ্চিত যে সকল (${notifications.size} টি) নোটিফিকেশন মুছে ফেলতে চান?"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearAllNotifications()
                        selectedIds = emptySet()
                        showClearAllConfirmation = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed)
                ) {
                    Text(if (isEnglish) "Clear All" else "সব মুছুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearAllConfirmation = false }) {
                    Text(if (isEnglish) "Cancel" else "বাতিল")
                }
            }
        )
    }
}

@Composable
fun NotificationItemRow(
    notif: StoreNotification,
    isSelected: Boolean,
    isDarkMode: Boolean,
    onToggleSelect: () -> Unit,
    onDelete: () -> Unit
) {
    val (icon, iconColor, bgTint) = when (notif.type) {
        "LOW_STOCK" -> Triple(Icons.Default.Warning, Color(0xFFE65100), if (isDarkMode) Color(0xFF331D0E) else Color(0xFFFFF3E0))
        "SALE" -> Triple(Icons.Default.ShoppingBag, Color(0xFF2E7D32), if (isDarkMode) Color(0xFF132B18) else Color(0xFFE8F5E9))
        "PURCHASE" -> Triple(Icons.Default.ReceiptLong, Color(0xFF1565C0), if (isDarkMode) Color(0xFF122238) else Color(0xFFE3F2FD))
        "SETTLED" -> Triple(Icons.Default.CheckCircle, SuccessGreen, if (isDarkMode) Color(0xFF122C1C) else Color(0xFFE8F8F5))
        "EXPORT" -> Triple(Icons.Default.Download, Color(0xFF8E24AA), if (isDarkMode) Color(0xFF2E1535) else Color(0xFFF3E5F5))
        else -> Triple(Icons.Default.Notifications, BkashPink, if (isDarkMode) Color(0xFF2D1420) else Color(0xFFFFEBEE))
    }

    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                if (isDarkMode) Color(0xFF3A1828) else Color(0xFFFFEBEE)
            } else {
                if (isDarkMode) Color(0xFF222222) else Color(0xFFFBFBFB)
            }
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) BkashPink else if (isDarkMode) Color(0xFF333333) else Color(0xFFE2E8F0)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggleSelect() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = isSelected,
                onCheckedChange = { onToggleSelect() },
                colors = CheckboxDefaults.colors(checkedColor = BkashPink)
            )

            Surface(
                shape = CircleShape,
                color = bgTint,
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(imageVector = icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(18.dp))
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = notif.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.5.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = notif.dateFormatted,
                        fontSize = 9.5.sp,
                        color = Color.Gray
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = notif.message,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 15.sp
                )
            }

            IconButton(onClick = onDelete, modifier = Modifier.size(26.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(14.dp))
            }
        }
    }
}
