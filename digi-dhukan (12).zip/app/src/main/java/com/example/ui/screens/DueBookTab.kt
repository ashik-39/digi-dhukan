package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CustomerDue
import com.example.ui.MainViewModel
import com.example.ui.theme.AlertRed
import com.example.ui.theme.BkashPink
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.universalTextFieldColors
import com.example.util.AppStrings

@Composable
fun DueBookTab(
    viewModel: MainViewModel,
    isDarkMode: Boolean = false,
    isEnglish: Boolean = false,
    onOpenAddDue: () -> Unit
) {
    val context = LocalContext.current
    val dues by viewModel.dues.collectAsState()
    val selectedDueIds by viewModel.selectedDueIds.collectAsState()
    var dueSearchQuery by remember { mutableStateOf("") }
    var showDeleteConfirmation by remember { mutableStateOf(false) }

    // REQUIREMENT 7: Segmented selection (0: Active Dues, 1: Settled / History Log)
    var dueTabSelection by remember { mutableStateOf(0) }

    val activeDuesCount = remember(dues) { dues.count { it.amount > 0 } }
    val settledDuesCount = remember(dues) { dues.count { it.amount <= 0 } }

    val filteredDues = remember(dues, dueSearchQuery, dueTabSelection) {
        val baseList = if (dueTabSelection == 0) {
            dues.filter { it.amount > 0 }
        } else {
            dues.filter { it.amount <= 0 }
        }
        baseList.filter { d ->
            dueSearchQuery.isBlank() ||
                    d.customerName.contains(dueSearchQuery, ignoreCase = true) ||
                    d.phone.contains(dueSearchQuery, ignoreCase = true) ||
                    d.note.contains(dueSearchQuery, ignoreCase = true) ||
                    d.historyNotes.contains(dueSearchQuery, ignoreCase = true)
        }
    }

    val totalDues = remember(dues) { dues.filter { it.amount > 0 }.sumOf { it.amount } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Header with total due amount
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isDarkMode) Color(0xFF381414) else Color(0xFFFFEBEE),
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.MenuBook, contentDescription = null, tint = AlertRed)
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(AppStrings.totalDues(isEnglish), fontSize = 11.sp, color = Color.Gray)
                        Text("৳ ${totalDues.toInt()}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = AlertRed)
                    }
                }

                Button(
                    onClick = onOpenAddDue,
                    colors = ButtonDefaults.buttonColors(containerColor = BkashPink),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(AppStrings.newDue(isEnglish), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search Input with clear button (Requirement 8: high contrast, minHeight 56dp)
        OutlinedTextField(
            value = dueSearchQuery,
            onValueChange = { dueSearchQuery = it },
            placeholder = { Text(AppStrings.dueSearchPlaceholder(isEnglish), fontSize = 12.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = BkashPink) },
            trailingIcon = {
                if (dueSearchQuery.isNotEmpty()) {
                    IconButton(onClick = { dueSearchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.Gray, modifier = Modifier.size(18.dp))
                    }
                }
            },
            singleLine = true,
            textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
            modifier = Modifier
                .fillMaxWidth()
                .defaultMinSize(minHeight = 56.dp),
            shape = RoundedCornerShape(12.dp),
            colors = universalTextFieldColors(isDarkMode)
        )

        Spacer(modifier = Modifier.height(8.dp))

        // REQUIREMENT 7: Active Dues vs Settled / History Segmented Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(if (isDarkMode) Color(0xFF242424) else Color(0xFFF1F5F9), RoundedCornerShape(10.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Surface(
                onClick = { dueTabSelection = 0 },
                shape = RoundedCornerShape(8.dp),
                color = if (dueTabSelection == 0) BkashPink else Color.Transparent,
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 7.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.MenuBook,
                        contentDescription = null,
                        tint = if (dueTabSelection == 0) Color.White else Color.Gray,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${AppStrings.activeDues(isEnglish)} ($activeDuesCount)",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (dueTabSelection == 0) Color.White else MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Surface(
                onClick = { dueTabSelection = 1 },
                shape = RoundedCornerShape(8.dp),
                color = if (dueTabSelection == 1) SuccessGreen else Color.Transparent,
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 7.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = if (dueTabSelection == 1) Color.White else Color.Gray,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${AppStrings.settledHistoryLog(isEnglish)} ($settledDuesCount)",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (dueTabSelection == 1) Color.White else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Select All & Bulk Delete Toolbar
        if (dues.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (isDarkMode) Color(0xFF242424) else Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = selectedDueIds.isNotEmpty() && selectedDueIds.size == dues.size,
                        onCheckedChange = { isChecked ->
                            viewModel.selectAllDues(isChecked)
                        },
                        colors = CheckboxDefaults.colors(checkedColor = BkashPink)
                    )
                    Text(
                        text = if (isEnglish) "Select All Dues (${dues.size})" else "সব সিলেক্ট (${dues.size} জন)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (selectedDueIds.isNotEmpty()) {
                    Button(
                        onClick = { showDeleteConfirmation = true },
                        colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isEnglish) "Delete (${selectedDueIds.size})" else "মুছুন (${selectedDueIds.size})",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        // Dues list
        if (filteredDues.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (dueTabSelection == 0) {
                        if (isEnglish) "No active dues found!" else "কোন চলতি বাকি হিসাব নেই!"
                    } else {
                        if (isEnglish) "No settled history accounts found!" else "কোন পরিশোধিত বাকি হিসাব নেই!"
                    },
                    color = Color.Gray,
                    fontSize = 13.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredDues, key = { it.id }) { due ->
                    val isSelected = selectedDueIds.contains(due.id)
                    DueItemCard(
                        due = due,
                        isSelected = isSelected,
                        isDarkMode = isDarkMode,
                        onToggleSelect = { viewModel.toggleDueSelection(due.id) },
                        isEnglish = isEnglish,
                        onOpenDetail = {
                            viewModel.selectedDueForDetail.value = due
                            viewModel.isDueDetailOpen.value = true
                        },
                        onSettle = {
                            viewModel.settleFullDue(due)
                        },
                        onCall = {
                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${due.phone}"))
                            context.startActivity(intent)
                        },
                        onWhatsApp = {
                            val msg = "সালামু আলাইকুম ${due.customerName}, ${viewModel.storeProfile.value.shopName}-এ আপনার বাকি: ৳${due.amount.toInt()} টাকা।"
                            val url = "https://api.whatsapp.com/send?phone=+88${due.phone}&text=${Uri.encode(msg)}"
                            try {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                            } catch (e: Exception) {
                                val smsIntent = Intent(Intent.ACTION_VIEW, Uri.parse("sms:${due.phone}")).apply {
                                    putExtra("sms_body", msg)
                                }
                                context.startActivity(smsIntent)
                            }
                        }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(90.dp))
                }
            }
        }
    }

    if (showDeleteConfirmation) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmation = false },
            title = { Text(if (isEnglish) "Delete Selected Dues?" else "বাকি হিসাব মুছবেন?") },
            text = {
                Text(
                    if (isEnglish)
                        "Are you sure you want to delete the due accounts of ${selectedDueIds.size} selected customers?"
                    else
                        "আপনি কি নির্বাচিত ${selectedDueIds.size} জন কাস্টমারের বাকি খাতা মুছে ফেলতে চান?"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteSelectedDues()
                        showDeleteConfirmation = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed)
                ) {
                    Text(if (isEnglish) "Delete" else "মুছুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmation = false }) {
                    Text(if (isEnglish) "Cancel" else "বাতিল")
                }
            }
        )
    }
}

@Composable
fun DueItemCard(
    due: CustomerDue,
    isSelected: Boolean,
    isDarkMode: Boolean = false,
    onToggleSelect: () -> Unit,
    isEnglish: Boolean,
    onOpenDetail: () -> Unit,
    onSettle: () -> Unit,
    onCall: () -> Unit,
    onWhatsApp: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenDetail() },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                if (isDarkMode) Color(0xFF3D1822) else Color(0xFFFFEBEE)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Checkbox(
                        checked = isSelected,
                        onCheckedChange = { onToggleSelect() },
                        colors = CheckboxDefaults.colors(checkedColor = BkashPink)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Column {
                        Text(
                            text = due.customerName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = due.phone,
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    if (due.amount <= 0.0) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = SuccessGreen.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = if (isEnglish) "✓ Settled (৳0)" else "✓ পরিশোধিত (৳০)",
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = SuccessGreen,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    } else {
                        Text(
                            text = "৳ ${due.amount.toInt()}",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp,
                            color = AlertRed
                        )
                    }
                    Text(
                        text = due.date,
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                }
            }

            if (due.note.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "${AppStrings.description(isEnglish)}: ${due.note}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action row: Call, WhatsApp, Settle & Edit Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (isDarkMode) Color(0xFF132B18) else Color(0xFFE8F5E9),
                        modifier = Modifier
                            .clickable { onCall() }
                            .padding(2.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Call, contentDescription = "Call", tint = SuccessGreen, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isEnglish) "Call" else "কল", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (isDarkMode) Color(0xFF122C2A) else Color(0xFFE0F2F1),
                        modifier = Modifier
                            .clickable { onWhatsApp() }
                            .padding(2.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Message, contentDescription = "WhatsApp", tint = Color(0xFF00897B), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isEnglish) "Notice" else "তাগাদা", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00897B))
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // REQUIREMENT 7: Settle Full Due Button
                    if (due.amount > 0.0) {
                        OutlinedButton(
                            onClick = onSettle,
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(if (isEnglish) "Settle Full" else "সম্পূর্ণ পরিশোধ", fontSize = 10.sp, color = SuccessGreen, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        OutlinedButton(
                            onClick = onOpenDetail,
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Icon(Icons.Default.History, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(if (isEnglish) "History Log" else "হিসাব লগ", fontSize = 10.sp, color = SuccessGreen, fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = onOpenDetail,
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BkashPink),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Icon(Icons.Default.EditNote, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(if (isEnglish) "Details" else "বিবরণ", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
