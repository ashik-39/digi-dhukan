package com.example.ui.components

import android.app.DatePickerDialog
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.Product
import com.example.data.StoreProfile
import com.example.data.SupplierMemo
import com.example.ui.theme.AlertRed
import com.example.ui.theme.BkashPink
import com.example.ui.theme.universalTextFieldColors
import com.example.util.AppStrings
import com.example.util.BarcodeUtil
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// 1. ADD / EDIT PRODUCT DIALOG (WITH PHOTO SUPPORT & RESTOCK QUANTITY)
@Composable
fun AddEditProductDialog(
    isOpen: Boolean,
    productToEdit: Product?,
    prefilledBarcode: String = "",
    userRole: String,
    isDarkMode: Boolean = false,
    isEnglish: Boolean = false,
    onDismiss: () -> Unit,
    onScanRequested: () -> Unit,
    onSave: (Product) -> Unit
) {
    if (!isOpen) return

    var barcode by remember(productToEdit, prefilledBarcode) {
        mutableStateOf(productToEdit?.barcode ?: prefilledBarcode)
    }
    var name by remember(productToEdit) { mutableStateOf(productToEdit?.name ?: "") }
    var buyPrice by remember(productToEdit) { mutableStateOf(productToEdit?.buyPrice?.let { if (it > 0) it.toString() else "" } ?: "") }
    var sellPrice by remember(productToEdit) { mutableStateOf(productToEdit?.sellPrice?.let { if (it > 0) it.toString() else "" } ?: "") }
    var stock by remember(productToEdit) { mutableStateOf(productToEdit?.stock?.toString() ?: "10") }
    var category by remember(productToEdit) { mutableStateOf(productToEdit?.category ?: "মুদি (Grocery)") }
    var imageUri by remember(productToEdit) { mutableStateOf(productToEdit?.imageUri ?: "") }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            imageUri = uri.toString()
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (productToEdit != null && productToEdit.id != 0L) AppStrings.editProduct(isEnglish) else AppStrings.addProduct(isEnglish),
                        fontWeight = FontWeight.Bold,
                        color = BkashPink,
                        fontSize = 16.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Barcode input with scan and auto-generate buttons
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = barcode,
                        onValueChange = { barcode = it },
                        label = { Text(if (isEnglish) "Barcode *" else "বারকোড *") },
                        modifier = Modifier.weight(1f).defaultMinSize(minHeight = 56.dp),
                        singleLine = true,
                        textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                        shape = RoundedCornerShape(10.dp),
                        colors = universalTextFieldColors(isDarkMode)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = onScanRequested,
                        modifier = Modifier.size(46.dp)
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = "Scan", tint = BkashPink)
                    }
                    Button(
                        onClick = {
                            barcode = BarcodeUtil.generateRandomBarcode()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(46.dp)
                    ) {
                        Text(AppStrings.autoGenerateBarcode(isEnglish), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(if (isEnglish) "Product Name *" else "পণ্যের নাম *") },
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 56.dp),
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    colors = universalTextFieldColors(isDarkMode)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = buyPrice,
                        onValueChange = { buyPrice = it },
                        label = { Text(if (isEnglish) "Buy Price (৳)" else "ক্রয়মূল্য (৳)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).defaultMinSize(minHeight = 56.dp),
                        singleLine = true,
                        textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                        shape = RoundedCornerShape(10.dp),
                        colors = universalTextFieldColors(isDarkMode)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = sellPrice,
                        onValueChange = { sellPrice = it },
                        label = { Text(if (isEnglish) "Sell Price (৳) *" else "বিক্রয়মূল্য (৳) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).defaultMinSize(minHeight = 56.dp),
                        singleLine = true,
                        textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                        shape = RoundedCornerShape(10.dp),
                        colors = universalTextFieldColors(isDarkMode)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = stock,
                        onValueChange = { stock = it },
                        label = { Text(if (isEnglish) "Stock (Qty) *" else "স্টক সংখ্যা *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).defaultMinSize(minHeight = 56.dp),
                        singleLine = true,
                        textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                        shape = RoundedCornerShape(10.dp),
                        colors = universalTextFieldColors(isDarkMode)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text(if (isEnglish) "Category" else "ক্যাটেগরি") },
                        modifier = Modifier.weight(1f).defaultMinSize(minHeight = 56.dp),
                        singleLine = true,
                        textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                        shape = RoundedCornerShape(10.dp),
                        colors = universalTextFieldColors(isDarkMode)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Product Photo Section
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isDarkMode) Color(0xFF222834) else Color(0xFFF1F5F9),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CameraAlt, contentDescription = null, tint = BkashPink, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isEnglish) "Product Photo (Camera / Gallery):" else "পণ্যের ছবি (ক্যামেরা/গ্যালারি):",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            if (imageUri.isNotBlank()) {
                                TextButton(
                                    onClick = { imageUri = "" },
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text(if (isEnglish) "Remove" else "ছবি সরান", color = AlertRed, fontSize = 11.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        if (imageUri.isNotBlank()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.size(60.dp)
                                ) {
                                    coil.compose.SubcomposeAsyncImage(
                                        model = imageUri,
                                        contentDescription = "Product Photo",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                OutlinedButton(
                                    onClick = {
                                        photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Text(if (isEnglish) "Change Photo" else "ছবি পরিবর্তন", fontSize = 11.sp)
                                }
                            }
                        } else {
                            OutlinedButton(
                                onClick = {
                                    photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().height(38.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (isEnglish) "Attach / Take Product Photo" else "পণ্যের ছবি তুলুন / যুক্ত করুন", fontSize = 11.5.sp)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        if (barcode.isBlank() || name.isBlank() || sellPrice.isBlank()) {
                            return@Button
                        }
                        val parsedStock = stock.toIntOrNull() ?: 0
                        val product = Product(
                            id = productToEdit?.id ?: 0L,
                            barcode = barcode.trim(),
                            name = name.trim(),
                            buyPrice = buyPrice.toDoubleOrNull() ?: 0.0,
                            sellPrice = sellPrice.toDoubleOrNull() ?: 0.0,
                            stock = parsedStock,
                            category = category.trim(),
                            imageUri = imageUri.trim(),
                            lastAddedQty = productToEdit?.lastAddedQty ?: parsedStock
                        )
                        onSave(product)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BkashPink),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().height(46.dp)
                ) {
                    Text(text = if (isEnglish) "Save Product" else "পণ্য সংরক্ষণ করুন", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// 2. ADD CUSTOMER DUE DIALOG
@Composable
fun AddCustomerDueDialog(
    isOpen: Boolean,
    isDarkMode: Boolean = false,
    isEnglish: Boolean = false,
    onDismiss: () -> Unit,
    onSave: (name: String, phone: String, amount: Double, note: String) -> Unit
) {
    if (!isOpen) return

    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var descriptionList by remember { mutableStateOf(listOf("")) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = AppStrings.newDue(isEnglish),
                        fontWeight = FontWeight.Bold,
                        color = BkashPink,
                        fontSize = 16.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(AppStrings.customerName(isEnglish) + " *") },
                    placeholder = { Text(if (isEnglish) "e.g. Rahim Ahmed" else "যেমন: রহিম মিয়া") },
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 56.dp),
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    colors = universalTextFieldColors(isDarkMode)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text(AppStrings.phone(isEnglish) + " *") },
                    placeholder = { Text("017XXXXXXXX") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 56.dp),
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    colors = universalTextFieldColors(isDarkMode)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text(AppStrings.dueAmount(isEnglish) + " *") },
                    placeholder = { Text(if (isEnglish) "Amount in Taka" else "টাকার পরিমাণ লিখুন") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 56.dp),
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    colors = universalTextFieldColors(isDarkMode)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isEnglish) "Description & Items (+ icon):" else "বাকির বিবরণ ও মালামাল (+ আইকন):",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    IconButton(
                        onClick = {
                            descriptionList = descriptionList + ""
                        },
                        modifier = Modifier
                            .size(30.dp)
                            .background(Color(0xFF2E7D32), CircleShape)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add Box", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                descriptionList.forEachIndexed { index, desc ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = desc,
                            onValueChange = { newText ->
                                val updated = descriptionList.toMutableList()
                                updated[index] = newText
                                descriptionList = updated
                            },
                            label = {
                                Text(if (isEnglish) "Item/Note ${index + 1}" else "বিবরণ ${index + 1}")
                            },
                            placeholder = {
                                Text(
                                    if (index == 0) (if (isEnglish) "1. Rice, Oil..." else "১. চাল, তেল...")
                                    else if (index == 1) (if (isEnglish) "2. Soap, Biscuits..." else "২. সাবান, বিস্কুট...")
                                    else (if (isEnglish) "Details..." else "বিবরণ...")
                                )
                            },
                            modifier = Modifier.weight(1f).defaultMinSize(minHeight = 52.dp),
                            textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                            shape = RoundedCornerShape(10.dp),
                            colors = universalTextFieldColors(isDarkMode)
                        )
                        if (descriptionList.size > 1) {
                            IconButton(
                                onClick = {
                                    val updated = descriptionList.toMutableList()
                                    updated.removeAt(index)
                                    descriptionList = updated
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Remove", tint = Color.Gray, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }

                TextButton(
                    onClick = { descriptionList = descriptionList + "" },
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFF2E7D32))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isEnglish) "+ Add Another Description Box" else "+ আরও বিবরণ যোগ করুন",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2E7D32)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        val parsed = amount.toDoubleOrNull()
                        if (name.isNotBlank() && phone.isNotBlank() && parsed != null && parsed > 0) {
                            val combinedNotes = descriptionList
                                .filter { it.isNotBlank() }
                                .joinToString(" | ")
                            onSave(name.trim(), phone.trim(), parsed, combinedNotes)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BkashPink),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().height(46.dp)
                ) {
                    Text(if (isEnglish) "Save Due Record" else "বাকি সংরক্ষণ করুন", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// 3. ADD & EDIT SUPPLIER MEMO DIALOG
@Composable
fun AddEditSupplierMemoDialog(
    isOpen: Boolean,
    memoToEdit: SupplierMemo? = null,
    isDarkMode: Boolean = false,
    isEnglish: Boolean = false,
    onDismiss: () -> Unit,
    onSave: (id: Long, supplier: String, memoNo: String, amount: Double, photoUri: String, note: String, memoDate: String) -> Unit
) {
    if (!isOpen) return
    val context = LocalContext.current
    val isEditing = memoToEdit != null && memoToEdit.id != 0L

    var supplier by remember(memoToEdit) { mutableStateOf(memoToEdit?.supplierName ?: "") }
    var memoNo by remember(memoToEdit) { mutableStateOf(memoToEdit?.memoNo ?: "") }
    var amount by remember(memoToEdit) { mutableStateOf(memoToEdit?.amount?.toInt()?.toString() ?: "") }
    var note by remember(memoToEdit) { mutableStateOf(memoToEdit?.note ?: "") }
    var photoUriString by remember(memoToEdit) { mutableStateOf(memoToEdit?.photoUri ?: "") }
    var memoDate by remember(memoToEdit) {
        mutableStateOf(memoToEdit?.date ?: SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()))
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            photoUriString = uri.toString()
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isEditing) AppStrings.editMemo(isEnglish) else AppStrings.addMemo(isEnglish),
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1976D2),
                        fontSize = 16.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = supplier,
                    onValueChange = { supplier = it },
                    label = { Text(AppStrings.supplierName(isEnglish) + " *") },
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 56.dp),
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    colors = universalTextFieldColors(isDarkMode)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = memoNo,
                    onValueChange = { memoNo = it },
                    label = { Text(AppStrings.memoNo(isEnglish) + " *") },
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 56.dp),
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    colors = universalTextFieldColors(isDarkMode)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = memoDate,
                    onValueChange = { memoDate = it },
                    label = { Text(AppStrings.memoArrivalDate(isEnglish) + " *") },
                    placeholder = { Text("DD/MM/YYYY") },
                    trailingIcon = {
                        IconButton(onClick = {
                            val cal = Calendar.getInstance()
                            DatePickerDialog(
                                context,
                                { _, year, month, dayOfMonth ->
                                    val picked = Calendar.getInstance().apply { set(year, month, dayOfMonth) }
                                    memoDate = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(picked.time)
                                },
                                cal.get(Calendar.YEAR),
                                cal.get(Calendar.MONTH),
                                cal.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        }) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = "Pick Date", tint = Color(0xFF1976D2))
                        }
                    },
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 56.dp),
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    colors = universalTextFieldColors(isDarkMode)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text(AppStrings.memoAmount(isEnglish) + " *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 56.dp),
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    colors = universalTextFieldColors(isDarkMode)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text(if (isEnglish) "Purchase Items Note" else "মাল ক্রয়ের বিবরণ") },
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 56.dp),
                    textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    colors = universalTextFieldColors(isDarkMode)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = AppStrings.attachMemoPhoto(isEnglish) + ":",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(6.dp))

                if (photoUriString.isNotBlank()) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isDarkMode) Color(0xFF2C2C2C) else Color(0xFFF1F5F9))
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp).fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AsyncImage(
                                    model = photoUriString,
                                    contentDescription = "Attached Memo Photo",
                                    modifier = Modifier.size(52.dp),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = if (isEnglish) "Photo Attached" else "রসিদের ছবি যুক্ত আছে",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF2E7D32)
                                    )
                                    Text(
                                        text = if (isEnglish) "Tap X to change or remove" else "ছবি পরিবর্তন করতে X চাপুন",
                                        fontSize = 10.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                            IconButton(onClick = { photoUriString = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color.Red)
                            }
                        }
                    }
                } else {
                    OutlinedButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier.fillMaxWidth().height(42.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Color(0xFF1976D2), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isEnglish) "Attach Slip Image" else "মেমো রসিদের ছবি তুলুন / যুক্ত করুন",
                            fontSize = 11.5.sp,
                            color = Color(0xFF1976D2),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val parsed = amount.toDoubleOrNull()
                        if (supplier.isNotBlank() && memoNo.isNotBlank() && parsed != null && parsed > 0) {
                            val finalDate = memoDate.ifBlank {
                                SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
                            }
                            onSave(memoToEdit?.id ?: 0L, supplier.trim(), memoNo.trim(), parsed, photoUriString, note.trim(), finalDate)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().height(46.dp)
                ) {
                    Text(
                        text = if (isEditing) (if (isEnglish) "Update Memo" else "মেমো আপডেট করুন")
                        else (if (isEnglish) "Save Memo" else "মেমো সংরক্ষণ করুন"),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// 4. PROFILE & STORE SETTINGS DIALOG
@Composable
fun ProfileSettingsDialog(
    isOpen: Boolean,
    currentProfile: StoreProfile,
    isDarkMode: Boolean = false,
    isEnglish: Boolean = false,
    onDismiss: () -> Unit,
    onSave: (StoreProfile) -> Unit
) {
    if (!isOpen) return

    var shopName by remember(currentProfile) { mutableStateOf(currentProfile.shopName) }
    var address by remember(currentProfile) { mutableStateOf(currentProfile.address) }
    var bossName by remember(currentProfile) { mutableStateOf(currentProfile.bossName) }
    var phone by remember(currentProfile) { mutableStateOf(currentProfile.phone) }
    var email by remember(currentProfile) { mutableStateOf(currentProfile.email) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = AppStrings.profileSettings(isEnglish),
                        fontWeight = FontWeight.Bold,
                        color = BkashPink,
                        fontSize = 16.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = shopName,
                    onValueChange = { shopName = it },
                    label = { Text(if (isEnglish) "Shop Name" else "দোকানের নাম") },
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 56.dp),
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    colors = universalTextFieldColors(isDarkMode)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text(if (isEnglish) "Shop Address" else "দোকানের ঠিকানা") },
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 56.dp),
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    colors = universalTextFieldColors(isDarkMode)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = bossName,
                    onValueChange = { bossName = it },
                    label = { Text(if (isEnglish) "Proprietor Name" else "মালিকের নাম") },
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 56.dp),
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    colors = universalTextFieldColors(isDarkMode)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text(if (isEnglish) "Official Phone" else "অফিসিয়াল মোবাইল নম্বর") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 56.dp),
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    colors = universalTextFieldColors(isDarkMode)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text(if (isEnglish) "Store Email / Gmail" else "জিমেইল / ইমেইল আইডি") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 56.dp),
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    colors = universalTextFieldColors(isDarkMode)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        onSave(
                            currentProfile.copy(
                                shopName = shopName.trim(),
                                address = address.trim(),
                                bossName = bossName.trim(),
                                phone = phone.trim(),
                                email = email.trim()
                            )
                        )
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BkashPink),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().height(46.dp)
                ) {
                    Text(if (isEnglish) "Save Store Profile" else "প্রোফাইল সংরক্ষণ করুন", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// 5. PIN & SECURITY SETTINGS DIALOG (With App Launch Priority & Biometric Settings)
@Composable
fun PinSecurityDialog(
    isOpen: Boolean,
    currentRole: String = "owner",
    isDarkMode: Boolean = false,
    isEnglish: Boolean = false,
    isMasterLockEnabled: Boolean = true,
    currentQuestion: String = "What is your pet's name?",
    currentAnswer: String = "",
    isBiometricAvailable: Boolean = false,
    isBiometricEnabled: Boolean = false,
    currentAutoLockMinutes: Int = 0,
    currentAutoLockType: String = "INSTANT",
    currentLaunchPriority: String = "FINGERPRINT_FIRST", // REQUIREMENT 9
    onDismiss: () -> Unit,
    onChangePin: ((oldPin: String, newPin: String) -> Boolean)? = null,
    onSaveSecuritySettings: ((newPin: String?, question: String, answer: String, masterLockEnabled: Boolean, biometricEnabled: Boolean, autoLockTime: Int, lockType: String, launchPriority: String) -> Boolean)? = null
) {
    if (!isOpen) return

    val context = LocalContext.current
    var masterLockState by remember { mutableStateOf(isMasterLockEnabled) }
    var biometricState by remember { mutableStateOf(isBiometricEnabled) }
    var lockTypeState by remember { mutableStateOf(currentAutoLockType) }
    var launchPriorityState by remember { mutableStateOf(currentLaunchPriority) } // REQUIREMENT 9
    var manualMinutesInput by remember { mutableStateOf(if (currentAutoLockMinutes > 0) currentAutoLockMinutes.toString() else "3") }

    val presetQuestions = remember(isEnglish) {
        if (isEnglish) {
            listOf(
                "What is your pet's name?",
                "Favorite shop location?",
                "What was your childhood nickname?",
                "What was the name of your first school?",
                "Custom Question..."
            )
        } else {
            listOf(
                "আপনার পোষা প্রাণীর নাম কি?",
                "আপনার প্রিয় বাজারের নাম কি?",
                "আপনার ছোটবেলার ডাকনাম কি?",
                "আপনার প্রথম স্কুলের নাম কি?",
                "নিজে প্রশ্ন লিখুন..."
            )
        }
    }

    val isCurrentPreset = presetQuestions.any { it.equals(currentQuestion, ignoreCase = true) }
    var isCustomSelected by remember { mutableStateOf(!isCurrentPreset || currentQuestion.startsWith("Custom") || currentQuestion.startsWith("নিজে")) }
    var selectedQuestion by remember { mutableStateOf(if (isCurrentPreset) currentQuestion else presetQuestions.first()) }
    var customQuestionText by remember { mutableStateOf(if (!isCurrentPreset) currentQuestion else "") }
    var secretAnswer by remember { mutableStateOf(currentAnswer) }

    var oldPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = AppStrings.appLockSettings(isEnglish),
                            fontWeight = FontWeight.Bold,
                            color = BkashPink,
                            fontSize = 15.sp
                        )
                        Text(
                            text = if (isEnglish) "Master Lock, Launch Priority & Fingerprint" else "মাস্টার লক, অগ্রাধিকার ও ফিঙ্গারপ্রিন্ট",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // MASTER TOGGLE SWITCH
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (masterLockState) {
                            if (isDarkMode) Color(0xFF2C1E2B) else Color(0xFFFFEBEE)
                        } else {
                            if (isDarkMode) Color(0xFF202020) else Color(0xFFF1F5F9)
                        }
                    ),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, if (masterLockState) BkashPink else Color(0xFFBDBDBD))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Surface(
                                shape = CircleShape,
                                color = if (masterLockState) BkashPink else Color.Gray,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Shield,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = AppStrings.appLockMasterToggle(isEnglish),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (masterLockState) {
                                        if (isEnglish) "App lock active (PIN/Fingerprint protected)" else "অ্যাপ লক সক্রিয় (পিন/ফিঙ্গারপ্রিন্ট সুরক্ষিত)"
                                    } else {
                                        if (isEnglish) "App lock turned off completely" else "অ্যাপ লক সম্পূর্ণ বন্ধ রয়েছে"
                                    },
                                    fontSize = 10.5.sp,
                                    color = if (masterLockState) BkashPink else Color.Gray
                                )
                            }
                        }
                        Switch(
                            checked = masterLockState,
                            onCheckedChange = { masterLockState = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = BkashPink,
                                uncheckedThumbColor = Color.LightGray,
                                uncheckedTrackColor = Color.Gray
                            )
                        )
                    }
                }

                if (masterLockState) {
                    Spacer(modifier = Modifier.height(12.dp))

                    // REQUIREMENT 9: APP LAUNCH PRIORITY SETTING
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isDarkMode) Color(0xFF1E2835) else Color(0xFFEFF6FF)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isDarkMode) Color(0xFF2A4365) else Color(0xFFBFDBFE))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Key, contentDescription = null, tint = Color(0xFF1976D2), modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = AppStrings.launchLockPriority(isEnglish) + ":",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = if (isDarkMode) Color(0xFF90CAF9) else Color(0xFF1D4ED8)
                                )
                            }
                            Text(
                                text = if (isEnglish) "Which security prompt should appear first when opening the app?"
                                else "অ্যাপ চালু করার সময় প্রথমে কোনটি সামনে আসবে?",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            // Option 1: Fingerprint First
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { launchPriorityState = "FINGERPRINT_FIRST" }
                                    .padding(vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = launchPriorityState == "FINGERPRINT_FIRST",
                                    onClick = { launchPriorityState = "FINGERPRINT_FIRST" },
                                    colors = RadioButtonDefaults.colors(selectedColor = BkashPink)
                                )
                                Column {
                                    Text(
                                        text = AppStrings.fingerprintFirst(isEnglish),
                                        fontSize = 12.sp,
                                        fontWeight = if (launchPriorityState == "FINGERPRINT_FIRST") FontWeight.Bold else FontWeight.Normal,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = if (isEnglish) "Show fingerprint scan immediately on app launch"
                                        else "অ্যাপ খোলার সাথে সাথে সরাসরি ফিঙ্গারপ্রিন্ট সেন্সর আসবে",
                                        fontSize = 9.5.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                            // Option 2: PIN First
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { launchPriorityState = "PIN_FIRST" }
                                    .padding(vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = launchPriorityState == "PIN_FIRST",
                                    onClick = { launchPriorityState = "PIN_FIRST" },
                                    colors = RadioButtonDefaults.colors(selectedColor = BkashPink)
                                )
                                Column {
                                    Text(
                                        text = AppStrings.pinFirst(isEnglish),
                                        fontSize = 12.sp,
                                        fontWeight = if (launchPriorityState == "PIN_FIRST") FontWeight.Bold else FontWeight.Normal,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = if (isEnglish) "Show 4-digit keypad first with manual fingerprint button"
                                        else "আগে ৪-সংখ্যার পিন প্যাড আসবে, প্রয়োজনে ফিঙ্গারপ্রিন্ট বাটন",
                                        fontSize = 9.5.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // BIOMETRIC (FINGERPRINT) TOGGLE
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isDarkMode) Color(0xFF333333) else Color(0xFFE2E8F0))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.Fingerprint, contentDescription = null, tint = BkashPink, modifier = Modifier.size(22.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = AppStrings.biometricFingerprint(isEnglish),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = if (isEnglish) "Quick unlock using device fingerprint sensor" else "ডিভাইসের আঙুলের ছাপ দিয়ে দ্রুত আনলক করুন",
                                        fontSize = 10.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                            Switch(
                                checked = biometricState,
                                onCheckedChange = { biometricState = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = BkashPink)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // CONFIGURABLE AUTO-LOCK TIMEOUT
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = if (isDarkMode) Color(0xFF1E2835) else Color(0xFFF8FAFC)),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isDarkMode) Color(0xFF333333) else Color(0xFFE2E8F0))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = AppStrings.autoLockTimeout(isEnglish) + ":",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color(0xFF1976D2)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { lockTypeState = "INSTANT" }
                                    .padding(vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = lockTypeState == "INSTANT",
                                    onClick = { lockTypeState = "INSTANT" },
                                    colors = RadioButtonDefaults.colors(selectedColor = BkashPink)
                                )
                                Text(
                                    text = AppStrings.autoLockInstant(isEnglish),
                                    fontSize = 12.sp,
                                    fontWeight = if (lockTypeState == "INSTANT") FontWeight.Bold else FontWeight.Normal,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { lockTypeState = "DEVICE_LOCK" }
                                    .padding(vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = lockTypeState == "DEVICE_LOCK",
                                    onClick = { lockTypeState = "DEVICE_LOCK" },
                                    colors = RadioButtonDefaults.colors(selectedColor = BkashPink)
                                )
                                Text(
                                    text = AppStrings.autoLockDeviceLock(isEnglish),
                                    fontSize = 12.sp,
                                    fontWeight = if (lockTypeState == "DEVICE_LOCK") FontWeight.Bold else FontWeight.Normal,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { lockTypeState = "MINUTES" }
                                    .padding(vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = lockTypeState == "MINUTES",
                                    onClick = { lockTypeState = "MINUTES" },
                                    colors = RadioButtonDefaults.colors(selectedColor = BkashPink)
                                )
                                Text(
                                    text = if (isEnglish) "After inactivity (Custom minutes)" else "নির্দিষ্ট মিনিট নিষ্ক্রিয় থাকলে",
                                    fontSize = 12.sp,
                                    fontWeight = if (lockTypeState == "MINUTES") FontWeight.Bold else FontWeight.Normal,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            if (lockTypeState == "MINUTES") {
                                Spacer(modifier = Modifier.height(6.dp))
                                Column(modifier = Modifier.padding(start = 32.dp)) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        listOf(1, 3, 5, 10).forEach { m ->
                                            Surface(
                                                shape = RoundedCornerShape(12.dp),
                                                color = if (manualMinutesInput == m.toString()) BkashPink else (if (isDarkMode) Color(0xFF333333) else Color(0xFFE2E8F0)),
                                                modifier = Modifier.clickable { manualMinutesInput = m.toString() }
                                            ) {
                                                Text(
                                                    text = "$m মিনিট",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (manualMinutesInput == m.toString()) Color.White else MaterialTheme.colorScheme.onSurface,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    OutlinedTextField(
                                        value = manualMinutesInput,
                                        onValueChange = { manualMinutesInput = it },
                                        label = { Text(if (isEnglish) "Minutes (e.g. 1, 3, 5)" else "মিনিট লিখুন") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                                        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 54.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = universalTextFieldColors(isDarkMode)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // CHANGE PIN SECTION
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isDarkMode) Color(0xFF333333) else Color(0xFFE2E8F0))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = if (isEnglish) "Update 4-Digit PIN (Optional):" else "৪-সংখ্যার পিন পরিবর্তন (ঐচ্ছিক):",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = BkashPink
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = oldPin,
                                onValueChange = { if (it.length <= 4) oldPin = it },
                                label = { Text(if (isEnglish) "Current PIN (Verify)" else "বর্তমান পিন (যাচাই করুন)", fontSize = 11.sp) },
                                visualTransformation = PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                singleLine = true,
                                textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                                modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 54.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = universalTextFieldColors(isDarkMode)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = newPin,
                                onValueChange = { if (it.length <= 4) newPin = it },
                                label = { Text(if (isEnglish) "New 4-Digit PIN" else "নতুন ৪-সংখ্যার পিন", fontSize = 11.sp) },
                                visualTransformation = PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                singleLine = true,
                                textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                                modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 54.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = universalTextFieldColors(isDarkMode)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // SECURITY QUESTION & RECOVERY ANSWER
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = if (isDarkMode) Color(0xFF1E2835) else Color(0xFFEFF6FF)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = if (isEnglish) "Security Question (PIN Recovery):" else "নিরাপত্তা প্রশ্ন (পিন পুনরুদ্ধারের জন্য):",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (isDarkMode) Color(0xFF90CAF9) else Color(0xFF1D4ED8)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            presetQuestions.forEach { q ->
                                val isSelected = (!isCustomSelected && selectedQuestion == q) || (isCustomSelected && (q.startsWith("Custom") || q.startsWith("নিজে")))
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (q.startsWith("Custom") || q.startsWith("নিজে")) {
                                                isCustomSelected = true
                                            } else {
                                                isCustomSelected = false
                                                selectedQuestion = q
                                            }
                                        }
                                        .padding(vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = {
                                            if (q.startsWith("Custom") || q.startsWith("নিজে")) {
                                                isCustomSelected = true
                                            } else {
                                                isCustomSelected = false
                                                selectedQuestion = q
                                            }
                                        },
                                        colors = RadioButtonDefaults.colors(selectedColor = BkashPink)
                                    )
                                    Text(
                                        text = q,
                                        fontSize = 11.5.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }

                            if (isCustomSelected) {
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = customQuestionText,
                                    onValueChange = { customQuestionText = it },
                                    placeholder = { Text(if (isEnglish) "Type custom security question..." else "নিজের গোপন প্রশ্নটি লিখুন...", fontSize = 11.sp) },
                                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 54.dp),
                                    singleLine = true,
                                    textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = universalTextFieldColors(isDarkMode)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (isEnglish) "Secret Answer:" else "গোপন উত্তর:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = secretAnswer,
                                onValueChange = { secretAnswer = it },
                                placeholder = { Text(if (isEnglish) "Enter secret answer..." else "গোপন উত্তর লিখুন...", fontSize = 11.sp) },
                                singleLine = true,
                                textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                                modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 54.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = universalTextFieldColors(isDarkMode)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val finalQuestion = if (isCustomSelected) customQuestionText.ifBlank { "What is your pet's name?" } else selectedQuestion
                        val finalAnswer = secretAnswer.trim()
                        if (masterLockState && finalAnswer.isBlank()) {
                            Toast.makeText(context, if (isEnglish) "Please enter a secret answer!" else "গোপন উত্তর প্রদান করুন!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (newPin.isNotBlank()) {
                            if (newPin.length != 4) {
                                Toast.makeText(context, if (isEnglish) "New PIN must be 4 digits!" else "নতুন পিন ৪ সংখ্যার হতে হবে!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (onChangePin != null && !onChangePin(oldPin, newPin)) {
                                Toast.makeText(context, if (isEnglish) "Current PIN is incorrect!" else "বর্তমান পিনটি সঠিক নয়!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                        }

                        val mins = manualMinutesInput.toIntOrNull() ?: 1
                        onSaveSecuritySettings?.invoke(
                            newPin.takeIf { it.isNotBlank() },
                            finalQuestion,
                            finalAnswer,
                            masterLockState,
                            biometricState,
                            mins,
                            lockTypeState,
                            launchPriorityState
                        )
                        Toast.makeText(context, if (isEnglish) "Security settings saved!" else "নিরাপত্তা সেটিংস সংরক্ষিত হয়েছে!", Toast.LENGTH_SHORT).show()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BkashPink),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().height(46.dp)
                ) {
                    Text(if (isEnglish) "Save Security Settings" else "নিরাপত্তা সেটিংস সংরক্ষণ করুন", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}
