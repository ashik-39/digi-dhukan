package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.CartItem
import com.example.ui.MainViewModel
import com.example.ui.theme.AlertRed
import com.example.ui.theme.BkashPink
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.universalTextFieldColors
import com.example.util.normalizeDigits

@Composable
fun CartModal(
    viewModel: MainViewModel,
    isOpen: Boolean,
    isDarkMode: Boolean = false,
    isEnglish: Boolean = false,
    onDismiss: () -> Unit
) {
    if (!isOpen) return

    val cartItems by viewModel.cart.collectAsState()
    var customerPhone by remember { mutableStateOf("") }
    val grandTotal = remember(cartItems) { cartItems.sumOf { it.totalCost } }

    // REQUIREMENT 5: Tap to edit middle quantity in Cart
    var editingItem by remember { mutableStateOf<CartItem?>(null) }
    var typedQtyInput by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = BkashPink, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isEnglish) "Shopping Cart & Billing" else "শপিং কার্ট ও বিক্রয় বিল",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = BkashPink
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (cartItems.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(if (isEnglish) "Your cart is empty!" else "কার্ট সম্পূর্ণ খালি!", color = Color.Gray, fontSize = 14.sp)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(cartItems, key = { it.product.id }) { item ->
                            Card(
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = if (isDarkMode) Color(0xFF242424) else Color(0xFFF9F9F9)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1.5f)) {
                                        Text(
                                            text = item.product.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            maxLines = 1,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "৳ ${item.product.sellPrice.toInt()} x ${item.quantity} = ৳ ${item.totalCost.toInt()}",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            shape = CircleShape,
                                            color = if (isDarkMode) Color(0xFF333333) else Color(0xFFE0E0E0),
                                            modifier = Modifier.size(26.dp)
                                        ) {
                                            IconButton(
                                                onClick = { viewModel.updateCartQuantity(item.product.id, -1) },
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Icon(Icons.Default.Remove, contentDescription = "Minus", modifier = Modifier.size(14.dp))
                                            }
                                        }

                                        // REQUIREMENT 5: Tap-to-edit middle quantity number
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (isDarkMode) Color(0xFF333333) else Color(0xFFF1F5F9),
                                            border = BorderStroke(1.dp, BkashPink.copy(alpha = 0.5f)),
                                            modifier = Modifier
                                                .padding(horizontal = 6.dp)
                                                .clickable {
                                                    editingItem = item
                                                    typedQtyInput = item.quantity.toString()
                                                }
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            ) {
                                                Text(
                                                    text = "${item.quantity}",
                                                    fontWeight = FontWeight.ExtraBold,
                                                    fontSize = 13.sp,
                                                    color = BkashPink
                                                )
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Icon(
                                                    imageVector = Icons.Default.Edit,
                                                    contentDescription = "Edit quantity",
                                                    tint = BkashPink,
                                                    modifier = Modifier.size(11.dp)
                                                )
                                            }
                                        }

                                        Surface(
                                            shape = CircleShape,
                                            color = BkashPink.copy(alpha = 0.15f),
                                            modifier = Modifier.size(26.dp)
                                        ) {
                                            IconButton(
                                                onClick = { viewModel.updateCartQuantity(item.product.id, 1) },
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Icon(Icons.Default.Add, contentDescription = "Plus", tint = BkashPink, modifier = Modifier.size(14.dp))
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(6.dp))

                                        IconButton(
                                            onClick = { viewModel.removeFromCart(item.product.id) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "Remove", tint = AlertRed, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // REQUIREMENT 8: High contrast OutlinedTextField with minHeight 56dp (no clipping)
                    OutlinedTextField(
                        value = customerPhone,
                        onValueChange = { customerPhone = it },
                        label = { Text(if (isEnglish) "Customer Mobile (Optional)" else "কাস্টমারের মোবাইল (ঐচ্ছিক)") },
                        placeholder = { Text("01XXXXXXXXX") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        textStyle = TextStyle(
                            fontSize = 14.sp,
                            color = if (isDarkMode) Color.White else Color.Black
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 56.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = universalTextFieldColors(isDarkMode)
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = if (isDarkMode) Color(0xFF333333) else Color(0xFFEEEEEE))
                    Spacer(modifier = Modifier.height(8.dp))

                    // Total Bill
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (isEnglish) "Total Bill:" else "সর্বমোট বিল (Total):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            text = "৳ ${grandTotal.toInt()}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = SuccessGreen
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.clearCart() },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(0.8f)
                        ) {
                            Text(if (isEnglish) "Clear" else "কার্ট খালি", color = Color.Gray, fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                viewModel.completeCheckout(customerPhone)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BkashPink),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1.4f)
                        ) {
                            Text(if (isEnglish) "Complete Sale & Receipt" else "বিক্রি সম্পন্ন ও রসিদ তৈরি", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }

    // REQUIREMENT 5: Manual Quantity Typing Dialog with available stock validation
    if (editingItem != null) {
        val target = editingItem!!
        val enteredInt = typedQtyInput.toIntOrNull()
        val isExceeding = enteredInt != null && enteredInt > target.product.stock
        val isZeroOrNegative = enteredInt != null && enteredInt <= 0
        val isInvalid = typedQtyInput.isBlank() || enteredInt == null || isExceeding || isZeroOrNegative

        Dialog(onDismissRequest = { editingItem = null }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = if (isEnglish) "Type Exact Quantity" else "নির্দিষ্ট পরিমাণ লিখুন",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = BkashPink
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${target.product.name} (স্টকে আছে: ${target.product.stock} টি)",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = typedQtyInput,
                        onValueChange = { input ->
                            typedQtyInput = input.normalizeDigits().filter { it.isDigit() }
                        },
                        label = { Text(if (isEnglish) "Quantity" else "পরিমাণ (পিস)") },
                        placeholder = { Text("যেমন: ২৫ বা ১০০...") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        isError = isExceeding,
                        supportingText = {
                            if (isExceeding) {
                                Text(
                                    text = if (isEnglish) 
                                        "⚠️ Cannot exceed stock (${target.product.stock})!" 
                                    else 
                                        "⚠️ স্টকের চেয়ে বেশি দেওয়া যাবে না (আছে মাত্র ${target.product.stock} টি)!",
                                    color = AlertRed,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            } else {
                                Text(
                                    text = if (isEnglish) "Available stock: ${target.product.stock} pcs" else "বর্তমান স্টক: ${target.product.stock} টি",
                                    fontSize = 10.5.sp
                                )
                            }
                        },
                        textStyle = TextStyle(
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDarkMode) Color.White else Color.Black
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 56.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = universalTextFieldColors(isDarkMode)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { editingItem = null }) {
                            Text(if (isEnglish) "Cancel" else "বাতিল")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val finalQty = enteredInt ?: 1
                                if (finalQty in 1..target.product.stock) {
                                    viewModel.setCartQuantity(target.product.id, finalQty)
                                    editingItem = null
                                }
                            },
                            enabled = !isInvalid,
                            colors = ButtonDefaults.buttonColors(containerColor = BkashPink),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(if (isEnglish) "Save Quantity" else "সেভ করুন")
                        }
                    }
                }
            }
        }
    }
}
