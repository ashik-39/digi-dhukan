package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CartItem
import com.example.data.Product
import com.example.data.SaleTransaction
import com.example.data.StoreProfile
import com.example.ui.MainViewModel
import com.example.ui.ReportPeriodFilter
import com.example.ui.components.ReceiptDialog
import com.example.ui.theme.AlertRed
import com.example.ui.theme.BkashPink
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.universalTextFieldColors
import com.example.util.AppStrings
import com.example.util.PdfReportGenerator
import com.example.util.ReceiptData
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun SalesReportTab(
    viewModel: MainViewModel,
    isDarkMode: Boolean = false,
    isEnglish: Boolean = false
) {
    val context = LocalContext.current
    val allTransactions by viewModel.transactions.collectAsState()
    val isLiveChartEnabled by viewModel.isLiveChartEnabled.collectAsState()
    val selectedTransactionIds by viewModel.selectedTransactionIds.collectAsState()
    val filter by viewModel.salesFilter.collectAsState()
    val customStartDate by viewModel.customStartDate.collectAsState()
    val customEndDate by viewModel.customEndDate.collectAsState()
    val salesSearchQuery by viewModel.salesSearchQuery.collectAsState()
    val storeProfile by viewModel.storeProfile.collectAsState()
    val dues by viewModel.dues.collectAsState()
    val memos by viewModel.memos.collectAsState()
    val products by viewModel.products.collectAsState()

    var showDeleteConfirmation by remember { mutableStateOf(false) }
    var selectedReceiptForModal by remember { mutableStateOf<ReceiptData?>(null) }

    val todayStr = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()) }
    val yesterdayStr = remember {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -1)
        SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(cal.time)
    }
    val currentMonthStr = remember { SimpleDateFormat("/MM/yyyy", Locale.getDefault()).format(Date()) }
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }

    val filteredTransactions = remember(allTransactions, filter, customStartDate, customEndDate, salesSearchQuery) {
        val dateFiltered = when (filter) {
            ReportPeriodFilter.ALL -> allTransactions
            ReportPeriodFilter.TODAY -> allTransactions.filter { it.dateFormatted.startsWith(todayStr) }
            ReportPeriodFilter.YESTERDAY -> allTransactions.filter { it.dateFormatted.startsWith(yesterdayStr) }
            ReportPeriodFilter.THIS_MONTH -> allTransactions.filter { it.dateFormatted.contains(currentMonthStr) }
            ReportPeriodFilter.CUSTOM_DATE_RANGE -> {
                if (customStartDate.isNotBlank() && customEndDate.isNotBlank()) {
                    try {
                        val sDate = dateFormat.parse(customStartDate)?.time ?: 0L
                        val eDate = (dateFormat.parse(customEndDate)?.time ?: Long.MAX_VALUE) + 86400000L - 1L
                        allTransactions.filter { txn ->
                            val txnDateStr = txn.dateFormatted.split(" ").firstOrNull() ?: ""
                            val txnTime = try {
                                dateFormat.parse(txnDateStr)?.time ?: txn.timestamp
                            } catch (e: Exception) {
                                txn.timestamp
                            }
                            txnTime in sDate..eDate
                        }
                    } catch (e: Exception) {
                        allTransactions
                    }
                } else if (customStartDate.isNotBlank()) {
                    allTransactions.filter { it.dateFormatted.startsWith(customStartDate) }
                } else {
                    allTransactions
                }
            }
        }

        if (salesSearchQuery.isBlank()) {
            dateFiltered
        } else {
            dateFiltered.filter { txn ->
                txn.id.toString().contains(salesSearchQuery, ignoreCase = true) ||
                        txn.itemsSummary.contains(salesSearchQuery, ignoreCase = true) ||
                        txn.customerPhone.contains(salesSearchQuery, ignoreCase = true)
            }
        }
    }

    val totalSales = remember(filteredTransactions) { filteredTransactions.sumOf { it.totalAmount } }
    val totalProfit = remember(filteredTransactions) { filteredTransactions.sumOf { it.totalProfit } }
    val transactionCount = remember(filteredTransactions) { filteredTransactions.size }

    val calendar = Calendar.getInstance()
    val startDatePickerDialog = remember {
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val selectedCal = Calendar.getInstance().apply { set(year, month, dayOfMonth) }
                val formatted = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(selectedCal.time)
                viewModel.customStartDate.value = formatted
                viewModel.salesFilter.value = ReportPeriodFilter.CUSTOM_DATE_RANGE
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
    }

    val endDatePickerDialog = remember {
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val selectedCal = Calendar.getInstance().apply { set(year, month, dayOfMonth) }
                val formatted = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(selectedCal.time)
                viewModel.customEndDate.value = formatted
                viewModel.salesFilter.value = ReportPeriodFilter.CUSTOM_DATE_RANGE
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))

            // Main Title & PDF Download Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = BkashPink.copy(alpha = 0.15f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Assessment, contentDescription = null, tint = BkashPink, modifier = Modifier.size(20.dp))
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (isEnglish) "Sales & Account Report" else "বিক্রয় ও হিসাব নিকাশ",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = if (isEnglish) "Export in PDF & JPG formats" else "PDF এবং JPG ফরম্যাটে ডাউনলোড",
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 1-CLICK COMPREHENSIVE 1-MONTH MONTHLY REPORT EXPORT CARD
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDarkMode) Color(0xFF1E2835) else Color(0xFFEFF6FF)
                ),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, if (isDarkMode) Color(0xFF2A4365) else Color(0xFF90CAF9)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF1976D2),
                            modifier = Modifier.size(28.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = AppStrings.downloadMonthlySummary(isEnglish),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp,
                                color = if (isDarkMode) Color(0xFF90CAF9) else Color(0xFF1D4ED8)
                            )
                            Text(
                                text = if (isEnglish)
                                    "1-Click Export: Full store ledger, sales summary, memos with slip photos & due book"
                                else
                                    "১ ক্লিকে সম্পূর্ণ দোকান হিসাব, পাইকারি মেমো ভাউচার ও বাকি খাতার বিবরণ",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // 1-Click PDF Download Button
                        Button(
                            onClick = {
                                viewModel.exportMonthlySummaryPdf(context)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f).height(42.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isEnglish) "Download PDF" else "পূর্ণাঙ্গ PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        // 1-Click JPG Download Button
                        Button(
                            onClick = {
                                com.example.util.ReportImageGenerator.saveAndShareReportJpg(
                                    context = context,
                                    storeProfile = storeProfile,
                                    transactions = allTransactions,
                                    dues = dues,
                                    memos = memos,
                                    products = products,
                                    isEnglish = isEnglish,
                                    reportTitle = if (isEnglish) "1-Month Sales & Account Report" else "১ মাসের পূর্ণাঙ্গ বিক্রয় ও দোকান হিসাব রিপোর্ট"
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00796B)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f).height(42.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isEnglish) "Download JPG" else "পূর্ণাঙ্গ JPG", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Preset Date Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChipPill(
                    label = if (isEnglish) "All Time" else "সব সময়",
                    isSelected = filter == ReportPeriodFilter.ALL,
                    onClick = {
                        viewModel.salesFilter.value = ReportPeriodFilter.ALL
                        viewModel.customStartDate.value = ""
                        viewModel.customEndDate.value = ""
                    }
                )
                FilterChipPill(
                    label = if (isEnglish) "Today" else "আজকের হিসাব",
                    isSelected = filter == ReportPeriodFilter.TODAY,
                    onClick = {
                        viewModel.salesFilter.value = ReportPeriodFilter.TODAY
                        viewModel.customStartDate.value = ""
                        viewModel.customEndDate.value = ""
                    }
                )
                FilterChipPill(
                    label = if (isEnglish) "Yesterday" else "গতকালের",
                    isSelected = filter == ReportPeriodFilter.YESTERDAY,
                    onClick = {
                        viewModel.salesFilter.value = ReportPeriodFilter.YESTERDAY
                        viewModel.customStartDate.value = ""
                        viewModel.customEndDate.value = ""
                    }
                )
                FilterChipPill(
                    label = if (isEnglish) "This Month" else "চলতি মাসের",
                    isSelected = filter == ReportPeriodFilter.THIS_MONTH,
                    onClick = {
                        viewModel.salesFilter.value = ReportPeriodFilter.THIS_MONTH
                        viewModel.customStartDate.value = ""
                        viewModel.customEndDate.value = ""
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Manual Start Date & End Date Picker Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDarkMode) Color(0xFF1E2835) else Color(0xFFEFF6FF)
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isDarkMode) Color(0xFF2A4365) else Color(0xFFBFDBFE))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DateRange, contentDescription = null, tint = Color(0xFF1976D2), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isEnglish) "Manual Date Range (Start & End Date):" else "নির্দিষ্ট তারিখ অনুযায়ী ফিল্টার:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDarkMode) Color(0xFF90CAF9) else Color(0xFF1D4ED8)
                            )
                        }
                        if (customStartDate.isNotBlank() || customEndDate.isNotBlank()) {
                            TextButton(
                                onClick = {
                                    viewModel.customStartDate.value = ""
                                    viewModel.customEndDate.value = ""
                                    viewModel.salesFilter.value = ReportPeriodFilter.ALL
                                },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(AppStrings.clearFilter(isEnglish), fontSize = 10.sp, color = AlertRed, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Start Date
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isDarkMode) Color(0xFF283648) else Color.White,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (customStartDate.isNotBlank()) Color(0xFF1976D2) else Color(0xFFCBD5E1)),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .clickable { startDatePickerDialog.show() }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = Color(0xFF1976D2), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(AppStrings.startDate(isEnglish), fontSize = 8.sp, color = Color.Gray)
                                    Text(
                                        text = if (customStartDate.isNotBlank()) customStartDate else (if (isEnglish) "Pick Date" else "শুরুর তারিখ"),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (customStartDate.isNotBlank()) Color(0xFF1976D2) else Color.Gray
                                    )
                                }
                            }
                        }

                        // End Date
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isDarkMode) Color(0xFF283648) else Color.White,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (customEndDate.isNotBlank()) Color(0xFF1976D2) else Color(0xFFCBD5E1)),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .clickable { endDatePickerDialog.show() }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = Color(0xFF1976D2), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(AppStrings.endDate(isEnglish), fontSize = 8.sp, color = Color.Gray)
                                    Text(
                                        text = if (customEndDate.isNotBlank()) customEndDate else (if (isEnglish) "Pick Date" else "শেষের তারিখ"),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (customEndDate.isNotBlank()) Color(0xFF1976D2) else Color.Gray
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Quick Search Bar (Requirement 8: high contrast, minHeight 56dp)
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = salesSearchQuery,
                onValueChange = { viewModel.salesSearchQuery.value = it },
                placeholder = { Text(AppStrings.salesSearchPlaceholder(isEnglish), fontSize = 12.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = BkashPink) },
                trailingIcon = {
                    if (salesSearchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.salesSearchQuery.value = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.Gray, modifier = Modifier.size(18.dp))
                        }
                    }
                },
                singleLine = true,
                textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 56.dp),
                shape = RoundedCornerShape(10.dp),
                colors = universalTextFieldColors(isDarkMode)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // KPI Summary Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = BkashPink, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isEnglish) "Total Sales" else "মোট বিক্রয়",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "৳ ${totalSales.toInt()}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = BkashPink
                        )
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.TrendingUp, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isEnglish) "Net Profit" else "নিট লাভ",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "৳ ${totalProfit.toInt()}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = SuccessGreen
                        )
                    }
                }
            }

            // Live Sales Trend Chart
            if (isLiveChartEnabled) {
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AutoGraph, contentDescription = null, tint = BkashPink, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isEnglish) "Live Sales Trend" else "লাইভ বিক্রয় গ্রাফ",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                            Text(
                                text = "$transactionCount টি চালান",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(64.dp)
                                .background(if (isDarkMode) Color(0xFF242424) else Color(0xFFF9F9F9), RoundedCornerShape(8.dp))
                                .padding(horizontal = 14.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            val days = if (isEnglish) listOf("Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri")
                            else listOf("শনি", "রবি", "সোম", "মঙ্গল", "বুধ", "বৃহঃ", "শুক্র")
                            val heights = listOf(0.45f, 0.7f, 0.85f, 0.6f, 0.75f, 0.9f, 1.0f)
                            days.forEachIndexed { i, day ->
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(
                                        modifier = Modifier
                                            .width(18.dp)
                                            .height((heights[i] * 38).dp)
                                            .background(
                                                if (i == 6) BkashPink else BkashPink.copy(alpha = 0.5f),
                                                RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp)
                                            )
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(day, fontSize = 9.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Multi-selection & Delete Toolbar
            if (filteredTransactions.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (isDarkMode) Color(0xFF242424) else Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = selectedTransactionIds.isNotEmpty() && selectedTransactionIds.size == filteredTransactions.size,
                            onCheckedChange = { isChecked ->
                                if (isChecked) {
                                    viewModel.selectedTransactionIds.value = filteredTransactions.map { it.id }.toSet()
                                } else {
                                    viewModel.selectedTransactionIds.value = emptySet()
                                }
                            },
                            colors = CheckboxDefaults.colors(checkedColor = BkashPink)
                        )
                        Text(
                            text = if (isEnglish) "Select All (${filteredTransactions.size})" else "সব সিলেক্ট (${filteredTransactions.size} টি)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    if (selectedTransactionIds.isNotEmpty()) {
                        Button(
                            onClick = { showDeleteConfirmation = true },
                            colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isEnglish) "Delete (${selectedTransactionIds.size})" else "মুছুন (${selectedTransactionIds.size})",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            Text(
                text = if (isEnglish) "Transaction & Cash Memo Records (${filteredTransactions.size}):" else "বিক্রয় চালান ও ক্যাশ মেমোর তালিকা (${filteredTransactions.size} টি):",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(6.dp))
        }

        if (filteredTransactions.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isEnglish) "No sales records found for this period." else "এই সময়ে কোন বিক্রয় চালান পাওয়া যায়নি।",
                        color = Color.Gray,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            items(filteredTransactions, key = { it.id }) { txn ->
                val isSelected = selectedTransactionIds.contains(txn.id)
                SaleTransactionItemCard(
                    transaction = txn,
                    isSelected = isSelected,
                    isDarkMode = isDarkMode,
                    onClick = {
                        selectedReceiptForModal = txn.toReceiptData(storeProfile)
                    },
                    onToggleSelect = { viewModel.toggleTransactionSelection(txn.id) },
                    onDelete = { viewModel.deleteTransaction(txn) },
                    isEnglish = isEnglish
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(90.dp))
        }
    }

    ReceiptDialog(
        receipt = selectedReceiptForModal,
        isOpen = selectedReceiptForModal != null,
        isDarkMode = isDarkMode,
        isEnglish = isEnglish,
        onDismiss = { selectedReceiptForModal = null }
    )

    if (showDeleteConfirmation) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmation = false },
            title = { Text(if (isEnglish) "Delete Selected Invoices?" else "চালান মুছবেন?") },
            text = {
                Text(
                    if (isEnglish)
                        "Are you sure you want to delete ${selectedTransactionIds.size} selected sales invoice records?"
                    else
                        "আপনি কি নির্বাচিত ${selectedTransactionIds.size} টি বিক্রয় চালান মুছে ফেলতে চান?"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteSelectedTransactions()
                        showDeleteConfirmation = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed)
                ) {
                    Text(if (isEnglish) "Delete" else "মুছুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmation = false }) {
                    Text(if (isEnglish) "Cancel" else "বাতিল")
                }
            }
        )
    }
}

@Composable
fun FilterChipPill(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (isSelected) BkashPink else Color(0xFFF1F5F9),
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (isSelected) Color.White else Color.DarkGray,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}

@Composable
fun SaleTransactionItemCard(
    transaction: SaleTransaction,
    isSelected: Boolean,
    isDarkMode: Boolean = false,
    onClick: () -> Unit,
    onToggleSelect: () -> Unit,
    onDelete: () -> Unit,
    isEnglish: Boolean
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                if (isDarkMode) Color(0xFF3D1822) else Color(0xFFFFEBEE)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Checkbox(
                        checked = isSelected,
                        onCheckedChange = { onToggleSelect() },
                        colors = CheckboxDefaults.colors(checkedColor = BkashPink)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(Icons.Default.Receipt, contentDescription = null, tint = BkashPink, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isEnglish) "Invoice #${transaction.id}" else "চালান নং #${transaction.id}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "৳ ${transaction.totalAmount.toInt()}",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp,
                        color = SuccessGreen
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = transaction.itemsSummary.trimEnd(),
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 16.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            HorizontalDivider(color = if (isDarkMode) Color(0xFF333333) else Color(0xFFF0F0F0))
            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = transaction.dateFormatted,
                    fontSize = 10.sp,
                    color = Color.Gray
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (isDarkMode) Color(0xFF2E1738) else Color(0xFFFCE4EC),
                        modifier = Modifier.clickable { onClick() }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Icon(Icons.Default.Receipt, contentDescription = null, tint = BkashPink, modifier = Modifier.size(11.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = if (isEnglish) "Cash Memo 🧾" else "ক্যাশ মেমো 🧾",
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = BkashPink
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (isDarkMode) Color(0xFF132B18) else Color(0xFFE8F5E9)
                    ) {
                        Text(
                            text = if (isEnglish) "Profit: ৳${transaction.totalProfit.toInt()}" else "লাভ: ৳${transaction.totalProfit.toInt()}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

fun SaleTransaction.toReceiptData(storeProfile: StoreProfile): ReceiptData {
    val items = mutableListOf<CartItem>()
    val lines = itemsSummary.lines().map { it.trim() }.filter { it.isNotBlank() }

    for (line in lines) {
        try {
            if (line.contains(" x ") && line.contains(" = ")) {
                val namePart = line.substringBefore(" x ")
                val qtyPart = line.substringAfter(" x ").substringBefore(" = ").trim()
                val pricePart = line.substringAfter(" = ").replace("৳", "").trim()
                val qty = qtyPart.toIntOrNull() ?: 1
                val totalCost = pricePart.toDoubleOrNull() ?: (totalAmount / lines.size)
                items.add(
                    CartItem(
                        product = Product(barcode = "", name = namePart, buyPrice = 0.0, sellPrice = totalCost / qty, stock = 0),
                        quantity = qty
                    )
                )
            } else {
                items.add(
                    CartItem(
                        product = Product(barcode = "", name = line, buyPrice = 0.0, sellPrice = totalAmount / lines.size, stock = 0),
                        quantity = 1
                    )
                )
            }
        } catch (e: Exception) {
            items.add(
                CartItem(
                    product = Product(barcode = "", name = line, buyPrice = 0.0, sellPrice = totalAmount / lines.size, stock = 0),
                    quantity = 1
                )
            )
        }
    }

    if (items.isEmpty()) {
        items.add(
            CartItem(
                product = Product(barcode = "", name = "বিক্রয় আইটেম (#$id)", buyPrice = 0.0, sellPrice = totalAmount, stock = 0),
                quantity = 1
            )
        )
    }

    return ReceiptData(
        shopName = storeProfile.shopName.ifBlank { "Digi Dhukan" },
        address = storeProfile.address.ifBlank { "দোকানের ঠিকানা" },
        phone = storeProfile.phone,
        bossName = storeProfile.bossName,
        items = items,
        totalAmount = totalAmount,
        dateFormatted = dateFormatted,
        customerPhone = customerPhone
    )
}
