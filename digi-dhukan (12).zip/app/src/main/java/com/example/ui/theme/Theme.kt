package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightColorScheme = lightColorScheme(
    primary = BkashPink,
    onPrimary = Color.White,
    primaryContainer = BkashPinkContainer,
    onPrimaryContainer = BkashOnPinkContainer,
    secondary = AccentPurple,
    onSecondary = Color.White,
    secondaryContainer = AccentPurpleContainer,
    onSecondaryContainer = Color(0xFF2C003E),
    tertiary = SuccessGreen,
    onTertiary = Color.White,
    tertiaryContainer = SuccessGreenContainer,
    background = SurfaceBgLight,
    onBackground = TextPrimary,
    surface = CardBgLight,
    onSurface = TextPrimary,
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = TextSecondary,
    outline = Color(0xFFCBD5E1),
    error = AlertRed,
    errorContainer = AlertRedContainer
)

private val DarkColorScheme = darkColorScheme(
    primary = BkashPinkLight,
    onPrimary = Color.Black,
    primaryContainer = BkashPinkDark,
    onPrimaryContainer = Color.White,
    secondary = AccentPurple,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF3B1547),
    onSecondaryContainer = Color(0xFFF3E5F5),
    tertiary = SuccessGreenLight,
    onTertiary = Color.Black,
    background = DarkBg,
    onBackground = Color(0xFFF1F5F9),
    surface = DarkSurface,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = DarkCard,
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = DarkBorder,
    error = Color(0xFFEF5350),
    errorContainer = Color(0xFF5C0000)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
