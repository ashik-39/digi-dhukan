package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.CustomerDue
import com.example.ui.theme.AlertRed
import com.example.ui.theme.BkashPink
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.universalTextFieldColors
import com.example.util.AppStrings

@Composable
fun CustomerDueDetailDialog(
    isOpen: Boolean,
    due: CustomerDue?,
    isDarkMode: Boolean = false,
    isEnglish: Boolean = false,
    onDismiss: () -> Unit,
    onAdjustDue: (due: CustomerDue, amount: Double, note: String, isPayment: Boolean) -> Unit,
    onAddNote: (due: CustomerDue, noteItem: String) -> Unit,
    onUpdateCustomerInfo: ((due: CustomerDue, name: String, phone: String, amount: Double, note: String) -> Unit)? = null,
    onSettleFull: (due: CustomerDue) -> Unit
) {
    if (!isOpen || due == null) return
    val context = LocalContext.current

    var isEditingCustomerInfo by remember(due) { mutableStateOf(false) }
    var editName by remember(due) { mutableStateOf(due.customerName) }
    var editPhone by remember(due) { mutableStateOf(due.phone) }
    var editAmount by remember(due) { mutableStateOf(due.amount.toInt().toString()) }

    var amountInput by remember { mutableStateOf("") }
    var noteInput by remember { mutableStateOf("") }
    var descriptionBoxes by remember { mutableStateOf(listOf("")) }

    val historyList = remember(due.historyNotes, due.amount) {
        due.getHistoryList()
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header with Name & Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = BkashPink.copy(alpha = 0.15f),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = BkashPink, modifier = Modifier.size(22.dp))
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        if (!isEditingCustomerInfo) {
                            Column {
                                Text(
                                    text = due.customerName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = due.phone,
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        } else {
                            Text(
                                text = if (isEnglish) "Edit Customer Info" else "কাস্টমার তথ্য সম্পাদনা",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = BkashPink
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (!isEditingCustomerInfo) {
                            IconButton(
                                onClick = { isEditingCustomerInfo = true },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = BkashPink, modifier = Modifier.size(18.dp))
                            }
                        }
                        IconButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${due.phone}"))
                                context.startActivity(intent)
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = "Call", tint = Color(0xFF1976D2), modifier = Modifier.size(18.dp))
                        }
                        IconButton(
                            onClick = {
                                val msg = "সালামু আলাইকুম ${due.customerName}, আপনার বাকির পরিমাণ ৳${due.amount.toInt()} টাকা।"
                                val url = "https://api.whatsapp.com/send?phone=+88${due.phone}&text=${Uri.encode(msg)}"
                                try {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                } catch (e: Exception) {
                                    val smsIntent = Intent(Intent.ACTION_VIEW, Uri.parse("sms:${due.phone}")).apply {
                                        putExtra("sms_body", msg)
                                    }
                                    context.startActivity(smsIntent)
                                }
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Message, contentDescription = "WhatsApp", tint = Color(0xFF25D366), modifier = Modifier.size(18.dp))
                        }
                        IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                        }
                    }
                }

                if (isEditingCustomerInfo) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isDarkMode) Color(0xFF242424) else Color(0xFFF1F5F9))
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            OutlinedTextField(
                                value = editName,
                                onValueChange = { editName = it },
                                label = { Text(if (isEnglish) "Name" else "নাম") },
                                singleLine = true,
                                textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                                modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 56.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = universalTextFieldColors(isDarkMode)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = editPhone,
                                onValueChange = { editPhone = it },
                                label = { Text(if (isEnglish) "Phone" else "মোবাইল") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                                modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 56.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = universalTextFieldColors(isDarkMode)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = editAmount,
                                onValueChange = { editAmount = it },
                                label = { Text(if (isEnglish) "Total Due (৳)" else "মোট বাকি (৳)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                                modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 56.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = universalTextFieldColors(isDarkMode)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(onClick = { isEditingCustomerInfo = false }) {
                                    Text(if (isEnglish) "Cancel" else "বাতিল", color = Color.Gray)
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Button(
                                    onClick = {
                                        val amt = editAmount.toDoubleOrNull() ?: due.amount
                                        onUpdateCustomerInfo?.invoke(due, editName, editPhone, amt, due.note)
                                        isEditingCustomerInfo = false
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = BkashPink),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (isEnglish) "Save" else "সংরক্ষণ", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Current Total Due Display Badge
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isDarkMode) Color(0xFF381414) else Color(0xFFFFEBEE))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isEnglish) "Current Due Balance:" else "বর্তমান অবশিষ্ট বাকি:",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDarkMode) Color(0xFFFF8A80) else Color(0xFFB71C1C)
                        )
                        Text(
                            text = "৳ ${due.amount.toInt()}",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = AlertRed
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Adjustment Card (+ / - Taka)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isDarkMode) Color(0xFF202020) else Color(0xFFF8FAFC)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isDarkMode) Color(0xFF333333) else Color(0xFFE2E8F0))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = if (isEnglish) "Adjust Due Amount (+ / - Taka):" else "টাকা সমন্বয় (+ বাকি বৃদ্ধি / - জমা গ্রহণ):",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(
                                value = amountInput,
                                onValueChange = { amountInput = it },
                                placeholder = { Text(if (isEnglish) "Amount ৳" else "টাকার অঙ্ক", fontSize = 11.sp) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                                modifier = Modifier
                                    .weight(1f)
                                    .defaultMinSize(minHeight = 54.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = universalTextFieldColors(isDarkMode)
                            )
                            OutlinedTextField(
                                value = noteInput,
                                onValueChange = { noteInput = it },
                                placeholder = { Text(if (isEnglish) "Reason/Item" else "কারণ/মালামাল", fontSize = 11.sp) },
                                singleLine = true,
                                textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                                modifier = Modifier
                                    .weight(1.5f)
                                    .defaultMinSize(minHeight = 54.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = universalTextFieldColors(isDarkMode)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val amt = amountInput.toDoubleOrNull()
                                    if (amt != null && amt > 0) {
                                        onAdjustDue(due, amt, noteInput.trim(), false)
                                        amountInput = ""
                                        noteInput = ""
                                    } else {
                                        Toast.makeText(context, if (isEnglish) "Enter valid amount" else "সঠিক টাকার পরিমাণ দিন", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = BkashPink),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f).height(40.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = AppStrings.addDueAmount(isEnglish),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Button(
                                onClick = {
                                    val amt = amountInput.toDoubleOrNull()
                                    if (amt != null && amt > 0) {
                                        onAdjustDue(due, amt, noteInput.trim(), true)
                                        amountInput = ""
                                        noteInput = ""
                                    } else {
                                        Toast.makeText(context, if (isEnglish) "Enter valid amount" else "সঠিক টাকার পরিমাণ দিন", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f).height(40.dp)
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = AppStrings.subtractDueAmount(isEnglish),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // MULTIPLE NEW DESCRIPTION BOXES WITH + ICON
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isDarkMode) Color(0xFF202020) else Color(0xFFF8FAFC)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isDarkMode) Color(0xFF333333) else Color(0xFFE2E8F0))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isEnglish) "Add New Description Boxes (+):" else "নতুন বিবরণ বক্স যোগ করুন (+ আইকন):",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            IconButton(
                                onClick = {
                                    descriptionBoxes = descriptionBoxes + ""
                                },
                                modifier = Modifier
                                    .size(30.dp)
                                    .background(Color(0xFF2E7D32), CircleShape)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Add Box", tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        descriptionBoxes.forEachIndexed { index, textVal ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = textVal,
                                    onValueChange = { newVal ->
                                        val updated = descriptionBoxes.toMutableList()
                                        updated[index] = newVal
                                        descriptionBoxes = updated
                                    },
                                    placeholder = {
                                        Text(
                                            if (index == 0) (if (isEnglish) "Item 1: 5kg rice..." else "আইটেম ১: চাল ৫ কেজি...")
                                            else (if (isEnglish) "Item ${index + 1}: ..." else "আইটেম ${index + 1}: তেল ২ লিটার..."),
                                            fontSize = 11.sp
                                        )
                                    },
                                    singleLine = true,
                                    textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
                                    modifier = Modifier
                                        .weight(1f)
                                        .defaultMinSize(minHeight = 52.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = universalTextFieldColors(isDarkMode)
                                )
                                if (descriptionBoxes.size > 1) {
                                    IconButton(
                                        onClick = {
                                            val updated = descriptionBoxes.toMutableList()
                                            updated.removeAt(index)
                                            descriptionBoxes = updated
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(
                                onClick = { descriptionBoxes = descriptionBoxes + "" }
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFF2E7D32))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isEnglish) "+ Add Box" else "+ নতুন বক্স",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2E7D32)
                                )
                            }
                            Button(
                                onClick = {
                                    val validItems = descriptionBoxes.filter { it.isNotBlank() }
                                    if (validItems.isNotEmpty()) {
                                        validItems.forEach { item ->
                                            onAddNote(due, item.trim())
                                        }
                                        descriptionBoxes = listOf("")
                                    } else {
                                        Toast.makeText(context, if (isEnglish) "Please enter item details" else "পণ্যের বিবরণ লিখুন", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isEnglish) "Save Items" else "বিবরণ সেভ করুন",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // TIMELINE & DESCRIPTION HISTORY LIST
                Text(
                    text = if (isEnglish) "Due History & Descriptions:" else "পূর্বের সকল বাকি ও জমার হিসাব বিবরণী:",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .background(if (isDarkMode) Color(0xFF1E1E1E) else Color(0xFFFAFAFA), RoundedCornerShape(8.dp))
                        .border(1.dp, if (isDarkMode) Color(0xFF333333) else Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                        .padding(6.dp)
                ) {
                    if (historyList.isEmpty()) {
                        Text(
                            text = if (isEnglish) "No transaction history recorded yet." else "কোন পূর্বের লেনদেন রেকর্ড পাওয়া যায়নি।",
                            fontSize = 10.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(6.dp)
                        )
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            items(historyList) { item ->
                                val isPay = item.contains("জমা") || item.contains("Payment")
                                val isAdd = item.contains("বৃদ্ধি") || item.contains("Add Due")
                                val isSettle = item.contains("সম্পূর্ণ বাকি পরিশোধ")
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (isDarkMode) {
                                        if (isSettle) Color(0xFF132B18) else if (isPay) Color(0xFF0D253F) else if (isAdd) Color(0xFF3D1424) else Color(0xFF282828)
                                    } else {
                                        if (isSettle) Color(0xFFE8F8F5) else if (isPay) Color(0xFFE3F2FD) else if (isAdd) Color(0xFFFFEBEE) else Color.White
                                    },
                                    border = androidx.compose.foundation.BorderStroke(
                                        0.5.dp,
                                        if (isSettle) SuccessGreen else if (isPay) Color(0xFF64B5F6) else if (isAdd) Color(0xFFE57373) else Color(0xFFCBD5E1)
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "• $item",
                                        fontSize = 10.sp,
                                        fontWeight = if (isPay || isAdd || isSettle) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSettle) SuccessGreen else if (isPay) Color(0xFF2196F3) else if (isAdd) Color(0xFFE91E63) else MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // REQUIREMENT 7: Settle Full Due Button & Auto-Hide
                if (due.amount > 0) {
                    Button(
                        onClick = {
                            onSettleFull(due)
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isEnglish) "Settle Full Due (৳0 BDT)" else "সম্পূর্ণ বাকি পরিশোধ করুন (৳০ টাকা)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
