package com.example.ui.components

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.AlertRed
import com.example.ui.theme.BkashPink
import com.example.ui.theme.SuccessGreen
import com.example.util.AppStrings

@Composable
fun AppLockScreen(
    isLocked: Boolean,
    isMasterLockEnabled: Boolean = true,
    isEnglish: Boolean = false,
    shopName: String,
    securityQuestion: String = "What is your pet's name?",
    isBiometricAvailable: Boolean = false,
    isBiometricEnabled: Boolean = false,
    launchLockPriority: String = "FINGERPRINT_FIRST", // REQUIREMENT 9
    onBiometricRequested: (() -> Unit)? = null,
    onVerifyPin: (String) -> Boolean,
    onVerifySecurityAnswer: ((String) -> Boolean)? = null,
    onResetPin: ((String) -> Boolean)? = null,
    onUnlocked: () -> Unit
) {
    if (!isLocked || !isMasterLockEnabled) return

    val context = LocalContext.current
    var pinInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }
    var isForgotDialogVisible by remember { mutableStateOf(false) }

    // REQUIREMENT 9: App Launch Priority check: If FINGERPRINT_FIRST, auto trigger biometric prompt
    LaunchedEffect(isLocked, isBiometricEnabled, launchLockPriority) {
        if (isLocked && isBiometricAvailable && isBiometricEnabled && launchLockPriority == "FINGERPRINT_FIRST") {
            onBiometricRequested?.invoke()
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF121212)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 10.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = BkashPink,
                    modifier = Modifier.size(72.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Storefront,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(38.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = shopName.ifBlank { "Digi Dhukan" },
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = BkashPink,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = AppStrings.enterPinToUnlock(isEnglish),
                        color = Color.LightGray,
                        fontSize = 12.5.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // PIN dot indicators (4 circles)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (i in 0 until 4) {
                        val isFilled = i < pinInput.length
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .background(
                                    if (isFilled) BkashPink else Color.Transparent,
                                    CircleShape
                                )
                                .border(2.dp, if (isFilled) BkashPink else Color.Gray, CircleShape)
                        )
                    }
                }

                AnimatedVisibility(
                    visible = errorMessage.isNotBlank(),
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Text(
                        text = errorMessage,
                        color = AlertRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Forgot PIN Recovery Link
                TextButton(
                    onClick = {
                        errorMessage = ""
                        isForgotDialogVisible = true
                    }
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.HelpOutline,
                            contentDescription = null,
                            tint = BkashPink,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isEnglish) "Forgot Password / PIN?" else "পিন ভুলে গেছেন? রিসেট করুন",
                            color = BkashPink,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // In-App Custom 0-9 Keypad
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Biometric Fingerprint Button (if enabled & available)
                if (isBiometricAvailable && isBiometricEnabled) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color(0xFF1E2835),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BkashPink.copy(alpha = 0.6f)),
                        modifier = Modifier
                            .clickable { onBiometricRequested?.invoke() }
                            .padding(bottom = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fingerprint,
                                contentDescription = "Fingerprint",
                                tint = BkashPink,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isEnglish) "Use Fingerprint" else "ফিঙ্গারপ্রিন্ট দিয়ে খুলুন",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                val buttons = listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9"),
                    listOf("C", "0", "DEL")
                )

                for (row in buttons) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        for (key in row) {
                            KeypadButton(
                                text = key,
                                onClick = {
                                    errorMessage = ""
                                    when (key) {
                                        "C" -> pinInput = ""
                                        "DEL" -> if (pinInput.isNotEmpty()) pinInput = pinInput.dropLast(1)
                                        else -> {
                                            if (pinInput.length < 4) {
                                                val newPin = pinInput + key
                                                pinInput = newPin
                                                if (newPin.length == 4) {
                                                    val success = onVerifyPin(newPin)
                                                    if (success) {
                                                        onUnlocked()
                                                    } else {
                                                        errorMessage = if (isEnglish) "Incorrect PIN! Try again." else "ভুল পিন! আবার চেষ্টা করুন।"
                                                        pinInput = ""
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    // PIN Recovery Dialog via Secret Question
    if (isForgotDialogVisible) {
        var answerInput by remember { mutableStateOf("") }
        var isAnswerVerified by remember { mutableStateOf(false) }
        var recoveryError by remember { mutableStateOf("") }
        var newPinInput by remember { mutableStateOf("") }
        var confirmPinInput by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { isForgotDialogVisible = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF1E222A),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(18.dp)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LockReset,
                                contentDescription = null,
                                tint = BkashPink,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isEnglish) "PIN Recovery" else "পিন পুনরুদ্ধার (রিসেট)",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 16.sp
                            )
                        }
                        IconButton(
                            onClick = { isForgotDialogVisible = false },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.LightGray)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (!isAnswerVerified) {
                        Text(
                            text = if (isEnglish)
                                "Answer your security question below to reset your PIN:"
                            else
                                "আপনার গোপন নিরাপত্তা প্রশ্নের সঠিক উত্তর দিন:",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF2A2E39)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = if (isEnglish) "Security Question:" else "নিরাপত্তা প্রশ্ন:",
                                    fontSize = 11.sp,
                                    color = Color.Gray,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = securityQuestion.ifBlank {
                                        if (isEnglish) "What is your pet's name?" else "আপনার পোষা প্রাণীর নাম কি?"
                                    },
                                    color = BkashPink,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.5.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = answerInput,
                            onValueChange = {
                                answerInput = it
                                recoveryError = ""
                            },
                            placeholder = {
                                Text(
                                    if (isEnglish) "Enter your secret answer..." else "সঠিক উত্তর লিখুন...",
                                    fontSize = 12.sp,
                                    color = Color.Gray
                                )
                            },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = BkashPink,
                                unfocusedBorderColor = Color.Gray
                            )
                        )

                        if (recoveryError.isNotBlank()) {
                            Text(
                                text = recoveryError,
                                color = AlertRed,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 6.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                if (answerInput.isBlank()) {
                                    recoveryError = if (isEnglish) "Please enter an answer!" else "দয়া করে উত্তর লিখুন!"
                                    return@Button
                                }
                                val isCorrect = onVerifySecurityAnswer?.invoke(answerInput) ?: false
                                if (isCorrect) {
                                    isAnswerVerified = true
                                    recoveryError = ""
                                } else {
                                    recoveryError = if (isEnglish)
                                        "Incorrect answer! Please try again."
                                    else
                                        "ভুল উত্তর! আবার চেষ্টা করুন।"
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BkashPink),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                        ) {
                            Text(
                                text = if (isEnglish) "Verify Answer" else "উত্তর যাচাই করুন",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    } else {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1B3828)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isEnglish) "✓ Security Question verified! Set a new 4-digit PIN." else "✓ উত্তর সঠিক হয়েছে! নতুন ৪-সংখ্যার পিন দিন।",
                                    color = SuccessGreen,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = newPinInput,
                            onValueChange = {
                                if (it.length <= 4) {
                                    newPinInput = it
                                    recoveryError = ""
                                }
                            },
                            label = { Text(if (isEnglish) "New 4-Digit PIN" else "নতুন ৪-সংখ্যার পিন", fontSize = 11.sp, color = Color.LightGray) },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = BkashPink,
                                unfocusedBorderColor = Color.Gray
                            )
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = confirmPinInput,
                            onValueChange = {
                                if (it.length <= 4) {
                                    confirmPinInput = it
                                    recoveryError = ""
                                }
                            },
                            label = { Text(if (isEnglish) "Confirm New PIN" else "নতুন পিন নিশ্চিত করুন", fontSize = 11.sp, color = Color.LightGray) },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = BkashPink,
                                unfocusedBorderColor = Color.Gray
                            )
                        )

                        if (recoveryError.isNotBlank()) {
                            Text(
                                text = recoveryError,
                                color = AlertRed,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 6.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                if (newPinInput.length != 4) {
                                    recoveryError = if (isEnglish) "PIN must be exactly 4 digits!" else "পিন অবশ্যই ৪-সংখ্যার হতে হবে!"
                                    return@Button
                                }
                                if (newPinInput != confirmPinInput) {
                                    recoveryError = if (isEnglish) "PINs do not match!" else "দুটি পিন মিলছে না!"
                                    return@Button
                                }
                                val resetOk = onResetPin?.invoke(newPinInput) ?: false
                                if (resetOk) {
                                    Toast.makeText(
                                        context,
                                        if (isEnglish) "✓ PIN successfully reset!" else "✓ পিন সফলভাবে পরিবর্তন করা হয়েছে!",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    isForgotDialogVisible = false
                                    onUnlocked()
                                } else {
                                    recoveryError = if (isEnglish) "Failed to reset PIN." else "পিন পরিবর্তন ব্যর্থ হয়েছে।"
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BkashPink),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                        ) {
                            Text(
                                text = if (isEnglish) "Reset PIN & Unlock" else "পিন পরিবর্তন ও আনলক করুন",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KeypadButton(
    text: String,
    onClick: () -> Unit
) {
    Surface(
        shape = CircleShape,
        color = if (text == "C" || text == "DEL") Color(0xFF262626) else Color(0xFF1E1E1E),
        modifier = Modifier
            .size(68.dp)
            .clickable { onClick() }
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (text == "DEL") {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                    contentDescription = "Backspace",
                    tint = Color.LightGray,
                    modifier = Modifier.size(22.dp)
                )
            } else {
                Text(
                    text = text,
                    color = if (text == "C") Color(0xFFFF8A80) else Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
