package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.SupplierMemo
import com.example.ui.MainViewModel
import com.example.ui.theme.AlertRed
import com.example.ui.theme.universalTextFieldColors
import com.example.util.AppStrings
import com.example.util.PdfReportGenerator
import com.example.util.ReportImageGenerator

@Composable
fun MemoSlipsTab(
    viewModel: MainViewModel,
    isDarkMode: Boolean = false,
    isEnglish: Boolean = false,
    onOpenAddMemo: () -> Unit,
    onOpenEditMemo: (SupplierMemo) -> Unit
) {
    val context = LocalContext.current
    val memos by viewModel.memos.collectAsState()
    val storeProfile by viewModel.storeProfile.collectAsState()
    val selectedMemoIds by viewModel.selectedMemoIds.collectAsState()
    var memoSearchQuery by remember { mutableStateOf("") }
    var showDeleteConfirmation by remember { mutableStateOf(false) }

    val filteredMemos = remember(memos, memoSearchQuery) {
        memos.filter { m ->
            memoSearchQuery.isBlank() ||
                    m.supplierName.contains(memoSearchQuery, ignoreCase = true) ||
                    m.memoNo.contains(memoSearchQuery, ignoreCase = true) ||
                    m.note.contains(memoSearchQuery, ignoreCase = true)
        }
    }

    val totalMemoAmount = remember(memos) { memos.sumOf { it.amount } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Total memos card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isDarkMode) Color(0xFF152A3F) else Color(0xFFE3F2FD),
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Receipt, contentDescription = null, tint = Color(0xFF1976D2))
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(if (isEnglish) "Total Wholesale Purchases" else "মোট পাইকারি ক্রয়ের হিসাব", fontSize = 11.sp, color = Color.Gray)
                        Text("৳ ${totalMemoAmount.toInt()}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1976D2))
                    }
                }

                Button(
                    onClick = onOpenAddMemo,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(AppStrings.addMemo(isEnglish), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // All Memos Download Row
        if (memos.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        PdfReportGenerator.generateAllMemosPdf(context, storeProfile, memos, isEnglish)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.weight(1f).height(38.dp)
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isEnglish) "Memos PDF" else "মেমো PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        ReportImageGenerator.saveAllMemosJpg(context, storeProfile, memos, isEnglish)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00796B)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.weight(1f).height(38.dp)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isEnglish) "Memos JPG" else "মেমো JPG", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Search Input with clear button (Requirement 8: high contrast, minHeight 56dp)
        OutlinedTextField(
            value = memoSearchQuery,
            onValueChange = { memoSearchQuery = it },
            placeholder = { Text(AppStrings.memoSearchPlaceholder(isEnglish), fontSize = 12.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color(0xFF1976D2)) },
            trailingIcon = {
                if (memoSearchQuery.isNotEmpty()) {
                    IconButton(onClick = { memoSearchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.Gray, modifier = Modifier.size(18.dp))
                    }
                }
            },
            singleLine = true,
            textStyle = TextStyle(fontSize = 14.sp, color = if (isDarkMode) Color.White else Color.Black),
            modifier = Modifier
                .fillMaxWidth()
                .defaultMinSize(minHeight = 56.dp),
            shape = RoundedCornerShape(12.dp),
            colors = universalTextFieldColors(isDarkMode)
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Selection & Delete Toolbar
        if (memos.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = selectedMemoIds.isNotEmpty() && selectedMemoIds.size == memos.size,
                        onCheckedChange = { isChecked ->
                            if (isChecked) {
                                viewModel.selectedMemoIds.value = memos.map { it.id }.toSet()
                            } else {
                                viewModel.selectedMemoIds.value = emptySet()
                            }
                        },
                        colors = CheckboxDefaults.colors(checkedColor = Color(0xFF1976D2))
                    )
                    Text(
                        text = if (isEnglish) "Select All (${memos.size})" else "সব সিলেক্ট (${memos.size} টি)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (selectedMemoIds.isNotEmpty()) {
                    Button(
                        onClick = { showDeleteConfirmation = true },
                        colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isEnglish) "Delete (${selectedMemoIds.size})" else "মুছুন (${selectedMemoIds.size})",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
        }

        Text(
            text = if (isEnglish) "Wholesale Memo Slips (${filteredMemos.size}):" else "মহাজন পাইকারি মেমোর তালিকা (${filteredMemos.size} টি):",
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(6.dp))

        if (filteredMemos.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isEnglish) "No wholesale purchase memos found!" else "কোন পাইকারি ক্রয়ের মেমো পাওয়া যায়নি!",
                    color = Color.Gray,
                    fontSize = 13.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredMemos, key = { it.id }) { memo ->
                    val isSelected = selectedMemoIds.contains(memo.id)
                    MemoCard(
                        memo = memo,
                        isSelected = isSelected,
                        isDarkMode = isDarkMode,
                        onToggleSelect = { viewModel.toggleMemoSelection(memo.id) },
                        onPhotoClick = {
                            if (memo.photoUri.isNotBlank()) {
                                viewModel.fullScreenImageUri.value = memo.photoUri
                            }
                        },
                        onEdit = { onOpenEditMemo(memo) },
                        onDelete = { viewModel.deleteSupplierMemo(memo) },
                        isEnglish = isEnglish
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(90.dp))
                }
            }
        }
    }

    if (showDeleteConfirmation) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmation = false },
            title = { Text(if (isEnglish) "Delete Selected Memos?" else "মেমো মুছবেন?") },
            text = {
                Text(
                    if (isEnglish)
                        "Are you sure you want to delete ${selectedMemoIds.size} selected purchase memo slips?"
                    else
                        "আপনি কি নির্বাচিত ${selectedMemoIds.size} টি পাইকারি মেমো মুছে ফেলতে চান?"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteSelectedMemos()
                        showDeleteConfirmation = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed)
                ) {
                    Text(if (isEnglish) "Delete" else "মুছুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmation = false }) {
                    Text(if (isEnglish) "Cancel" else "বাতিল")
                }
            }
        )
    }
}

@Composable
fun MemoCard(
    memo: SupplierMemo,
    isSelected: Boolean,
    isDarkMode: Boolean = false,
    onToggleSelect: () -> Unit,
    onPhotoClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    isEnglish: Boolean = false
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                if (isDarkMode) Color(0xFF1E2F40) else Color(0xFFE3F2FD)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Checkbox(
                        checked = isSelected,
                        onCheckedChange = { onToggleSelect() },
                        colors = CheckboxDefaults.colors(checkedColor = Color(0xFF1976D2))
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = memo.supplierName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Text(
                    text = "৳ ${memo.amount.toInt()}",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp,
                    color = Color(0xFF1976D2)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isEnglish) "Memo No: ${memo.memoNo}" else "মেমো নং: #${memo.memoNo}",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
                Text(text = memo.date, fontSize = 10.sp, color = Color.Gray)
            }

            if (memo.note.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = memo.note,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Photo Thumbnail Banner
            if (memo.photoUri.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isDarkMode) Color(0xFF282828) else Color(0xFFF1F5F9),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onPhotoClick() }
                ) {
                    Row(
                        modifier = Modifier.padding(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = memo.photoUri,
                            contentDescription = "Memo Slip Photo",
                            modifier = Modifier
                                .size(46.dp)
                                .background(Color.LightGray, RoundedCornerShape(6.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Image, contentDescription = null, tint = Color(0xFF1976D2), modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isEnglish) "Memo Slip Photo Attached" else "মেমোর রসিদের ছবি যুক্ত আছে",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1976D2)
                                )
                            }
                            Text(
                                text = if (isEnglish) "Tap to view full screen & share 🔍" else "বড় করে দেখতে ও শেয়ার করতে ট্যাপ করুন 🔍",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Action Row: Edit Memo & Delete Memo
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFF1976D2).copy(alpha = 0.12f),
                    modifier = Modifier.clickable { onEdit() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Edit,
                            contentDescription = "Edit Memo",
                            tint = Color(0xFF1976D2),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = AppStrings.editMemo(isEnglish),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1976D2)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = AlertRed.copy(alpha = 0.8f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
