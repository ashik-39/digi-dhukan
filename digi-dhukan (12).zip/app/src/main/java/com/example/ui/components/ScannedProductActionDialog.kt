package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PriceCheck
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.SubcomposeAsyncImage
import com.example.data.Product
import com.example.ui.theme.AlertRed
import com.example.ui.theme.BkashPink
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.universalTextFieldColors
import com.example.util.AppStrings
import com.example.util.normalizeDigits

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ScannedProductActionDialog(
    isOpen: Boolean,
    product: Product?,
    userRole: String,
    isDarkMode: Boolean = false,
    isEnglish: Boolean = false,
    onDismiss: () -> Unit,
    onAddToCart: (product: Product, quantity: Int) -> Unit,
    onDirectSell: (product: Product, quantity: Int, customerPhone: String) -> Unit,
    onAddStock: (productId: Long, amountToAdd: Int) -> Unit,
    onEditProduct: (product: Product) -> Unit,
    onOpenFullScreen: ((String) -> Unit)? = null,
    onScanNextItem: () -> Unit = onDismiss
) {
    if (!isOpen || product == null) return

    val isOutOfStock = product.stock <= 0
    val isCriticalLow = product.stock in 1..5

    var selectedQuantity by remember(product) { mutableIntStateOf(1) }
    var isRestockMode by remember { mutableStateOf(isOutOfStock) }
    var customRestockInput by remember { mutableStateOf("") }
    var customerPhoneInput by remember { mutableStateOf("") }

    // REQUIREMENT 5: Tap to edit quantity state
    var isTypingQuantity by remember { mutableStateOf(false) }
    var typedQuantityText by remember { mutableStateOf("") }

    val totalSellForQuantity = product.sellPrice * selectedQuantity

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header with barcode badge and close button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = BkashPink.copy(alpha = 0.15f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCode,
                                contentDescription = null,
                                tint = BkashPink,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = product.barcode,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = BkashPink
                            )
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Product Image Container
                AnimatedVisibility(
                    visible = true,
                    enter = fadeIn() + expandVertically()
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(165.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isDarkMode) Color(0xFF1E2430) else Color(0xFFF1F5F9))
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            if (product.imageUri.isNotBlank()) {
                                SubcomposeAsyncImage(
                                    model = product.imageUri,
                                    contentDescription = product.name,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clickable { onOpenFullScreen?.invoke(product.imageUri) },
                                    loading = {
                                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                            CircularProgressIndicator(
                                                color = BkashPink,
                                                modifier = Modifier.size(28.dp)
                                            )
                                        }
                                    }
                                )
                                Surface(
                                    shape = CircleShape,
                                    color = Color.Black.copy(alpha = 0.7f),
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(8.dp)
                                        .size(36.dp)
                                        .clickable { onOpenFullScreen?.invoke(product.imageUri) }
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.OpenInFull,
                                            contentDescription = "Popup Fullscreen",
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            } else {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clickable { onEditProduct(product) }
                                        .padding(12.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PhotoCamera,
                                        contentDescription = null,
                                        tint = BkashPink,
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = if (isEnglish) "No product photo" else "পণ্যের ছবি যুক্ত করা নেই",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = if (isEnglish) "Tap to attach / take photo" else "ছবি তুলতে এখানে ট্যাপ করুন",
                                        fontSize = 10.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Product Name & Category
                Text(
                    text = product.name,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = if (isEnglish) "Category: ${product.category}" else "ক্যাটেগরি: ${product.category}",
                    fontSize = 11.sp,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(8.dp))

                // REQUIREMENT 11: Low Stock Alert with Bengali text: "পণ্য শেষের দিকে... X টি পণ্য stock এ আছে"
                if (isOutOfStock) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isDarkMode) Color(0xFF381414) else Color(0xFFFFEBEE),
                        border = BorderStroke(1.dp, AlertRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = AlertRed, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = if (isEnglish) "⚠️ OUT OF STOCK (0 Available)" else "⚠️ স্টক শেষ! (০ টি পণ্য অবশিষ্ট)",
                                    color = AlertRed,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isEnglish) "Selling blocked until stock is added." else "বিক্রয় করতে আগে স্টক বৃদ্ধি করুন।",
                                    color = if (isDarkMode) Color(0xFFFF8A80) else Color(0xFFB71C1C),
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                } else if (isCriticalLow) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isDarkMode) Color(0xFF351A18) else Color(0xFFFFF3E0),
                        border = BorderStroke(1.dp, Color(0xFFE65100)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFE65100), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = AppStrings.lowStockBadge(isEnglish, product.stock),
                                color = Color(0xFFE65100),
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Prices & Stock Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isOutOfStock) {
                            if (isDarkMode) Color(0xFF2C1E1E) else Color(0xFFFFF5F5)
                        } else {
                            if (isDarkMode) Color(0xFF1E281E) else Color(0xFFF9FBE7)
                        }
                    ),
                    border = BorderStroke(
                        1.5.dp,
                        if (isOutOfStock) Color(0xFFFFCDD2) else Color(0xFFC5E1A5)
                    )
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.2f)) {
                                Text(
                                    text = if (isEnglish) "Sell Price" else "বিক্রয় মূল্য",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF4CAF50)
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.PriceCheck,
                                        contentDescription = null,
                                        tint = SuccessGreen,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "৳ ${product.sellPrice.toInt()}",
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = SuccessGreen
                                    )
                                }
                            }

                            if (userRole == "owner") {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isEnglish) "Buy Price" else "ক্রয়মূল্য",
                                        fontSize = 10.sp,
                                        color = Color(0xFFBA68C8)
                                    )
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.MonetizationOn,
                                            contentDescription = null,
                                            tint = Color(0xFF8E24AA),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Text(
                                            text = "৳ ${product.buyPrice.toInt()}",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFBA68C8)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = if (isOutOfStock) Color(0xFFFFCDD2) else Color(0xFFDCEDC8))
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isOutOfStock) Color(0xFFFFCDD2) else if (isCriticalLow) Color(0xFFFFEBEE) else Color(0xFFDCEDC8)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Inventory,
                                        contentDescription = null,
                                        tint = if (isOutOfStock || isCriticalLow) AlertRed else SuccessGreen,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isOutOfStock) (if (isEnglish) "Stock: 0 (Out)" else "স্টক: ০ (শেষ)")
                                        else (if (isEnglish) "Total Current Stock: ${product.stock} pcs" else "বর্তমান মোট স্টক: ${product.stock} টি"),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isOutOfStock || isCriticalLow) AlertRed else Color(0xFF1B5E20)
                                    )
                                }
                            }

                            if (product.lastAddedQty > 0) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isDarkMode) Color(0xFF1E2835) else Color(0xFFE3F2FD)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.History,
                                            contentDescription = null,
                                            tint = Color(0xFF1976D2),
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text(
                                            text = if (isEnglish) "Last Restock: +${product.lastAddedQty} pcs" else "সর্বশেষ যোগ: +${product.lastAddedQty} টি",
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF1565C0)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Quantity Selector & Tap-to-edit
                if (!isOutOfStock) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (isEnglish) "Quantity to Sell:" else "বিক্রয় পরিমাণ:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "৳ ${totalSellForQuantity.toInt()}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = BkashPink
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(if (isDarkMode) Color(0xFF282828) else Color(0xFFF5F5F5), RoundedCornerShape(12.dp))
                                .padding(4.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier.size(32.dp)
                            ) {
                                IconButton(
                                    onClick = {
                                        if (selectedQuantity > 1) selectedQuantity--
                                    }
                                ) {
                                    Icon(Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(16.dp))
                                }
                            }

                            // REQUIREMENT 5: Tap-to-edit quantity number in Quick Sell / Product Dialog
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, BkashPink.copy(alpha = 0.6f)),
                                modifier = Modifier
                                    .padding(horizontal = 4.dp)
                                    .clickable {
                                        typedQuantityText = selectedQuantity.toString()
                                        isTypingQuantity = true
                                    }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "$selectedQuantity",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        textAlign = TextAlign.Center,
                                        color = BkashPink
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Type exact quantity",
                                        tint = BkashPink,
                                        modifier = Modifier.size(11.dp)
                                    )
                                }
                            }

                            Surface(
                                shape = CircleShape,
                                color = BkashPink.copy(alpha = 0.15f),
                                modifier = Modifier.size(32.dp)
                            ) {
                                IconButton(
                                    onClick = {
                                        if (selectedQuantity < product.stock) {
                                            selectedQuantity++
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Increase", tint = BkashPink, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // REQUIREMENT 8: High contrast OutlinedTextField with minHeight 56dp
                    OutlinedTextField(
                        value = customerPhoneInput,
                        onValueChange = { customerPhoneInput = it },
                        placeholder = { Text(if (isEnglish) "Customer Mobile (Optional)" else "কাস্টমারের মোবাইল (ঐচ্ছিক)", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        textStyle = TextStyle(
                            fontSize = 14.sp,
                            color = if (isDarkMode) Color.White else Color.Black
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 56.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = universalTextFieldColors(isDarkMode)
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                }

                // MAIN ACTION BUTTONS: Add to Cart + Direct Sell
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            if (!isOutOfStock) onAddToCart(product, selectedQuantity)
                        },
                        enabled = !isOutOfStock,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BkashPink,
                            disabledContainerColor = Color.LightGray
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isOutOfStock) (if (isEnglish) "Out of Stock" else "স্টক নেই") else (if (isEnglish) "Add to Cart" else "কার্টে যোগ"),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = {
                            if (!isOutOfStock) onDirectSell(product, selectedQuantity, customerPhoneInput)
                        },
                        enabled = !isOutOfStock,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SuccessGreen,
                            disabledContainerColor = Color(0xFFBDBDBD)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isOutOfStock) (if (isEnglish) "Unavailable" else "অনুপলব্ধ") else (if (isEnglish) "Direct Sell" else "সরাসরি বিক্রি"),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // NEXT ITEM SCAN BUTTON
                Button(
                    onClick = onScanNextItem,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF0D47A1),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(14.dp),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp, pressedElevation = 6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isEnglish) "Scan Next Item" else "পরবর্তী পণ্য স্ক্যান করুন",
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // RESTOCK / ADD STOCK BUTTON
                OutlinedButton(
                    onClick = { isRestockMode = !isRestockMode },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                ) {
                    Icon(Icons.Default.Inventory, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFF1976D2))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isRestockMode) (if (isEnglish) "Hide Restock Box" else "স্টক বক্স লুকান") else (if (isEnglish) "Add Stock / Restock" else "স্টক যোগ করুন (Restock)"),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1976D2)
                    )
                }

                if (isRestockMode) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = if (isDarkMode) Color(0xFF1A2A3A) else Color(0xFFE3F2FD)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = if (isEnglish) "Select amount to add to stock:" else "স্টক বাড়ানোর পরিমাণ নির্বাচন করুন:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1565C0)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(1, 5, 10, 20, 50).forEach { qty ->
                                    Button(
                                        onClick = {
                                            onAddStock(product.id, qty)
                                            isRestockMode = false
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                        modifier = Modifier.height(30.dp)
                                    ) {
                                        Text("+$qty টি", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = customRestockInput,
                                    onValueChange = { customRestockInput = it },
                                    placeholder = { Text(if (isEnglish) "Custom qty..." else "নির্দিষ্ট সংখ্যা...", fontSize = 11.sp) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    textStyle = TextStyle(
                                        fontSize = 14.sp,
                                        color = if (isDarkMode) Color.White else Color.Black
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .defaultMinSize(minHeight = 52.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = universalTextFieldColors(isDarkMode)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Button(
                                    onClick = {
                                        val parsed = customRestockInput.toIntOrNull()
                                        if (parsed != null && parsed > 0) {
                                            onAddStock(product.id, parsed)
                                            customRestockInput = ""
                                            isRestockMode = false
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.height(48.dp)
                                ) {
                                    Text(if (isEnglish) "Add" else "যোগ", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Edit Product Link
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    TextButton(
                        onClick = {
                            onDismiss()
                            onEditProduct(product)
                        }
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Gray)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isEnglish) "Edit Product Details" else "পণ্যের বিবরণ সম্পাদনা", fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
        }
    }

    // REQUIREMENT 5: Quick Sell Tap-to-Edit Quantity Dialog with stock validation
    if (isTypingQuantity) {
        val enteredInt = typedQuantityText.toIntOrNull()
        val isExceeding = enteredInt != null && enteredInt > product.stock
        val isZeroOrNegative = enteredInt != null && enteredInt <= 0
        val isInvalid = typedQuantityText.isBlank() || enteredInt == null || isExceeding || isZeroOrNegative

        Dialog(onDismissRequest = { isTypingQuantity = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = if (isEnglish) "Type Exact Quantity" else "নির্দিষ্ট বিক্রয় পরিমাণ লিখুন",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = BkashPink
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${product.name} (স্টকে আছে: ${product.stock} টি)",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    OutlinedTextField(
                        value = typedQuantityText,
                        onValueChange = { input ->
                            typedQuantityText = input.normalizeDigits().filter { it.isDigit() }
                        },
                        label = { Text(if (isEnglish) "Quantity" else "পরিমাণ (পিস)") },
                        placeholder = { Text("যেমন: ২৫ বা ১০০...") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        isError = isExceeding,
                        supportingText = {
                            if (isExceeding) {
                                Text(
                                    text = if (isEnglish) 
                                        "⚠️ Cannot exceed stock (${product.stock})!" 
                                    else 
                                        "⚠️ স্টকের চেয়ে বেশি দেওয়া যাবে না (আছে মাত্র ${product.stock} টি)!",
                                    color = AlertRed,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            } else {
                                Text(
                                    text = if (isEnglish) "Available stock: ${product.stock} pcs" else "বর্তমান স্টক: ${product.stock} টি",
                                    fontSize = 10.5.sp
                                )
                            }
                        },
                        textStyle = TextStyle(
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDarkMode) Color.White else Color.Black
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 56.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = universalTextFieldColors(isDarkMode)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { isTypingQuantity = false }) {
                            Text(if (isEnglish) "Cancel" else "বাতিল")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val finalQty = enteredInt ?: 1
                                if (finalQty in 1..product.stock) {
                                    selectedQuantity = finalQty
                                    isTypingQuantity = false
                                }
                            },
                            enabled = !isInvalid,
                            colors = ButtonDefaults.buttonColors(containerColor = BkashPink),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(if (isEnglish) "Confirm" else "নিশ্চিত করুন")
                        }
                    }
                }
            }
        }
    }
}
