package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.BkashPink
import com.example.util.AppStrings
import com.example.util.BarcodeUtil
import com.example.util.PdfReportGenerator
import com.example.util.ReceiptData
import com.example.util.ReceiptImageGenerator

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReceiptDialog(
    receipt: ReceiptData?,
    isOpen: Boolean,
    isDarkMode: Boolean = false,
    isEnglish: Boolean = false,
    onDismiss: () -> Unit
) {
    if (!isOpen || receipt == null) return
    val context = LocalContext.current

    val barcodeBitmap = remember(receipt.totalAmount) {
        BarcodeUtil.generateBarcodeBitmap("RCPT-${System.currentTimeMillis() % 1000000}", width = 360, height = 70)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header with close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = AppStrings.cashMemo(isEnglish),
                        fontWeight = FontWeight.Bold,
                        color = BkashPink,
                        fontSize = 15.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Thermal receipt paper container (clean white paper style for legibility)
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFFE0E0E0), RoundedCornerShape(8.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = receipt.shopName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = BkashPink
                        )
                        Text(
                            text = receipt.address,
                            fontSize = 11.sp,
                            color = Color.DarkGray
                        )
                        Text(
                            text = "মোবাইল: ${receipt.phone} | স্বত্বাধিকারী: ${receipt.bossName}",
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = Color.LightGray)
                        Spacer(modifier = Modifier.height(6.dp))

                        // Date & Time
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "তারিখ: ${receipt.dateFormatted}", fontSize = 10.sp, color = Color.Gray)
                            if (receipt.customerPhone.isNotBlank()) {
                                Text(text = "কাস্টমার: ${receipt.customerPhone}", fontSize = 10.sp, color = Color.Gray)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Table Header
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFEEEEEE), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "পণ্যের নাম", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.8f))
                            Text(text = "পরিমাণ", fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.weight(0.8f))
                            Text(text = "মূল্য (৳)", fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
                        }

                        // Table Body
                        LazyColumn(modifier = Modifier.height(115.dp)) {
                            items(receipt.items) { item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp, horizontal = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = item.product.name, fontSize = 11.sp, color = Color.Black, modifier = Modifier.weight(1.8f))
                                    Text(text = "${item.quantity}", fontSize = 11.sp, color = Color.Black, textAlign = TextAlign.Center, modifier = Modifier.weight(0.8f))
                                    Text(text = "৳ ${item.totalCost.toInt()}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32), textAlign = TextAlign.End, modifier = Modifier.weight(1f))
                                }
                            }
                        }

                        HorizontalDivider(color = Color.LightGray)
                        Spacer(modifier = Modifier.height(8.dp))

                        // Grand Total
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = AppStrings.totalBill(isEnglish), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Black)
                            Text(
                                text = "৳ ${receipt.totalAmount.toInt()}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = Color(0xFF2E7D32)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        if (barcodeBitmap != null) {
                            Image(
                                bitmap = barcodeBitmap.asImageBitmap(),
                                contentDescription = "Receipt Barcode",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(34.dp)
                            )
                        }

                        Text(
                            text = AppStrings.thankYou(isEnglish),
                            fontSize = 11.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Actions: JPG Download, PDF Download, WhatsApp, Bluetooth, General Share
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // 1. JPG Download Button
                    Button(
                        onClick = {
                            ReceiptImageGenerator.saveReceiptToGallery(context, receipt)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f).height(42.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = if (isEnglish) "JPG Image" else "JPG রসিদ", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    // 2. PDF Download Button
                    Button(
                        onClick = {
                            PdfReportGenerator.generateReceiptPdf(context, receipt)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC2185B)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f).height(42.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = if (isEnglish) "PDF Invoice" else "PDF চালান", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    // 3. WhatsApp Fast Share
                    Button(
                        onClick = {
                            shareToWhatsApp(context, receipt)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f).height(42.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(text = AppStrings.shareWhatsApp(isEnglish), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // 4. Bluetooth Share
                    Button(
                        onClick = {
                            shareToBluetooth(context, receipt)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00838F)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f).height(40.dp)
                    ) {
                        Icon(Icons.Default.Bluetooth, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = AppStrings.shareBluetooth(isEnglish), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    // 5. General Share via Android Intent
                    OutlinedButton(
                        onClick = {
                            shareGeneral(context, receipt)
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f).height(40.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = AppStrings.shareGeneral(isEnglish), fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

private fun shareToWhatsApp(context: Context, receipt: ReceiptData) {
    try {
        val text = receipt.toWhatsAppFormattedString()
        val imageUri = ReceiptImageGenerator.getReceiptImageCacheUri(context, receipt)
        val intent = Intent(Intent.ACTION_SEND).apply {
            setPackage("com.whatsapp")
            type = if (imageUri != null) "image/jpeg" else "text/plain"
            if (imageUri != null) {
                putExtra(Intent.EXTRA_STREAM, imageUri)
                putExtra(Intent.EXTRA_TEXT, text)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } else {
                putExtra(Intent.EXTRA_TEXT, text)
            }
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        val text = receipt.toWhatsAppFormattedString()
        val url = "https://api.whatsapp.com/send?text=${Uri.encode(text)}"
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (ex: Exception) {
            shareGeneral(context, receipt)
        }
    }
}

private fun shareToBluetooth(context: Context, receipt: ReceiptData) {
    try {
        val imageUri = ReceiptImageGenerator.getReceiptImageCacheUri(context, receipt)
        val text = receipt.toWhatsAppFormattedString()
        val intent = Intent(Intent.ACTION_SEND).apply {
            setPackage("com.android.bluetooth")
            if (imageUri != null) {
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, imageUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } else {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        val imageUri = ReceiptImageGenerator.getReceiptImageCacheUri(context, receipt)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = if (imageUri != null) "image/jpeg" else "text/plain"
            if (imageUri != null) {
                putExtra(Intent.EXTRA_STREAM, imageUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } else {
                putExtra(Intent.EXTRA_TEXT, receipt.toWhatsAppFormattedString())
            }
        }
        context.startActivity(Intent.createChooser(intent, "Bluetooth এ শেয়ার করুন"))
    }
}

private fun shareGeneral(context: Context, receipt: ReceiptData) {
    val imageUri = ReceiptImageGenerator.getReceiptImageCacheUri(context, receipt)
    val sendIntent = Intent(Intent.ACTION_SEND).apply {
        if (imageUri != null) {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, imageUri)
            putExtra(Intent.EXTRA_TEXT, receipt.toWhatsAppFormattedString())
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } else {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, receipt.toWhatsAppFormattedString())
        }
    }
    val shareIntent = Intent.createChooser(sendIntent, "রসিদ শেয়ার করুন")
    context.startActivity(shareIntent)
}
