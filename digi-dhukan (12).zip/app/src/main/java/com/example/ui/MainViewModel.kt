package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.AppUpdateInfo
import com.example.data.CartItem
import com.example.data.CustomerDue
import com.example.data.FirebaseSyncManager
import com.example.data.OfflineBackupData
import com.example.data.Product
import com.example.data.SaleTransaction
import com.example.data.StoreNotification
import com.example.data.StoreProfile
import com.example.data.SupplierMemo
import com.example.util.NotificationHelper
import com.example.util.PdfReportGenerator
import com.example.util.ReceiptData
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class ReportPeriodFilter {
    ALL,
    TODAY,
    YESTERDAY,
    THIS_MONTH,
    CUSTOM_DATE_RANGE
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val productDao = db.productDao()
    private val dueDao = db.customerDueDao()
    private val memoDao = db.supplierMemoDao()
    private val transactionDao = db.saleTransactionDao()
    private val notificationDao = db.storeNotificationDao()

    private val prefs = application.getSharedPreferences("digi_dhukan_prefs", Context.MODE_PRIVATE)

    // Room StateFlows
    val products: StateFlow<List<Product>> = productDao.getAllProducts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dues: StateFlow<List<CustomerDue>> = dueDao.getAllDues()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memos: StateFlow<List<SupplierMemo>> = memoDao.getAllMemos()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactions: StateFlow<List<SaleTransaction>> = transactionDao.getAllTransactions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<StoreNotification>> = notificationDao.getAllNotifications()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadNotificationCount: StateFlow<Int> = notificationDao.getUnreadCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // REQUIREMENT 10: Notification Center Dialog State
    val isNotificationCenterOpen = MutableStateFlow(false)

    // REQUIREMENT 2: In-App Update Dialog State
    val isUpdateDialogOpen = MutableStateFlow(false)
    val appUpdateInfo: StateFlow<AppUpdateInfo> = FirebaseSyncManager.appUpdateInfo

    // REQUIREMENT 3: Google Drive & Cloud Backup Dialog State
    val isGoogleDriveBackupOpen = MutableStateFlow(false)

    // REQUIREMENT 9: App Launch Priority: "FINGERPRINT_FIRST" vs "PIN_FIRST"
    private val _launchLockPriority = MutableStateFlow(prefs.getString("launch_lock_priority", "FINGERPRINT_FIRST") ?: "FINGERPRINT_FIRST")
    val launchLockPriority: StateFlow<String> = _launchLockPriority.asStateFlow()

    fun setLaunchLockPriority(priority: String) {
        _launchLockPriority.value = priority
        prefs.edit().putString("launch_lock_priority", priority).apply()
        _storeProfile.value = _storeProfile.value.copy(launchLockPriority = priority)
    }

    // Cart state
    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

    // Store Profile
    private val _storeProfile = MutableStateFlow(loadStoreProfile())
    val storeProfile: StateFlow<StoreProfile> = _storeProfile.asStateFlow()

    // Firebase Auth user
    val currentUser: StateFlow<FirebaseUser?> = FirebaseSyncManager.currentUser

    // Language state: false = Bangla, true = English
    private val _isEnglish = MutableStateFlow(prefs.getBoolean("is_english", false))
    val isEnglish: StateFlow<Boolean> = _isEnglish.asStateFlow()

    fun toggleLanguage() {
        val newVal = !_isEnglish.value
        _isEnglish.value = newVal
        prefs.edit().putBoolean("is_english", newVal).apply()
        val msg = if (newVal) "Language switched to English" else "ভাষা বাংলায় পরিবর্তন করা হয়েছে"
        Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
    }

    // Dark Mode state
    private val _isDarkMode = MutableStateFlow(prefs.getBoolean("is_dark_mode", false))
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    fun toggleDarkMode() {
        val newVal = !_isDarkMode.value
        _isDarkMode.value = newVal
        prefs.edit().putBoolean("is_dark_mode", newVal).apply()
        val msg = if (newVal) "ডার্ক মোড সক্রিয়" else "লাইট মোড সক্রিয়"
        Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
    }

    // Live Chart Toggle
    private val _isLiveChartEnabled = MutableStateFlow(prefs.getBoolean("live_chart_enabled", true))
    val isLiveChartEnabled: StateFlow<Boolean> = _isLiveChartEnabled.asStateFlow()

    fun toggleLiveChart() {
        val newVal = !_isLiveChartEnabled.value
        _isLiveChartEnabled.value = newVal
        prefs.edit().putBoolean("live_chart_enabled", newVal).apply()
    }

    // App Lock Master Toggle
    private val _isAppLockMasterEnabled = MutableStateFlow(prefs.getBoolean("app_lock_master_enabled", true))
    val isAppLockMasterEnabled: StateFlow<Boolean> = _isAppLockMasterEnabled.asStateFlow()

    fun setAppLockMasterEnabled(enabled: Boolean) {
        _isAppLockMasterEnabled.value = enabled
        prefs.edit().putBoolean("app_lock_master_enabled", enabled).apply()
        if (!enabled) {
            _isAppLocked.value = false
        }
        val msg = if (isEnglish.value) {
            if (enabled) "App Lock Master enabled" else "App Lock disabled"
        } else {
            if (enabled) "অ্যাপ লক মাস্টার সুইচ চালু" else "অ্যাপ লক মাস্টার সুইচ বন্ধ"
        }
        Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
    }

    // App Password Lock state
    private val _isAppLocked = MutableStateFlow(
        prefs.getBoolean("app_lock_master_enabled", true) && prefs.getBoolean("require_lock", true)
    )
    val isAppLocked: StateFlow<Boolean> = _isAppLocked.asStateFlow()

    fun unlockApp(pin: String): Boolean {
        if (!_isAppLockMasterEnabled.value) {
            _isAppLocked.value = false
            return true
        }
        if (verifyPin(pin)) {
            _isAppLocked.value = false
            return true
        }
        return false
    }

    fun lockAppSession() {
        if (_isAppLockMasterEnabled.value) {
            _isAppLocked.value = true
        } else {
            val msg = if (isEnglish.value) "App Lock is disabled in settings" else "অ্যাপ লক সেটিংসে বন্ধ করা আছে"
            Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
        }
    }

    // Role
    private val _userRole = MutableStateFlow("owner")
    val userRole: StateFlow<String> = _userRole.asStateFlow()

    // Search filters
    val searchQuery = MutableStateFlow("")
    val filterLowStockOnly = MutableStateFlow(false)
    val memoSearchQuery = MutableStateFlow("")
    val salesSearchQuery = MutableStateFlow("")

    // Sales Report Filtering: Start Date & End Date
    val salesFilter = MutableStateFlow(ReportPeriodFilter.ALL)
    val customStartDate = MutableStateFlow("")
    val customEndDate = MutableStateFlow("")

    // UI Dialog & Scanner states
    val isScannerOpen = MutableStateFlow(false)
    val isCartOpen = MutableStateFlow(false)
    val isAddProductOpen = MutableStateFlow(false)
    val isAddDueOpen = MutableStateFlow(false)
    val isAddEditMemoOpen = MutableStateFlow(false)
    val isProfileOpen = MutableStateFlow(false)
    val isPinSettingsOpen = MutableStateFlow(false)
    val isBarcodeGenOpen = MutableStateFlow(false)
    val isReceiptOpen = MutableStateFlow(false)
    val isScanActionDialogOpen = MutableStateFlow(false)

    // Full screen image viewer
    val fullScreenImageUri = MutableStateFlow<String?>(null)

    // Customer Due Detailed Editor State
    val isDueDetailOpen = MutableStateFlow(false)
    val selectedDueForDetail = MutableStateFlow<CustomerDue?>(null)

    // Current editing items
    val editingProduct = MutableStateFlow<Product?>(null)
    val editingMemo = MutableStateFlow<SupplierMemo?>(null)
    val scannedBarcodeForProduct = MutableStateFlow("")
    val scannedProductForAction = MutableStateFlow<Product?>(null)
    val lastGeneratedReceipt = MutableStateFlow<ReceiptData?>(null)

    // Live Scanner State & History
    val isLiveScanMode = MutableStateFlow(true)
    val scanHistory = MutableStateFlow<List<Product>>(emptyList())

    // Biometric & Auto-Lock Security Settings
    val isBiometricEnabled = MutableStateFlow(prefs.getBoolean("is_biometric_enabled", false))
    val autoLockMinutes = MutableStateFlow(prefs.getInt("auto_lock_minutes", 0))
    val autoLockType = MutableStateFlow(prefs.getString("auto_lock_type", "INSTANT") ?: "INSTANT")

    fun setBiometricEnabled(enabled: Boolean) {
        isBiometricEnabled.value = enabled
        prefs.edit().putBoolean("is_biometric_enabled", enabled).apply()
    }

    fun setAutoLockConfig(minutes: Int, type: String = "MINUTES") {
        autoLockMinutes.value = minutes
        autoLockType.value = type
        prefs.edit()
            .putInt("auto_lock_minutes", minutes)
            .putString("auto_lock_type", type)
            .apply()
    }

    fun unlockWithBiometric() {
        _isAppLocked.value = false
    }

    private var appBackgroundTimestamp: Long = 0L

    fun onAppBackgrounded() {
        if (!_isAppLockMasterEnabled.value) return
        appBackgroundTimestamp = System.currentTimeMillis()
        if (autoLockType.value == "DEVICE_LOCK") {
            _isAppLocked.value = true
        }
    }

    fun onAppForegrounded() {
        if (!_isAppLockMasterEnabled.value) {
            _isAppLocked.value = false
            return
        }
        if (_isAppLocked.value) return
        when (autoLockType.value) {
            "INSTANT" -> _isAppLocked.value = true
            "DEVICE_LOCK" -> _isAppLocked.value = true
            "MINUTES" -> {
                val mins = autoLockMinutes.value
                if (mins <= 0) {
                    _isAppLocked.value = true
                } else if (appBackgroundTimestamp > 0) {
                    val elapsedMillis = System.currentTimeMillis() - appBackgroundTimestamp
                    if (elapsedMillis >= (mins * 60 * 1000L)) {
                        _isAppLocked.value = true
                    }
                }
            }
        }
    }

    // Multi-selection states for bulk delete across modules
    val selectedProductIds = MutableStateFlow<Set<Long>>(emptySet())
    val selectedDueIds = MutableStateFlow<Set<Long>>(emptySet())
    val selectedMemoIds = MutableStateFlow<Set<Long>>(emptySet())
    val selectedTransactionIds = MutableStateFlow<Set<Long>>(emptySet())

    val isCloudConnected = FirebaseSyncManager.isCloudConnected
    val isCloudSyncing = FirebaseSyncManager.isSyncing
    val lastCloudSyncTime = FirebaseSyncManager.lastSyncTime

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    init {
        NotificationHelper.createNotificationChannel(application)
        loadPersistentScanHistory()
        initFirebaseSync()

        // Check for in-app updates on startup
        viewModelScope.launch {
            kotlinx.coroutines.delay(1200)
            if (appUpdateInfo.value.isUpdateAvailable) {
                isUpdateDialogOpen.value = true
            }
        }
    }

    fun refreshAppData() {
        viewModelScope.launch {
            _isRefreshing.value = true
            initFirebaseSync()
            loadPersistentScanHistory()
            kotlinx.coroutines.delay(600)
            _isRefreshing.value = false
            val msg = if (isEnglish.value) "App data refreshed successfully!" else "দোকানের সকল তথ্য সফলভাবে রিলোড হয়েছে!"
            Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
        }
    }

    private fun initFirebaseSync() {
        val uid = _storeProfile.value.userUid.ifBlank { "default_owner" }
        FirebaseSyncManager.init(uid)
        FirebaseSyncManager.startRealtimeSync(
            onProductsUpdated = { remoteProducts ->
                productDao.insertAll(remoteProducts)
            },
            onDuesUpdated = { remoteDues ->
                dueDao.insertAll(remoteDues)
            },
            onMemosUpdated = { remoteMemos ->
                memoDao.insertAll(remoteMemos)
            },
            onTransactionsUpdated = { remoteTxns ->
                transactionDao.insertAll(remoteTxns)
            },
            onProfileUpdated = { remoteProfile ->
                _storeProfile.value = remoteProfile
            }
        )
    }

    fun syncAllDataToCloud() {
        viewModelScope.launch {
            FirebaseSyncManager.pushAllLocalToCloud(
                products = products.value,
                dues = dues.value,
                memos = memos.value,
                transactions = transactions.value,
                profile = storeProfile.value
            ) { success ->
                val msg = if (success) {
                    if (isEnglish.value) "Firebase Realtime Sync completed! All devices synced." else "ক্লাউড সিঙ্ক সফল হয়েছে! সকল ডিভাইসে তথ্য আপডেট হয়েছে।"
                } else {
                    if (isEnglish.value) "Firebase Sync failed. Check internet." else "ক্লাউড সিঙ্ক ব্যর্থ হয়েছে। ইন্টারনেট সংযোগ পরীক্ষা করুন।"
                }
                Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
            }
        }
    }

    // REQUIREMENT 3: Authenticate User & Isolate Gmail Cloud Backup
    fun linkGmailAccount(email: String, displayName: String = "", uid: String = "") {
        val resolvedUid = if (uid.isNotBlank()) uid else email.replace("@", "_").replace(".", "_")
        val updated = _storeProfile.value.copy(
            email = email.trim(),
            userUid = resolvedUid,
            bossName = if (displayName.isNotBlank()) displayName.trim() else _storeProfile.value.bossName
        )
        updateStoreProfile(updated)
        FirebaseSyncManager.switchUser(resolvedUid, email)
        initFirebaseSync()
        syncAllDataToCloud()

        val msg = if (isEnglish.value) "Logged in with Gmail: $email" else "জিমেইল যুক্ত হয়েছে: $email"
        Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
    }

    // REQUIREMENT 2: In-App Update Checker
    fun checkForAppUpdates(isManualCheck: Boolean = false) {
        val update = appUpdateInfo.value
        if (update.isUpdateAvailable) {
            isUpdateDialogOpen.value = true
        } else {
            if (isManualCheck) {
                val msg = if (isEnglish.value) "You are on the latest version (v1.0)!" else "আপনার অ্যাপটি সর্বশেষ ভার্সন (v1.0) এ আছে!"
                Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
            }
        }
    }

    // REQUIREMENT 3: Personal Google Drive / Cloud Backup Exporter
    fun backupToGoogleDrive(context: Context) {
        val backup = OfflineBackupData(
            exportDate = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date()),
            profile = storeProfile.value,
            products = products.value,
            dues = dues.value,
            memos = memos.value,
            transactions = transactions.value
        )
        PdfReportGenerator.exportOfflineDatabaseJson(context, backup, isEnglish.value) { file ->
            shareFileToDrive(context, file)
        }
    }

    private fun shareFileToDrive(context: Context, file: File) {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Digi Dhukan Google Drive Backup - ${storeProfile.value.shopName}")
                putExtra(Intent.EXTRA_TEXT, "Digi Dhukan Database Backup (${storeProfile.value.email})")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Google Drive এ ব্যাকআপ সংরক্ষণ করুন"))
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "ব্যাকআপ শেয়ারে ত্রুটি: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportOfflineBackupJson(context: Context) {
        val backup = OfflineBackupData(
            exportDate = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date()),
            profile = storeProfile.value,
            products = products.value,
            dues = dues.value,
            memos = memos.value,
            transactions = transactions.value
        )
        PdfReportGenerator.exportOfflineDatabaseJson(context, backup, isEnglish.value)
    }

    private fun loadPersistentScanHistory() {
        viewModelScope.launch {
            val savedCodes = prefs.getString("scanned_history_list", "") ?: ""
            if (savedCodes.isNotBlank()) {
                val codes = savedCodes.split(",").filter { it.isNotBlank() }
                val loaded = mutableListOf<Product>()
                codes.forEach { code ->
                    val prod = productDao.getProductByBarcode(code)
                    if (prod != null && loaded.none { it.id == prod.id }) {
                        loaded.add(prod)
                    }
                }
                scanHistory.value = loaded
            }
        }
    }

    fun clearScanHistory() {
        scanHistory.value = emptyList()
        prefs.edit().putString("scanned_history_list", "").apply()
        val msg = if (isEnglish.value) "Scan history cleared" else "স্ক্যান হিস্ট্রি মুছে ফেলা হয়েছে"
        Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
    }

    private fun loadStoreProfile(): StoreProfile {
        val shopName = prefs.getString("shop_name", "Digi Dhukan") ?: "Digi Dhukan"
        val address = prefs.getString("address", "দোকানের ঠিকানা লিখুন") ?: "দোকানের ঠিকানা লিখুন"
        val bossName = prefs.getString("boss_name", "দোকান মালিক") ?: "দোকান মালিক"
        val phone = prefs.getString("phone", "01700000000") ?: "01700000000"
        val email = prefs.getString("email", "") ?: ""
        val userUid = prefs.getString("user_uid", "default_owner") ?: "default_owner"
        val masterEnabled = prefs.getBoolean("app_lock_master_enabled", true)
        val launchPriority = prefs.getString("launch_lock_priority", "FINGERPRINT_FIRST") ?: "FINGERPRINT_FIRST"

        return StoreProfile(
            shopName = shopName,
            address = address,
            bossName = bossName,
            phone = phone,
            email = email,
            userUid = userUid,
            pin = prefs.getString("app_pin", "1234") ?: "1234",
            securityQuestion = prefs.getString("security_question", "What is your pet's name?") ?: "What is your pet's name?",
            securityAnswer = prefs.getString("security_answer", "admin") ?: "admin",
            isAppLockMasterEnabled = masterEnabled,
            launchLockPriority = launchPriority
        )
    }

    fun updateStoreProfile(profile: StoreProfile) {
        _storeProfile.value = profile
        prefs.edit()
            .putString("shop_name", profile.shopName)
            .putString("address", profile.address)
            .putString("boss_name", profile.bossName)
            .putString("phone", profile.phone)
            .putString("email", profile.email)
            .putString("user_uid", profile.userUid)
            .putString("app_pin", profile.pin)
            .putString("security_question", profile.securityQuestion)
            .putString("security_answer", profile.securityAnswer)
            .putBoolean("app_lock_master_enabled", profile.isAppLockMasterEnabled)
            .putString("launch_lock_priority", profile.launchLockPriority)
            .apply()

        _launchLockPriority.value = profile.launchLockPriority
        FirebaseSyncManager.syncStoreProfile(profile)
        Toast.makeText(getApplication(), "প্রোফাইল সংরক্ষিত হয়েছে!", Toast.LENGTH_SHORT).show()
    }

    fun verifyPin(enteredPin: String): Boolean {
        return enteredPin == _storeProfile.value.pin
    }

    fun updatePin(newPin: String) {
        updateStoreProfile(_storeProfile.value.copy(pin = newPin))
    }

    fun verifySecurityAnswer(enteredAnswer: String): Boolean {
        val storedAnswer = _storeProfile.value.securityAnswer.trim()
        val candidate = enteredAnswer.trim()
        if (storedAnswer.isBlank()) {
            return candidate.equals("admin", ignoreCase = true) ||
                    (_storeProfile.value.phone.isNotBlank() && candidate == _storeProfile.value.phone.trim()) ||
                    (_storeProfile.value.bossName.isNotBlank() && candidate.equals(_storeProfile.value.bossName.trim(), ignoreCase = true))
        }
        return storedAnswer.equals(candidate, ignoreCase = true)
    }

    fun resetPin(newPin: String): Boolean {
        if (newPin.length != 4) return false
        val updated = _storeProfile.value.copy(pin = newPin)
        updateStoreProfile(updated)
        _isAppLocked.value = false
        return true
    }

    fun updateSecuritySettings(
        newPin: String?,
        question: String,
        answer: String,
        masterLockEnabled: Boolean? = null,
        biometricEnabled: Boolean? = null,
        autoLockMins: Int? = null,
        lockType: String? = null,
        launchPriority: String? = null
    ): Boolean {
        val pinToSave = if (!newPin.isNullOrBlank()) newPin else _storeProfile.value.pin
        val master = masterLockEnabled ?: _isAppLockMasterEnabled.value
        val priority = launchPriority ?: _launchLockPriority.value
        val updated = _storeProfile.value.copy(
            pin = pinToSave,
            securityQuestion = question.trim(),
            securityAnswer = answer.trim(),
            isAppLockMasterEnabled = master,
            launchLockPriority = priority
        )
        updateStoreProfile(updated)
        masterLockEnabled?.let { setAppLockMasterEnabled(it) }
        biometricEnabled?.let { setBiometricEnabled(it) }
        launchPriority?.let { setLaunchLockPriority(it) }
        if (autoLockMins != null || lockType != null) {
            setAutoLockConfig(autoLockMins ?: autoLockMinutes.value, lockType ?: autoLockType.value)
        }
        return true
    }

    // Product Management
    fun saveProduct(product: Product) {
        viewModelScope.launch {
            val savedProduct: Product
            if (product.id == 0L) {
                val newId = productDao.insertProduct(product.copy(lastAddedQty = product.stock))
                savedProduct = product.copy(id = newId, lastAddedQty = product.stock)
                Toast.makeText(getApplication(), "পণ্য যোগ করা হয়েছে!", Toast.LENGTH_SHORT).show()
            } else {
                productDao.updateProduct(product)
                savedProduct = product
                Toast.makeText(getApplication(), "পণ্য আপডেট করা হয়েছে!", Toast.LENGTH_SHORT).show()
            }
            FirebaseSyncManager.syncProduct(savedProduct)

            // REQUIREMENT 11: Low Stock Warning if stock <= 5
            if (savedProduct.stock in 1..5) {
                NotificationHelper.sendLowStockNotification(getApplication(), savedProduct.name, savedProduct.stock, isEnglish.value)
                addStoreNotification(
                    title = if (isEnglish.value) "Low Stock Warning" else "কম স্টক সতর্কতা",
                    message = if (isEnglish.value) "Low Stock: Only ${savedProduct.stock} items left for '${savedProduct.name}'!"
                              else "পণ্য শেষের দিকে... ${savedProduct.stock} টি পণ্য stock এ আছে ('${savedProduct.name}')",
                    type = "LOW_STOCK"
                )
            }
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            productDao.deleteProduct(product)
            FirebaseSyncManager.deleteProduct(product.id)
            Toast.makeText(getApplication(), "পণ্য মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show()
        }
    }

    fun toggleProductSelection(id: Long) {
        val current = selectedProductIds.value.toMutableSet()
        if (current.contains(id)) current.remove(id) else current.add(id)
        selectedProductIds.value = current
    }

    fun selectAllProducts(selectAll: Boolean) {
        selectedProductIds.value = if (selectAll) products.value.map { it.id }.toSet() else emptySet()
    }

    fun deleteSelectedProducts() {
        viewModelScope.launch {
            val ids = selectedProductIds.value.toList()
            if (ids.isNotEmpty()) {
                productDao.deleteProductsByIds(ids)
                selectedProductIds.value = emptySet()
                Toast.makeText(getApplication(), "${ids.size} টি পণ্য মুছে ফেলা হয়েছে!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Barcode Live Scan Handler with Pop-up Dialog
    fun handleScannedBarcode(barcode: String, keepScannerOpenIfLive: Boolean = true) {
        viewModelScope.launch {
            val trimmed = barcode.trim()
            val existing = productDao.getProductByBarcode(trimmed)
            if (existing != null) {
                com.example.util.SoundHapticHelper.playProductIdentifiedSuccess(getApplication())
                scannedProductForAction.value = existing

                val currentHistory = scanHistory.value.toMutableList()
                currentHistory.removeAll { it.id == existing.id }
                currentHistory.add(0, existing)
                scanHistory.value = currentHistory
                val codesString = currentHistory.take(25).joinToString(",") { it.barcode }
                prefs.edit().putString("scanned_history_list", codesString).apply()

                isScanActionDialogOpen.value = true
                isScannerOpen.value = false
            } else {
                com.example.util.SoundHapticHelper.playScanTick(getApplication())
                scannedBarcodeForProduct.value = trimmed
                editingProduct.value = Product(barcode = trimmed, name = "", buyPrice = 0.0, sellPrice = 0.0, stock = 10, lastAddedQty = 10)
                isAddProductOpen.value = true
                isScannerOpen.value = false
                Toast.makeText(getApplication(), "নতুন বারকোড: $trimmed - পণ্যের নাম ও দাম লিখুন", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun resumeLiveScannerForNextItem() {
        isScanActionDialogOpen.value = false
        scannedProductForAction.value = null
        isScannerOpen.value = true
    }

    // Direct Sell
    fun directQuickSell(product: Product, quantity: Int, customerPhone: String = "") {
        if (quantity <= 0) return
        if (product.stock <= 0) {
            Toast.makeText(getApplication(), "পণ্যটি স্টক আউট!", Toast.LENGTH_LONG).show()
            return
        }
        if (quantity > product.stock) {
            Toast.makeText(getApplication(), "স্টকে পর্যাপ্ত পণ্য নেই (আছে ${product.stock} টি)!", Toast.LENGTH_LONG).show()
            return
        }

        viewModelScope.launch {
            val totalCost = product.sellPrice * quantity
            val totalProfit = (product.sellPrice - product.buyPrice) * quantity
            val updatedStock = (product.stock - quantity).coerceAtLeast(0)

            productDao.updateStock(product.id, updatedStock)
            FirebaseSyncManager.updateProductStock(product.id, updatedStock)

            val dateStr = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date())
            val summary = "${product.name} x $quantity = ৳${totalCost.toInt()}\n"
            val transaction = SaleTransaction(
                totalAmount = totalCost,
                totalProfit = totalProfit,
                itemsSummary = summary,
                customerPhone = customerPhone,
                dateFormatted = dateStr
            )
            val newTxnId = transactionDao.insertTransaction(transaction)
            FirebaseSyncManager.syncSaleTransaction(transaction.copy(id = newTxnId))

            lastGeneratedReceipt.value = ReceiptData(
                shopName = _storeProfile.value.shopName,
                address = _storeProfile.value.address,
                phone = _storeProfile.value.phone,
                bossName = _storeProfile.value.bossName,
                items = listOf(CartItem(product = product.copy(stock = updatedStock), quantity = quantity)),
                totalAmount = totalCost,
                dateFormatted = dateStr,
                customerPhone = customerPhone
            )

            isScanActionDialogOpen.value = false
            isScannerOpen.value = false
            isReceiptOpen.value = true

            // REQUIREMENT 11: Low Stock warning if stock <= 5
            if (updatedStock in 1..5) {
                NotificationHelper.sendLowStockNotification(getApplication(), product.name, updatedStock, isEnglish.value)
                addStoreNotification(
                    title = if (isEnglish.value) "Low Stock Warning" else "কম স্টক সতর্কতা",
                    message = if (isEnglish.value) "Low Stock: Only $updatedStock items left for '${product.name}'!"
                              else "পণ্য শেষের দিকে... $updatedStock টি পণ্য stock এ আছে ('${product.name}')",
                    type = "LOW_STOCK"
                )
            }
            NotificationHelper.sendSaleNotification(getApplication(), product.name, totalCost, quantity, isEnglish.value)
            addStoreNotification(
                title = if (isEnglish.value) "Direct Sale Completed" else "সরাসরি বিক্রি সম্পন্ন",
                message = "${product.name} ($quantity টি) - মোট বিল: ৳${totalCost.toInt()}",
                type = "SALE"
            )
            Toast.makeText(getApplication(), "বিক্রি সম্পন্ন হয়েছে!", Toast.LENGTH_SHORT).show()
        }
    }

    // Add Stock / Restock
    fun addStockToProduct(productId: Long, addedStock: Int) {
        if (addedStock <= 0) return
        viewModelScope.launch {
            val current = productDao.getProductById(productId)
            if (current != null) {
                val newStock = current.stock + addedStock
                productDao.updateStockAndLastAdded(productId, newStock, addedStock)
                FirebaseSyncManager.updateProductStock(productId, newStock, addedStock)
                scannedProductForAction.value = current.copy(stock = newStock, lastAddedQty = addedStock)
                NotificationHelper.sendBuyNotification(getApplication(), "স্টক বৃদ্ধি", "${current.name} (+$addedStock টি)", current.buyPrice * addedStock, isEnglish.value)
                Toast.makeText(getApplication(), "+${addedStock} স্টক বৃদ্ধি! বর্তমান স্টক: $newStock টি", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun addToCart(product: Product) {
        addToCartWithQty(product, 1)
    }

    fun addToCartWithQty(product: Product, quantity: Int) {
        if (quantity <= 0) return
        if (product.stock <= 0) {
            Toast.makeText(getApplication(), "স্টক শেষ! '${product.name}' আর স্টকে নেই", Toast.LENGTH_LONG).show()
            return
        }

        val current = _cart.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == product.id }
        val currentQty = if (index >= 0) current[index].quantity else 0

        if (currentQty + quantity > product.stock) {
            Toast.makeText(getApplication(), "স্টকে আছে মাত্র ${product.stock} টি (কার্টে ইতিমধ্যে $currentQty টি আছে)!", Toast.LENGTH_LONG).show()
            return
        }

        if (index >= 0) {
            val item = current[index]
            current[index] = item.copy(quantity = item.quantity + quantity)
        } else {
            current.add(CartItem(product = product, quantity = quantity))
        }
        _cart.value = current
        isScanActionDialogOpen.value = false
        Toast.makeText(getApplication(), "কার্টে যুক্ত: ${product.name} ($quantity টি)!", Toast.LENGTH_SHORT).show()
    }

    fun updateCartQuantity(productId: Long, delta: Int) {
        val current = _cart.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == productId }
        if (index >= 0) {
            val item = current[index]
            val newQty = item.quantity + delta
            if (newQty <= 0) {
                current.removeAt(index)
            } else {
                if (newQty > item.product.stock) {
                    Toast.makeText(getApplication(), "স্টকে পর্যাপ্ত পণ্য নেই (${item.product.stock} টি আছে)!", Toast.LENGTH_SHORT).show()
                    return
                }
                current[index] = item.copy(quantity = newQty)
            }
            _cart.value = current
        }
    }

    // REQUIREMENT 5: Manual Quantity Typing Support in Cart with stock validation
    fun setCartQuantity(productId: Long, newQuantity: Int) {
        val current = _cart.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == productId }
        if (index >= 0) {
            val item = current[index]
            if (newQuantity <= 0) {
                current.removeAt(index)
                val msg = if (isEnglish.value) "Item removed from cart" else "পণ্যটি কার্ট থেকে সরানো হয়েছে"
                Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
            } else {
                val maxStock = item.product.stock
                val finalQty = if (newQuantity > maxStock) {
                    val warnMsg = if (isEnglish.value) 
                        "Cannot exceed available stock ($maxStock pcs)!" 
                    else 
                        "স্টকের চেয়ে বেশি পরিমাণ দেওয়া যাবে না (আছে মাত্র $maxStock টি)!"
                    Toast.makeText(getApplication(), warnMsg, Toast.LENGTH_LONG).show()
                    maxStock
                } else {
                    newQuantity
                }
                current[index] = item.copy(quantity = finalQty)
            }
            _cart.value = current
        }
    }

    fun removeFromCart(productId: Long) {
        _cart.value = _cart.value.filter { it.product.id != productId }
    }

    fun clearCart() {
        _cart.value = emptyList()
    }

    fun completeCheckout(customerPhone: String = "") {
        val items = _cart.value
        if (items.isEmpty()) return

        for (item in items) {
            if (item.product.stock <= 0) {
                Toast.makeText(getApplication(), "স্টক শেষ! '${item.product.name}' বিক্রি করা যাবে না", Toast.LENGTH_LONG).show()
                return
            }
            if (item.quantity > item.product.stock) {
                Toast.makeText(getApplication(), "স্টক পর্যাপ্ত নয়! '${item.product.name}' আছে মাত্র ${item.product.stock} টি", Toast.LENGTH_LONG).show()
                return
            }
        }

        viewModelScope.launch {
            var grandTotal = 0.0
            var grandProfit = 0.0
            val summaryBuilder = StringBuilder()

            for (item in items) {
                grandTotal += item.totalCost
                grandProfit += item.totalProfit
                summaryBuilder.append("${item.product.name} x ${item.quantity} = ৳${item.totalCost.toInt()}\n")

                val updatedStock = (item.product.stock - item.quantity).coerceAtLeast(0)
                productDao.updateStock(item.product.id, updatedStock)
                FirebaseSyncManager.updateProductStock(item.product.id, updatedStock)

                if (updatedStock in 1..5) {
                    NotificationHelper.sendLowStockNotification(getApplication(), item.product.name, updatedStock, isEnglish.value)
                    addStoreNotification(
                        title = if (isEnglish.value) "Low Stock Warning" else "কম স্টক সতর্কতা",
                        message = if (isEnglish.value) "Low Stock: Only $updatedStock items left for '${item.product.name}'!"
                                  else "পণ্য শেষের দিকে... $updatedStock টি পণ্য stock এ আছে ('${item.product.name}')",
                        type = "LOW_STOCK"
                    )
                }
            }

            val dateStr = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date())
            val transaction = SaleTransaction(
                totalAmount = grandTotal,
                totalProfit = grandProfit,
                itemsSummary = summaryBuilder.toString(),
                customerPhone = customerPhone,
                dateFormatted = dateStr
            )
            val newTxnId = transactionDao.insertTransaction(transaction)
            FirebaseSyncManager.syncSaleTransaction(transaction.copy(id = newTxnId))

            NotificationHelper.sendSaleNotification(getApplication(), "ক্যাশ বিক্রি", grandTotal, items.size, isEnglish.value)
            addStoreNotification(
                title = if (isEnglish.value) "Sale Invoice #${newTxnId}" else "বিক্রয় রশিদ #${newTxnId}",
                message = "মোট বিক্রয় বিল: ৳${grandTotal.toInt()} (${items.size} টি পণ্য)",
                type = "SALE"
            )

            lastGeneratedReceipt.value = ReceiptData(
                shopName = _storeProfile.value.shopName,
                address = _storeProfile.value.address,
                phone = _storeProfile.value.phone,
                bossName = _storeProfile.value.bossName,
                items = items.toList(),
                totalAmount = grandTotal,
                dateFormatted = dateStr,
                customerPhone = customerPhone
            )

            _cart.value = emptyList()
            isCartOpen.value = false
            isReceiptOpen.value = true
            Toast.makeText(getApplication(), "বিক্রি সম্পন্ন হয়েছে!", Toast.LENGTH_SHORT).show()
        }
    }

    // Customer Due Management
    fun addDue(customerName: String, phone: String, amount: Double, note: String = "") {
        viewModelScope.launch {
            val dateStr = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
            val existing = dueDao.getDueByPhone(phone)
            val finalDue: CustomerDue

            if (existing != null) {
                val newAmount = existing.amount + amount
                val initialEntry = if (existing.note.isNotBlank()) "পূর্বের বাকি: ${existing.note} (${existing.date})" else ""
                val newEntry = "+ বাকি বৃদ্ধি ৳${amount.toInt()}${if (note.isNotBlank()) " ($note)" else ""} [$dateStr]"
                val updatedHistory = if (existing.historyNotes.isBlank()) {
                    if (initialEntry.isNotBlank()) "$initialEntry||$newEntry" else newEntry
                } else {
                    "${existing.historyNotes}||$newEntry"
                }

                finalDue = existing.copy(
                    customerName = customerName,
                    amount = newAmount,
                    note = if (existing.note.isNotBlank() && note.isNotBlank()) "${existing.note} | $note" else if (note.isNotBlank()) note else existing.note,
                    date = dateStr,
                    historyNotes = updatedHistory
                )
                dueDao.updateDue(finalDue)
            } else {
                val historyInit = if (note.isNotBlank()) "বাকি তৈরি ৳${amount.toInt()} ($note) [$dateStr]" else "বাকি তৈরি ৳${amount.toInt()} [$dateStr]"
                val newDue = CustomerDue(
                    customerName = customerName,
                    phone = phone,
                    amount = amount,
                    note = note,
                    date = dateStr,
                    historyNotes = historyInit
                )
                val newId = dueDao.insertDue(newDue)
                finalDue = newDue.copy(id = newId)
            }

            FirebaseSyncManager.syncCustomerDue(finalDue)
            isAddDueOpen.value = false
            Toast.makeText(getApplication(), "বাকি এন্ট্রি সফল হয়েছে!", Toast.LENGTH_SHORT).show()
        }
    }

    fun adjustCustomerDue(due: CustomerDue, deltaAmount: Double, note: String = "") {
        viewModelScope.launch {
            val newAmount = (due.amount + deltaAmount).coerceAtLeast(0.0)
            val dateStr = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
            val actionLabel = if (deltaAmount > 0) "+ বাকি বৃদ্ধি ৳${deltaAmount.toInt()}" else "- জমা গ্রহণ ৳${(-deltaAmount).toInt()}"
            val newEntry = "$actionLabel${if (note.isNotBlank()) " ($note)" else ""} [$dateStr]"
            val updatedHistory = if (due.historyNotes.isBlank()) {
                val init = if (due.note.isNotBlank()) "পূর্বের বাকি: ${due.note} (${due.date})" else ""
                if (init.isNotBlank()) "$init||$newEntry" else newEntry
            } else {
                "${due.historyNotes}||$newEntry"
            }

            val updated = due.copy(
                amount = newAmount,
                date = dateStr,
                historyNotes = updatedHistory
            )
            dueDao.updateDue(updated)
            FirebaseSyncManager.syncCustomerDue(updated)
            selectedDueForDetail.value = updated
            Toast.makeText(getApplication(), "বাকি আপডেট হয়েছে!", Toast.LENGTH_SHORT).show()
        }
    }

    fun updateCustomerDueDetails(dueId: Long, name: String, phone: String, amount: Double, note: String) {
        viewModelScope.launch {
            val existing = dues.value.find { it.id == dueId } ?: return@launch
            val updated = existing.copy(
                customerName = name.trim(),
                phone = phone.trim(),
                amount = amount.coerceAtLeast(0.0),
                note = note.trim()
            )
            dueDao.updateDue(updated)
            FirebaseSyncManager.syncCustomerDue(updated)
            selectedDueForDetail.value = updated
            Toast.makeText(getApplication(), "কাস্টমারের তথ্য সংরক্ষিত হয়েছে!", Toast.LENGTH_SHORT).show()
        }
    }

    fun deleteCustomerDue(due: CustomerDue) {
        viewModelScope.launch {
            dueDao.deleteDue(due)
            FirebaseSyncManager.deleteCustomerDue(due.id)
            isDueDetailOpen.value = false
            selectedDueForDetail.value = null
            Toast.makeText(getApplication(), "বাকি মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show()
        }
    }

    fun toggleDueSelection(id: Long) {
        val current = selectedDueIds.value.toMutableSet()
        if (current.contains(id)) current.remove(id) else current.add(id)
        selectedDueIds.value = current
    }

    fun selectAllDues(selectAll: Boolean) {
        selectedDueIds.value = if (selectAll) dues.value.map { it.id }.toSet() else emptySet()
    }

    fun deleteSelectedDues() {
        viewModelScope.launch {
            val ids = selectedDueIds.value.toList()
            if (ids.isNotEmpty()) {
                dueDao.deleteDuesByIds(ids)
                ids.forEach { FirebaseSyncManager.deleteCustomerDue(it) }
                selectedDueIds.value = emptySet()
                val msg = if (isEnglish.value) "${ids.size} dues deleted" else "${ids.size} টি বাকি হিসাব মুছে ফেলা হয়েছে"
                Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
            }
        }
    }

    // REQUIREMENT 7: Settle Full Due & auto-hide/move to history
    fun settleFullDue(due: CustomerDue) {
        viewModelScope.launch {
            val previousAmount = due.amount
            val timeStr = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date())
            val settlementNote = "সম্পূর্ণ বাকি পরিশোধ ৳${previousAmount.toInt()} [পরিশোধের সময়: $timeStr]"
            val updatedHistory = if (due.historyNotes.isBlank()) {
                val init = if (due.note.isNotBlank()) "পূর্বের বাকি: ${due.note} (${due.date})" else ""
                if (init.isNotBlank()) "$init||$settlementNote" else settlementNote
            } else {
                "${due.historyNotes}||$settlementNote"
            }

            val updated = due.copy(
                amount = 0.0,
                historyNotes = updatedHistory
            )
            dueDao.updateDue(updated)
            FirebaseSyncManager.syncCustomerDue(updated)
            selectedDueForDetail.value = updated

            // Add alert to notification center
            addStoreNotification(
                title = if (isEnglish.value) "✅ Full Due Settled" else "✅ সম্পূর্ণ বাকি পরিশোধ",
                message = if (isEnglish.value) 
                    "${due.customerName}'s due (৳${previousAmount.toInt()}) has been fully settled to ৳0."
                else 
                    "${due.customerName}-এর মোট বাকি ৳${previousAmount.toInt()} সম্পূর্ণ পরিশোধ হয়েছে।",
                type = "SETTLED"
            )

            val msg = if (isEnglish.value) 
                "Full due settled for ${due.customerName}! Moved to history." 
            else 
                "${due.customerName}-এর সম্পূর্ণ বাকি পরিশোধ হয়েছে এবং হিস্ট্রিতে সরানো হয়েছে।"
            Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
        }
    }

    // REQUIREMENT 10: Notification Center Management
    fun addStoreNotification(title: String, message: String, type: String = "ALERT") {
        viewModelScope.launch {
            val dateFormatted = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date())
            val notif = StoreNotification(
                title = title,
                message = message,
                timestamp = System.currentTimeMillis(),
                type = type,
                dateFormatted = dateFormatted,
                isRead = false
            )
            notificationDao.insertNotification(notif)
        }
    }

    fun deleteNotification(id: Long) {
        viewModelScope.launch {
            notificationDao.deleteNotificationsByIds(listOf(id))
        }
    }

    fun deleteNotifications(ids: List<Long>) {
        viewModelScope.launch {
            if (ids.isNotEmpty()) {
                notificationDao.deleteNotificationsByIds(ids)
                val msg = if (isEnglish.value) "${ids.size} notifications deleted" else "${ids.size} টি নোটিফিকেশন মুছে ফেলা হয়েছে"
                Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun clearAllNotifications() {
        viewModelScope.launch {
            notificationDao.deleteAllNotifications()
            val msg = if (isEnglish.value) "All notifications cleared" else "সকল নোটিফিকেশন মুছে ফেলা হয়েছে"
            Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
        }
    }

    fun markAllNotificationsAsRead() {
        viewModelScope.launch {
            notificationDao.markAllAsRead()
        }
    }

    // Supplier Memo Management
    fun saveSupplierMemo(
        id: Long = 0L,
        supplier: String,
        memoNo: String,
        amount: Double,
        photoUri: String = "",
        note: String = "",
        manualDate: String = ""
    ) {
        viewModelScope.launch {
            val dateStr = if (manualDate.isNotBlank()) manualDate.trim() else SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
            val savedMemo: SupplierMemo
            if (id == 0L) {
                val memo = SupplierMemo(
                    supplierName = supplier.trim(),
                    memoNo = memoNo.trim(),
                    amount = amount,
                    date = dateStr,
                    photoUri = photoUri,
                    note = note.trim()
                )
                val newId = memoDao.insertMemo(memo)
                savedMemo = memo.copy(id = newId)
                Toast.makeText(getApplication(), "মেমো সংরক্ষিত হয়েছে!", Toast.LENGTH_SHORT).show()
            } else {
                savedMemo = SupplierMemo(
                    id = id,
                    supplierName = supplier.trim(),
                    memoNo = memoNo.trim(),
                    amount = amount,
                    date = dateStr,
                    photoUri = photoUri,
                    note = note.trim()
                )
                memoDao.updateMemo(savedMemo)
                Toast.makeText(getApplication(), "মেমো আপডেট করা হয়েছে!", Toast.LENGTH_SHORT).show()
            }
            FirebaseSyncManager.syncSupplierMemo(savedMemo)
            NotificationHelper.sendBuyNotification(getApplication(), supplier.trim(), memoNo.trim(), amount, isEnglish.value)
            addStoreNotification(
                title = if (isEnglish.value) "Purchase Memo #${memoNo.trim()}" else "পাইকারি মেমো #${memoNo.trim()}",
                message = "${supplier.trim()} - মোট ক্রয়: ৳${amount.toInt()}",
                type = "PURCHASE"
            )
            isAddEditMemoOpen.value = false
            editingMemo.value = null
        }
    }

    fun deleteSupplierMemo(memo: SupplierMemo) {
        viewModelScope.launch {
            memoDao.deleteMemo(memo)
            FirebaseSyncManager.deleteSupplierMemo(memo.id)
            Toast.makeText(getApplication(), "মেমো মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show()
        }
    }

    fun toggleMemoSelection(id: Long) {
        val current = selectedMemoIds.value.toMutableSet()
        if (current.contains(id)) current.remove(id) else current.add(id)
        selectedMemoIds.value = current
    }

    fun selectAllMemos(selectAll: Boolean) {
        selectedMemoIds.value = if (selectAll) memos.value.map { it.id }.toSet() else emptySet()
    }

    fun deleteSelectedMemos() {
        viewModelScope.launch {
            val ids = selectedMemoIds.value.toList()
            if (ids.isNotEmpty()) {
                memoDao.deleteMemosByIds(ids)
                selectedMemoIds.value = emptySet()
                Toast.makeText(getApplication(), "${ids.size} টি মেমো মুছে ফেলা হয়েছে!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Sales Multi-selection & Delete
    fun toggleTransactionSelection(id: Long) {
        val current = selectedTransactionIds.value.toMutableSet()
        if (current.contains(id)) current.remove(id) else current.add(id)
        selectedTransactionIds.value = current
    }

    fun selectAllTransactions(selectAll: Boolean) {
        selectedTransactionIds.value = if (selectAll) transactions.value.map { it.id }.toSet() else emptySet()
    }

    fun deleteSelectedTransactions() {
        viewModelScope.launch {
            val ids = selectedTransactionIds.value.toList()
            if (ids.isNotEmpty()) {
                transactionDao.deleteTransactionsByIds(ids)
                ids.forEach { FirebaseSyncManager.deleteSaleTransaction(it) }
                selectedTransactionIds.value = emptySet()
                Toast.makeText(getApplication(), "${ids.size} টি বিক্রয় হিসাব মুছে ফেলা হয়েছে!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun deleteTransaction(transaction: SaleTransaction) {
        viewModelScope.launch {
            transactionDao.deleteTransaction(transaction)
            FirebaseSyncManager.deleteSaleTransaction(transaction.id)
            Toast.makeText(getApplication(), "চালান মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show()
        }
    }

    // Exports
    fun exportInventoryPdf(context: Context) {
        PdfReportGenerator.generateInventoryStockPdf(context, storeProfile.value, products.value, isEnglish.value)
    }

    fun exportInventoryCsv(context: Context) {
        PdfReportGenerator.exportInventoryStockCsv(context, products.value, isEnglish.value)
    }

    fun exportMonthlySummaryPdf(context: Context) {
        PdfReportGenerator.generateComprehensiveMonthlyReportPdf(
            context = context,
            storeProfile = storeProfile.value,
            transactions = transactions.value,
            dues = dues.value,
            memos = memos.value,
            products = products.value,
            isEnglish = isEnglish.value
        )
    }

    fun shareCsvData(context: Context) {
        exportInventoryCsv(context)
    }
}
