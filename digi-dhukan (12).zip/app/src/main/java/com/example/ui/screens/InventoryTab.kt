package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Product
import com.example.ui.MainViewModel
import com.example.ui.theme.AlertRed
import com.example.ui.theme.BkashPink
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.universalTextFieldColors
import com.example.util.AppStrings

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun InventoryTab(
    viewModel: MainViewModel,
    isDarkMode: Boolean = false,
    isEnglish: Boolean = false,
    onOpenScanner: () -> Unit,
    onOpenAddProduct: () -> Unit = {}
) {
    val context = LocalContext.current
    val products by viewModel.products.collectAsState()
    val dues by viewModel.dues.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val userRole by viewModel.userRole.collectAsState()
    val isLiveChartEnabled by viewModel.isLiveChartEnabled.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val filterLowStockOnly by viewModel.filterLowStockOnly.collectAsState()
    val selectedIds by viewModel.selectedProductIds.collectAsState()
    val isRefreshing by viewModel.isRefreshing.collectAsState()

    val totalDuesAmount = remember(dues) { dues.sumOf { it.amount } }

    // REQUIREMENT 11: Low Stock items (stock in 1..5)
    val lowStockItems = remember(products) { products.filter { it.stock in 1..5 } }

    val filteredProducts = remember(products, searchQuery, filterLowStockOnly) {
        products.filter { p ->
            val matchQuery = searchQuery.isBlank() ||
                    p.name.contains(searchQuery, ignoreCase = true) ||
                    p.barcode.contains(searchQuery, ignoreCase = true) ||
                    p.category.contains(searchQuery, ignoreCase = true)
            val matchLowStock = !filterLowStockOnly || p.stock in 1..5
            matchQuery && matchLowStock
        }
    }

    // REQUIREMENT 6: Real-time Total Stock Valuation (Quantity × Buying Price)
    val totalStockValuation = remember(products) {
        products.sumOf { it.stock.coerceAtLeast(0).toDouble() * it.buyPrice }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))

            // REQUIREMENT 6: Total Stock Valuation Card on Main Dashboard
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDarkMode) Color(0xFF142B1A) else Color(0xFFE8F5E9)
                ),
                border = BorderStroke(
                    1.dp,
                    if (isDarkMode) Color(0xFF2E7D32) else Color(0xFFA5D6A7)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SuccessGreen.copy(alpha = 0.2f),
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.MonetizationOn,
                                    contentDescription = null,
                                    tint = SuccessGreen,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = AppStrings.totalStockValuation(isEnglish),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (isEnglish) "Real-time auto-deduct (Qty × Buying Price)" else "মোট মালামাল ক্রয়মূল্য (বিক্রয়ে স্বয়ংক্রিয় বাদ হয়)",
                                fontSize = 9.5.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "৳ ${totalStockValuation.toInt()}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = SuccessGreen
                        )
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = SuccessGreen.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "● Live Auto-Sync",
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = SuccessGreen,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Secondary Dashboard Cards: Total Products & Total Dues
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Total Products Card
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isDarkMode) Color(0xFF2C1E3D) else Color(0xFFEDE7F6),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Inventory2, contentDescription = null, tint = Color(0xFF9575CD))
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(AppStrings.totalProducts(isEnglish), fontSize = 11.sp, color = Color.Gray)
                            Text("${products.size} টি", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = if (isDarkMode) Color(0xFFB39DDB) else Color(0xFF512DA8))
                        }
                    }
                }

                // Total Dues Card
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isDarkMode) Color(0xFF381414) else Color(0xFFFFEBEE),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = AlertRed)
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(AppStrings.totalDues(isEnglish), fontSize = 11.sp, color = Color.Gray)
                            Text("৳ ${totalDuesAmount.toInt()}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = AlertRed)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // INVENTORY STOCK LIST EXPORT CARD (PDF & CSV)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(
                            imageVector = Icons.Default.FileDownload,
                            contentDescription = null,
                            tint = BkashPink,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = AppStrings.downloadInventoryStockList(isEnglish),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (isEnglish) "Export full stock list with SKU, current stock & last restock" else "বর্তমান মোট স্টক, বারকোড ও শেষ যোগকৃত স্টক তালিকা",
                                fontSize = 9.5.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = { viewModel.exportInventoryPdf(context) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { viewModel.exportInventoryCsv(context) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00796B)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("CSV", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // REQUIREMENT 11: LOW STOCK ALERT BANNER (Bengali text: "পণ্য শেষের দিকে... X টি পণ্য stock এ আছে")
            if (lowStockItems.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isDarkMode) Color(0xFF351515) else Color(0xFFFFEBEE))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = AlertRed, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (lowStockItems.size == 1) {
                                    val item = lowStockItems.first()
                                    if (isEnglish) "Low Stock: Only ${item.stock} left in stock (${item.name})!"
                                    else "পণ্য শেষের দিকে... ${item.stock} টি পণ্য stock এ আছে (${item.name})"
                                } else {
                                    if (isEnglish) "Low Stock Alert: ${lowStockItems.size} items have 5 or fewer in stock!"
                                    else "পণ্য শেষের দিকে... ${lowStockItems.size} টি পণ্য stock এ আছে"
                                },
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = AlertRed
                            )
                        }

                        Button(
                            onClick = {
                                viewModel.filterLowStockOnly.value = !viewModel.filterLowStockOnly.value
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (filterLowStockOnly) Color.DarkGray else AlertRed
                            ),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text(
                                text = if (filterLowStockOnly) AppStrings.viewAll(isEnglish) else AppStrings.filterLow(isEnglish),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Live Sales Trend Mini Chart (toggleable)
            if (userRole == "owner" && isLiveChartEnabled) {
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AutoGraph, contentDescription = null, tint = BkashPink, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (isEnglish) "Weekly Sales Trend" else "সাপ্তাহিক বিক্রয় গ্রাফ", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            val todaySales = transactions.sumOf { it.totalAmount }
                            Text("৳ ${todaySales.toInt()}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .background(if (isDarkMode) Color(0xFF242424) else Color(0xFFF9F9F9), RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            val days = if (isEnglish) listOf("Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri")
                            else listOf("শনি", "রবি", "সোম", "মঙ্গল", "বুধ", "বৃহঃ", "শুক্র")
                            val heights = listOf(0.4f, 0.65f, 0.9f, 0.75f, 0.6f, 0.85f, 1.0f)
                            days.forEachIndexed { i, day ->
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(
                                        modifier = Modifier
                                            .width(16.dp)
                                            .height((heights[i] * 32).dp)
                                            .background(
                                                if (i == 6) BkashPink else BkashPink.copy(alpha = 0.5f),
                                                RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp)
                                            )
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(day, fontSize = 8.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }
            }

            // Quick Search Bar with Scanner Shortcut
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // REQUIREMENT 8: High contrast OutlinedTextField with minHeight 56dp
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.searchQuery.value = it },
                    placeholder = { Text(AppStrings.searchPlaceholder(isEnglish), fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = BkashPink) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.Gray, modifier = Modifier.size(18.dp))
                            }
                        }
                    },
                    singleLine = true,
                    textStyle = TextStyle(
                        fontSize = 14.sp,
                        color = if (isDarkMode) Color.White else Color.Black
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 56.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = universalTextFieldColors(isDarkMode)
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = onOpenScanner,
                    modifier = Modifier
                        .size(52.dp)
                        .background(BkashPink.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                ) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan", tint = BkashPink)
                }
            }

            // Section Header with Add Product & Reload
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (isEnglish) "📦 Inventory (${filteredProducts.size})" else "📦 পণ্য তালিকা (${filteredProducts.size} টি)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = { viewModel.refreshAppData() },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            Icons.Default.Refresh,
                            contentDescription = "Reload",
                            tint = if (isRefreshing) BkashPink else Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = {
                            viewModel.editingProduct.value = null
                            viewModel.scannedBarcodeForProduct.value = ""
                            viewModel.isAddProductOpen.value = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(AppStrings.addProduct(isEnglish), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { viewModel.shareCsvData(context) },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("CSV", fontSize = 11.sp)
                    }
                }
            }

            // Multi-selection bar
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val allSelected = filteredProducts.isNotEmpty() && selectedIds.size == filteredProducts.size
                    Checkbox(
                        checked = allSelected,
                        onCheckedChange = { viewModel.selectAllProducts(it) },
                        colors = CheckboxDefaults.colors(checkedColor = BkashPink)
                    )
                    Text(
                        text = if (isEnglish) "Select All (${filteredProducts.size})" else "সব সিলেক্ট (${filteredProducts.size} টি)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (selectedIds.isNotEmpty() && userRole == "owner") {
                    IconButton(onClick = { viewModel.deleteSelectedProducts() }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = AlertRed)
                    }
                }
            }
            HorizontalDivider(color = if (isDarkMode) Color(0xFF333333) else Color(0xFFEEEEEE))
        }

        // Product List Items
        if (filteredProducts.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isEnglish) "No matching products found in inventory!" else "কোন পণ্য পাওয়া যায়নি!",
                        color = Color.Gray,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            items(filteredProducts, key = { it.id }) { product ->
                ProductListItem(
                    product = product,
                    userRole = userRole,
                    isDarkMode = isDarkMode,
                    isEnglish = isEnglish,
                    isSelected = selectedIds.contains(product.id),
                    onToggleSelect = { viewModel.toggleProductSelection(product.id) },
                    onItemClick = {
                        viewModel.scannedProductForAction.value = product
                        viewModel.isScanActionDialogOpen.value = true
                    },
                    onQuickAddToCart = { viewModel.addToCart(product) },
                    onEdit = {
                        viewModel.editingProduct.value = product
                        viewModel.isAddProductOpen.value = true
                    }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(90.dp))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ProductListItem(
    product: Product,
    userRole: String,
    isDarkMode: Boolean = false,
    isSelected: Boolean,
    isEnglish: Boolean = false,
    onToggleSelect: () -> Unit,
    onItemClick: () -> Unit,
    onQuickAddToCart: () -> Unit,
    onEdit: () -> Unit
) {
    val isCriticalLow = product.stock in 1..5
    val isOutOfStock = product.stock <= 0

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .combinedClickable(
                onClick = onItemClick,
                onLongClick = onEdit
            ),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                if (isDarkMode) Color(0xFF3D1822) else Color(0xFFFFEBEE)
            } else if (isOutOfStock) {
                if (isDarkMode) Color(0xFF2E1517) else Color(0xFFFFEBEE)
            } else if (isCriticalLow) {
                if (isDarkMode) Color(0xFF28181A) else Color(0xFFFFF5F5)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        border = if (isOutOfStock) androidx.compose.foundation.BorderStroke(1.dp, AlertRed.copy(alpha = 0.6f))
                 else if (isCriticalLow) androidx.compose.foundation.BorderStroke(1.dp, AlertRed.copy(alpha = 0.5f))
                 else null,
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = isSelected,
                onCheckedChange = { onToggleSelect() },
                colors = CheckboxDefaults.colors(checkedColor = BkashPink)
            )

            Column(modifier = Modifier.weight(1.3f)) {
                Text(
                    text = product.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = product.barcode,
                    fontSize = 10.sp,
                    color = Color.Gray,
                    fontFamily = FontFamily.Monospace
                )

                // REQUIREMENT 11: Warning badge with Bengali text "পণ্য শেষের দিকে... X টি পণ্য stock এ আছে"
                if (isOutOfStock) {
                    Text(
                        text = if (isEnglish) "Out of Stock!" else "স্টক শেষ!",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = AlertRed
                    )
                } else if (isCriticalLow) {
                    Text(
                        text = AppStrings.lowStockBadge(isEnglish, product.stock),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = AlertRed
                    )
                }
            }

            // BUY PRICE (Owner only)
            if (userRole == "owner") {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isDarkMode) Color(0xFF2E1738) else Color(0xFFF3E5F5),
                    modifier = Modifier.padding(horizontal = 3.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "৳ ${product.buyPrice.toInt()}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = if (isDarkMode) Color(0xFFCE93D8) else Color(0xFF6A1B9A)
                        )
                        Text(if (isEnglish) "Buy" else "ক্রয়", fontSize = 8.sp, color = Color.Gray)
                    }
                }
            }

            // SELL PRICE
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = if (isDarkMode) Color(0xFF132B18) else Color(0xFFE8F5E9),
                modifier = Modifier.padding(horizontal = 3.dp)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "৳ ${product.sellPrice.toInt()}",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 12.5.sp,
                        color = SuccessGreen
                    )
                    Text(if (isEnglish) "Sell" else "বিক্রয়", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                }
            }

            // TOTAL CURRENT STOCK BADGE
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = if (isOutOfStock) Color(0xFFFFCDD2)
                        else if (isCriticalLow) Color(0xFFFFEBEE)
                        else (if (isDarkMode) Color(0xFF1E281E) else Color(0xFFF1F8E9)),
                border = if (isOutOfStock) androidx.compose.foundation.BorderStroke(1.dp, AlertRed)
                         else if (isCriticalLow) androidx.compose.foundation.BorderStroke(1.dp, AlertRed)
                         else null,
                modifier = Modifier.padding(horizontal = 3.dp)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isOutOfStock) (if (isEnglish) "0" else "০") else "${product.stock}",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 11.sp,
                        color = if (isOutOfStock || isCriticalLow) AlertRed else Color(0xFF33691E)
                    )
                    Text(
                        text = if (isOutOfStock) (if (isEnglish) "Out" else "শেষ")
                        else if (isCriticalLow) (if (isEnglish) "Low" else "কম")
                        else (if (isEnglish) "Stock" else "স্টক"),
                        fontSize = 7.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isOutOfStock || isCriticalLow) AlertRed else Color.Gray
                    )
                }
            }

            // LAST ADDED QUANTITY BADGE
            if (product.lastAddedQty > 0) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isDarkMode) Color(0xFF1E2835) else Color(0xFFE3F2FD),
                    modifier = Modifier.padding(horizontal = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "+${product.lastAddedQty}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = Color(0xFF1565C0)
                        )
                        Text(
                            text = if (isEnglish) "Last" else "যোগ",
                            fontSize = 7.sp,
                            color = Color(0xFF1565C0)
                        )
                    }
                }
            }

            IconButton(
                onClick = onQuickAddToCart,
                enabled = !isOutOfStock,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    Icons.Default.AddShoppingCart,
                    contentDescription = "Add to Cart",
                    tint = if (isOutOfStock) Color.LightGray else BkashPink,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
