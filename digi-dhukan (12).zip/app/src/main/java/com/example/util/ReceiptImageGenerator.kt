package com.example.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.CartItem
import java.io.File
import java.io.FileOutputStream

data class ReceiptData(
    val shopName: String,
    val address: String,
    val phone: String,
    val bossName: String,
    val items: List<CartItem>,
    val totalAmount: Double,
    val dateFormatted: String,
    val customerPhone: String = ""
) {
    fun toWhatsAppFormattedString(): String {
        val sb = StringBuilder()
        sb.append("🧾 *${shopName}*\n")
        sb.append("📍 ${address}\n")
        sb.append("📞 মোবাইল: ${phone} | স্বত্বাধিকারী: ${bossName}\n")
        sb.append("📅 তারিখ: ${dateFormatted}\n")
        if (customerPhone.isNotBlank()) {
            sb.append("👤 কাস্টমার: ${customerPhone}\n")
        }
        sb.append("--------------------------------\n")
        items.forEach { item ->
            sb.append("${item.product.name} x ${item.quantity} = ৳${item.totalCost.toInt()}\n")
        }
        sb.append("--------------------------------\n")
        sb.append("💰 *মোট বিল: ৳${totalAmount.toInt()}*\n")
        sb.append("ধন্যবাদ! আবার আসবেন। 🛍️\n")
        return sb.toString()
    }
}

object ReceiptImageGenerator {

    fun generateReceiptBitmap(receipt: ReceiptData): Bitmap {
        val width = 640
        val baseHeight = 540
        val itemHeight = 40
        val totalHeight = baseHeight + (receipt.items.size * itemHeight)

        val bitmap = Bitmap.createBitmap(width, totalHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val paint = Paint().apply {
            isAntiAlias = true
            color = Color.BLACK
        }

        var y = 55f

        // Brand / Shop Name
        paint.textSize = 32f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.color = Color.parseColor("#E2136E")
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText(receipt.shopName, (width / 2).toFloat(), y, paint)

        // Address
        y += 35f
        paint.textSize = 18f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.color = Color.parseColor("#334155")
        canvas.drawText(receipt.address, (width / 2).toFloat(), y, paint)

        // Contact
        y += 28f
        paint.textSize = 16f
        paint.color = Color.parseColor("#475569")
        canvas.drawText("মোবাইল: ${receipt.phone} | স্বত্বাধিকারী: ${receipt.bossName}", (width / 2).toFloat(), y, paint)

        // Divider
        y += 24f
        paint.strokeWidth = 2f
        paint.color = Color.LTGRAY
        canvas.drawLine(40f, y, (width - 40).toFloat(), y, paint)

        // Date and Customer Info
        y += 30f
        paint.textAlign = Paint.Align.LEFT
        paint.textSize = 16f
        paint.color = Color.DKGRAY
        canvas.drawText("তারিখ: ${receipt.dateFormatted}", 45f, y, paint)
        if (receipt.customerPhone.isNotBlank()) {
            paint.textAlign = Paint.Align.RIGHT
            canvas.drawText("কাস্টমার: ${receipt.customerPhone}", (width - 45).toFloat(), y, paint)
        }

        // Table Header
        y += 32f
        paint.color = Color.parseColor("#F1F5F9")
        canvas.drawRect(40f, y - 24f, (width - 40).toFloat(), y + 12f, paint)
        paint.color = Color.BLACK
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textAlign = Paint.Align.LEFT
        canvas.drawText("পণ্যের নাম", 50f, y, paint)
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("পরিমাণ", (width / 2).toFloat(), y, paint)
        paint.textAlign = Paint.Align.RIGHT
        canvas.drawText("দাম (টাকা)", (width - 50).toFloat(), y, paint)

        // Items
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        for (item in receipt.items) {
            y += itemHeight.toFloat()
            paint.textAlign = Paint.Align.LEFT
            paint.color = Color.BLACK
            val name = if (item.product.name.length > 22) item.product.name.substring(0, 20) + ".." else item.product.name
            canvas.drawText(name, 50f, y, paint)

            paint.textAlign = Paint.Align.CENTER
            paint.color = Color.DKGRAY
            canvas.drawText("${item.quantity}", (width / 2).toFloat(), y, paint)

            paint.textAlign = Paint.Align.RIGHT
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.color = Color.parseColor("#2E7D32")
            canvas.drawText("৳ ${item.totalCost.toInt()}", (width - 50).toFloat(), y, paint)
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }

        // Bottom Divider
        y += 25f
        paint.color = Color.LTGRAY
        paint.strokeWidth = 2f
        canvas.drawLine(40f, y, (width - 40).toFloat(), y, paint)

        // Total
        y += 42f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 26f
        paint.textAlign = Paint.Align.LEFT
        paint.color = Color.BLACK
        canvas.drawText("সর্বমোট বিল (Total):", 50f, y, paint)

        paint.textAlign = Paint.Align.RIGHT
        paint.color = Color.parseColor("#2E7D32")
        canvas.drawText("৳ ${receipt.totalAmount.toInt()}", (width - 50).toFloat(), y, paint)

        // Barcode visual representation
        y += 32f
        val barcodeBitmap = BarcodeUtil.generateBarcodeBitmap("RCPT-${System.currentTimeMillis() % 1000000}", width = 380, height = 55)
        if (barcodeBitmap != null) {
            canvas.drawBitmap(barcodeBitmap, ((width - 380) / 2).toFloat(), y, null)
            y += 65f
        }

        // Thank you note
        y += 20f
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 17f
        paint.color = Color.GRAY
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("ধন্যবাদ! আবার আসবেন।", (width / 2).toFloat(), y, paint)

        return bitmap
    }

    fun saveReceiptToGallery(context: Context, receipt: ReceiptData): Uri? {
        val bitmap = generateReceiptBitmap(receipt)
        val filename = "DigiDhukan_Receipt_${System.currentTimeMillis()}.jpg"
        var uri: Uri? = null

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/DigiDhukan")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { stream ->
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
                    }
                    contentValues.clear()
                    contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, contentValues, null, null)
                }
            } else {
                val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                val appDir = File(picturesDir, "DigiDhukan").apply { mkdirs() }
                val imageFile = File(appDir, filename)
                FileOutputStream(imageFile).use { stream ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
                }
                uri = Uri.fromFile(imageFile)
                val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE).apply {
                    data = uri
                }
                context.sendBroadcast(mediaScanIntent)
            }
            Toast.makeText(
                context,
                "রসিদের ছবি গ্যালারিতে সেভ হয়েছে! (Pictures/DigiDhukan)",
                Toast.LENGTH_LONG
            ).show()
            NotificationHelper.sendExportCompleteNotification(context, "ক্যাশ মেমো (JPG)")
        } catch (e: Exception) {
            e.printStackTrace()
            try {
                val cacheDir = File(context.cacheDir, "receipts").apply { mkdirs() }
                val fallbackFile = File(cacheDir, filename)
                FileOutputStream(fallbackFile).use { stream ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
                }
                uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", fallbackFile)
                Toast.makeText(context, "রসিদ সংরক্ষিত হয়েছে!", Toast.LENGTH_SHORT).show()
                NotificationHelper.sendExportCompleteNotification(context, "ক্যাশ মেমো (JPG)")
            } catch (ex: Exception) {
                ex.printStackTrace()
                Toast.makeText(context, "সংরক্ষণে সমস্যা: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
        return uri
    }

    fun getReceiptImageCacheUri(context: Context, receipt: ReceiptData): Uri? {
        return try {
            val bitmap = generateReceiptBitmap(receipt)
            val cachePath = File(context.cacheDir, "receipts").apply { mkdirs() }
            val file = File(cachePath, "receipt_share_${System.currentTimeMillis()}.jpg")
            FileOutputStream(file).use { stream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
            }
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
