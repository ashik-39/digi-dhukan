package com.example.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix
import java.io.File
import java.io.FileOutputStream

object BarcodeUtil {

    fun generateBarcodeBitmap(
        content: String,
        format: BarcodeFormat = BarcodeFormat.CODE_128,
        width: Int = 600,
        height: Int = 240
    ): Bitmap? {
        if (content.isBlank()) return null
        return try {
            val bitMatrix: BitMatrix = MultiFormatWriter().encode(content, format, width, height)
            val matrixWidth = bitMatrix.width
            val matrixHeight = bitMatrix.height
            val bitmap = Bitmap.createBitmap(matrixWidth, matrixHeight, Bitmap.Config.ARGB_8888)
            for (x in 0 until matrixWidth) {
                for (y in 0 until matrixHeight) {
                    bitmap.setPixel(x, y, if (bitMatrix[x, y]) Color.BLACK else Color.WHITE)
                }
            }
            bitmap
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun generateRandomBarcode(): String {
        val prefix = "894" // Bangladesh retail EAN prefix
        val randomPart = (100000000L + (Math.random() * 899999999L).toLong()).toString()
        return "$prefix$randomPart"
    }

    fun generatePrintableBarcodeCard(
        barcodeText: String,
        shopName: String = "Digi Dhukan"
    ): Bitmap? {
        val rawBarcode = generateBarcodeBitmap(barcodeText, BarcodeFormat.CODE_128, width = 640, height = 220) ?: return null
        val cardWidth = 740
        val cardHeight = 400

        val bitmap = Bitmap.createBitmap(cardWidth, cardHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val paint = Paint().apply { isAntiAlias = true }
        val boldPaint = Paint().apply {
            isAntiAlias = true
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.CENTER
        }

        // Card Border
        paint.color = Color.parseColor("#E2136E")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4f
        canvas.drawRoundRect(10f, 10f, (cardWidth - 10).toFloat(), (cardHeight - 10).toFloat(), 20f, 20f, paint)

        // Shop Name at top
        boldPaint.color = Color.parseColor("#E2136E")
        boldPaint.textSize = 28f
        canvas.drawText(shopName.ifBlank { "Digi Dhukan" }, (cardWidth / 2).toFloat(), 55f, boldPaint)

        // Divider
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#E2E8F0")
        canvas.drawLine(40f, 75f, (cardWidth - 40).toFloat(), 75f, paint)

        // Draw Barcode
        canvas.drawBitmap(rawBarcode, ((cardWidth - 640) / 2).toFloat(), 95f, null)

        // Monospace Digits Under Barcode
        boldPaint.color = Color.BLACK
        boldPaint.typeface = Typeface.MONOSPACE
        boldPaint.textSize = 30f
        canvas.drawText(barcodeText, (cardWidth / 2).toFloat(), 355f, boldPaint)

        return bitmap
    }

    fun saveBarcodeJpgToGallery(
        context: Context,
        barcodeText: String,
        shopName: String = "Digi Dhukan",
        isEnglish: Boolean = false
    ): Uri? {
        val bitmap = generatePrintableBarcodeCard(barcodeText, shopName) ?: return null
        val fileName = "Barcode_${barcodeText}_${System.currentTimeMillis()}.jpg"
        var uri: Uri? = null

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/DigiDhukan_Barcodes")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { stream ->
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
                    }
                    contentValues.clear()
                    contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, contentValues, null, null)
                }
            } else {
                val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                val appDir = File(picturesDir, "DigiDhukan_Barcodes").apply { mkdirs() }
                val imageFile = File(appDir, fileName)
                FileOutputStream(imageFile).use { stream ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
                }
                uri = Uri.fromFile(imageFile)
                val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE).apply {
                    data = uri
                }
                context.sendBroadcast(mediaScanIntent)
            }

            val cacheDir = File(context.cacheDir, "barcodes").apply { mkdirs() }
            val shareFile = File(cacheDir, fileName)
            FileOutputStream(shareFile).use { stream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
            }
            val shareUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", shareFile)

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, shareUri)
                putExtra(Intent.EXTRA_TEXT, "বারকোড: $barcodeText ($shopName)")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "বারকোড JPG প্রিন্ট / শেয়ার"))

            val successMsg = if (isEnglish) "Barcode JPG saved to gallery successfully!" else "বারকোড JPG গ্যালারিতে সেভ হয়েছে!"
            Toast.makeText(context, successMsg, Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "ত্রুটি: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
        return uri
    }
}
