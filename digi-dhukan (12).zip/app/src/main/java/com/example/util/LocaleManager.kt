package com.example.util

enum class AppLanguage {
    BANGLA,
    ENGLISH
}

object AppStrings {
    // Top Bar & App Identity
    fun appTitle(isEnglish: Boolean) = if (isEnglish) "Digi Dhukan" else "ডিজি দোকান"
    fun owner(isEnglish: Boolean) = if (isEnglish) "Owner" else "মালিক"
    fun cashier(isEnglish: Boolean) = if (isEnglish) "Cashier" else "ক্যাশিয়ার"
    fun refreshApp(isEnglish: Boolean) = if (isEnglish) "Refresh App / Reload" else "ডাটা রিলোড / রিফ্রেশ"

    // Tabs
    fun tabInventory(isEnglish: Boolean) = if (isEnglish) "Inventory" else "পণ্য তালিকা"
    fun tabDueBook(isEnglish: Boolean) = if (isEnglish) "Due Book" else "বাকি খাতা"
    fun tabMemoSlips(isEnglish: Boolean) = if (isEnglish) "Memo Slips" else "মেমো রসিদ"
    fun tabSalesReport(isEnglish: Boolean) = if (isEnglish) "Sales Report" else "হিসাব নিকাশ"
    fun scan(isEnglish: Boolean) = if (isEnglish) "Scan" else "স্ক্যান"

    // Dashboard Cards & Inventory
    fun totalProducts(isEnglish: Boolean) = if (isEnglish) "Total Products" else "মোট পণ্য"
    fun totalDues(isEnglish: Boolean) = if (isEnglish) "Total Dues" else "মোট বাকি"
    fun totalSales(isEnglish: Boolean) = if (isEnglish) "Total Sales" else "মোট বিক্রি"
    fun totalProfit(isEnglish: Boolean) = if (isEnglish) "Total Profit" else "মোট লাভ"
    fun searchPlaceholder(isEnglish: Boolean) = if (isEnglish) "Search by product name or barcode..." else "পণ্যের নাম বা বারকোড খুঁজুন..."
    fun dueSearchPlaceholder(isEnglish: Boolean) = if (isEnglish) "Search customer name or phone..." else "কাস্টমারের নাম বা মোবাইল দিয়ে খুঁজুন..."
    fun memoSearchPlaceholder(isEnglish: Boolean) = if (isEnglish) "Search supplier name or memo no..." else "মহাজন/সাপ্লায়ার বা মেমো নং খুঁজুন..."
    fun salesSearchPlaceholder(isEnglish: Boolean) = if (isEnglish) "Search invoice or phone..." else "চালান নং বা ফোন দিয়ে খুঁজুন..."

    // Alerts - REQUIREMENT 11: Bengali text update: "পণ্য শেষের দিকে... X টি পণ্য stock এ আছে"
    fun lowStockAlert(isEnglish: Boolean, count: Int) =
        if (isEnglish) "Low Stock: Only $count items left in stock!" else "পণ্য শেষের দিকে... $count টি পণ্য stock এ আছে"

    fun lowStockBadge(isEnglish: Boolean, count: Int) =
        if (isEnglish) "Low Stock: Only $count left" else "পণ্য শেষের দিকে... $count টি পণ্য stock এ আছে"

    fun viewAll(isEnglish: Boolean) = if (isEnglish) "View All" else "সকল পণ্য"
    fun filterLow(isEnglish: Boolean) = if (isEnglish) "Low Stock" else "কম স্টক"

    // Product labels
    fun buyPrice(isEnglish: Boolean) = if (isEnglish) "Buy Price" else "ক্রয়মূল্য"
    fun sellPrice(isEnglish: Boolean) = if (isEnglish) "Sell Price" else "বিক্রয়মূল্য"
    fun stock(isEnglish: Boolean) = if (isEnglish) "Stock" else "স্টক"
    fun totalCurrentStock(isEnglish: Boolean) = if (isEnglish) "Total Current Stock" else "বর্তমান মোট স্টক"
    fun lastAddedQty(isEnglish: Boolean) = if (isEnglish) "Last Restock Qty" else "সর্বশেষ যোগকৃত"
    fun addProduct(isEnglish: Boolean) = if (isEnglish) "+ Add Product" else "+ নতুন পণ্য"
    fun editProduct(isEnglish: Boolean) = if (isEnglish) "Edit Product" else "পণ্য সম্পাদনা"
    fun selectAll(isEnglish: Boolean) = if (isEnglish) "Select All" else "সব সিলেক্ট"
    fun delete(isEnglish: Boolean) = if (isEnglish) "Delete" else "মুছুন"

    // Actions
    fun addToCart(isEnglish: Boolean) = if (isEnglish) "Add to Cart" else "কার্টে যোগ"
    fun quickSell(isEnglish: Boolean) = if (isEnglish) "Direct Sell" else "সরাসরি বিক্রি"
    fun restock(isEnglish: Boolean) = if (isEnglish) "Add Stock" else "স্টক বৃদ্ধি"
    fun autoGenerateBarcode(isEnglish: Boolean) = if (isEnglish) "⚡ Auto Code" else "⚡ অটো কোড"

    // Due Ledger
    fun newDue(isEnglish: Boolean) = if (isEnglish) "+ New Due" else "+ নতুন বাকি"
    fun customerName(isEnglish: Boolean) = if (isEnglish) "Customer Name" else "কাস্টমারের নাম"
    fun phone(isEnglish: Boolean) = if (isEnglish) "Phone Number" else "মোবাইল নম্বর"
    fun dueAmount(isEnglish: Boolean) = if (isEnglish) "Due Amount (৳)" else "বাকির পরিমাণ (৳)"
    fun description(isEnglish: Boolean) = if (isEnglish) "Description / Items" else "বিবরণ / মালামাল"
    fun settleDue(isEnglish: Boolean) = if (isEnglish) "Settle" else "পরিশোধ"
    fun addDueAmount(isEnglish: Boolean) = if (isEnglish) "+ Add Due" else "+ বাকি বৃদ্ধি"
    fun subtractDueAmount(isEnglish: Boolean) = if (isEnglish) "- Payment" else "- টাকা জমা"
    fun addDescription(isEnglish: Boolean) = if (isEnglish) "Add Note Item" else "পণ্য/বিবরণ লিখুন"

    // Wholesale Supplier Memos
    fun addMemo(isEnglish: Boolean) = if (isEnglish) "+ Add Memo" else "+ নতুন মেমো"
    fun editMemo(isEnglish: Boolean) = if (isEnglish) "Edit Memo" else "মেমো পরিবর্তন"
    fun supplierName(isEnglish: Boolean) = if (isEnglish) "Supplier / Mahajan Name" else "মহাজন / কোম্পানির নাম"
    fun memoNo(isEnglish: Boolean) = if (isEnglish) "Memo / Invoice No." else "মেমো / ভাউচার নং"
    fun memoAmount(isEnglish: Boolean) = if (isEnglish) "Total Purchase Amount (৳)" else "মোট ক্রয়ের পরিমাণ (৳)"
    fun attachMemoPhoto(isEnglish: Boolean) = if (isEnglish) "Attach Memo Photo (Camera/Gallery)" else "মেমোর ছবি সংযুক্ত করুন (ক্যামেরা/গ্যালারি)"
    fun memoArrivalDate(isEnglish: Boolean) = if (isEnglish) "Memo Arrival Date" else "মালামাল পৌঁছানোর তারিখ"

    // Date Range in Sales Report
    fun startDate(isEnglish: Boolean) = if (isEnglish) "Start Date" else "শুরুর তারিখ"
    fun endDate(isEnglish: Boolean) = if (isEnglish) "End Date" else "শেষের তারিখ"
    fun selectDateRange(isEnglish: Boolean) = if (isEnglish) "Custom Date Range" else "নির্দিষ্ট তারিখ অনুযায়ী"
    fun filterSales(isEnglish: Boolean) = if (isEnglish) "Filter" else "ফিল্টার"
    fun clearFilter(isEnglish: Boolean) = if (isEnglish) "Reset" else "রিসেট"

    // Reports
    fun downloadMonthlySummary(isEnglish: Boolean) =
        if (isEnglish) "Download Monthly Summary" else "১ মাসের পূর্ণাঙ্গ রিপোর্ট ডাউনলোড"
    fun downloadInventoryStockList(isEnglish: Boolean) =
        if (isEnglish) "Download Inventory Stock List" else "স্টকের পূর্ণাঙ্গ তালিকা ডাউনলোড"
    fun offlineBackup(isEnglish: Boolean) =
        if (isEnglish) "Offline Database Backup (JSON)" else "অফলাইন ডাটা ব্যাকআপ (JSON)"

    // Receipt & Bill Download
    fun cashMemo(isEnglish: Boolean) = if (isEnglish) "Cash Memo / Receipt" else "ক্যাশ মেমো / রশিদ"
    fun totalBill(isEnglish: Boolean) = if (isEnglish) "Total Bill:" else "মোট বিল:"
    fun downloadJpg(isEnglish: Boolean) = if (isEnglish) "Download JPG" else "ছবি ডাউনলোড (JPG)"
    fun shareWhatsApp(isEnglish: Boolean) = if (isEnglish) "WhatsApp Share" else "হোয়াটসঅ্যাপে পাঠান"
    fun shareBluetooth(isEnglish: Boolean) = if (isEnglish) "Bluetooth Share" else "ব্লুটুথে প্রিন্ট/শেয়ার"
    fun shareGeneral(isEnglish: Boolean) = if (isEnglish) "Share Receipt" else "শেয়ার করুন"
    fun thankYou(isEnglish: Boolean) = if (isEnglish) "Thank you! Please visit again. 🛍️" else "ধন্যবাদ! আবার আসবেন। 🛍️"
    fun downloadSuccess(isEnglish: Boolean) = if (isEnglish) "Download complete! Saved successfully." else "ডাউনলোড সফলভাবে সম্পন্ন হয়েছে!"

    // 3-dot Menu & Settings
    fun profileSettings(isEnglish: Boolean) = if (isEnglish) "Store & Profile Settings" else "দোকান ও প্রোফাইল সেটিংস"
    fun customBarcodeGen(isEnglish: Boolean) = if (isEnglish) "Generate Custom Barcode" else "কাস্টম বারকোড তৈরি"
    fun appLockSettings(isEnglish: Boolean) = if (isEnglish) "App Lock & Security Settings" else "অ্যাপ লক ও নিরাপত্তা সেটিংস"
    fun appLockMasterToggle(isEnglish: Boolean) = if (isEnglish) "App Lock Master Switch" else "অ্যাপ লক মাস্টার সুইচ"
    fun biometricFingerprint(isEnglish: Boolean) = if (isEnglish) "Fingerprint Login" else "ফিঙ্গারপ্রিন্ট লগইন"
    fun autoLockTimeout(isEnglish: Boolean) = if (isEnglish) "Auto-Lock Timer" else "অটো লক সময় নির্ধারণ"
    fun autoLockInstant(isEnglish: Boolean) = if (isEnglish) "Instant" else "তাত্ক্ষণিক (সরাসরি)"
    fun autoLockDeviceLock(isEnglish: Boolean) = if (isEnglish) "When device locks" else "মোবাইল লক হলে"
    fun autoLockManualMinutes(isEnglish: Boolean) = if (isEnglish) "Custom Inactivity Minutes" else "নির্দিষ্ট মিনিট পর"
    fun toggleLiveChart(isEnglish: Boolean, isEnabled: Boolean) =
        if (isEnglish) if (isEnabled) "Hide Profit Chart" else "Show Profit Chart"
        else if (isEnabled) "গ্রাফ বন্ধ করুন" else "গ্রাফ চালু করুন"
    fun lockApp(isEnglish: Boolean) = if (isEnglish) "Lock App Session" else "অ্যাপ লক করুন"
    fun switchLanguage(isEnglish: Boolean) = if (isEnglish) "বাংলা ভাষা" else "Switch to English"
    fun toggleDarkMode(isEnglish: Boolean, isDark: Boolean) =
        if (isEnglish) if (isDark) "Light Mode ☀️" else "Dark Mode 🌙"
        else if (isDark) "লাইট মোড ☀️" else "ডার্ক মোড 🌙"

    // Valuation & Settlement & Notification Center
    fun totalStockValuation(isEnglish: Boolean) = if (isEnglish) "Total Stock Valuation" else "দোকানের মোট স্টক মূল্য"
    fun settleFullDue(isEnglish: Boolean) = if (isEnglish) "Settle Full Due" else "সম্পূর্ণ বাকি পরিশোধ"
    fun settledHistoryLog(isEnglish: Boolean) = if (isEnglish) "Settled / History Log" else "পরিশোধিত / পূর্বের হিসাব"
    fun activeDues(isEnglish: Boolean) = if (isEnglish) "Active Dues" else "চলতি বাকি"
    fun notificationCenter(isEnglish: Boolean) = if (isEnglish) "Notification Center" else "নোটিফিকেশন সেন্টার"
    fun clearAllNotifications(isEnglish: Boolean) = if (isEnglish) "Clear All" else "সব মুছুন"
    fun deleteSelected(isEnglish: Boolean) = if (isEnglish) "Delete Selected" else "নির্বাচিতগুলো মুছুন"
    fun markAllRead(isEnglish: Boolean) = if (isEnglish) "Mark All as Read" else "সব পঠিত চিহ্নিত করুন"
    fun launchLockPriority(isEnglish: Boolean) = if (isEnglish) "App Launch Priority" else "অ্যাপ খোলার অগ্রাধিকার"
    fun fingerprintFirst(isEnglish: Boolean) = if (isEnglish) "Fingerprint First" else "আগে ফিঙ্গারপ্রিন্ট"
    fun pinFirst(isEnglish: Boolean) = if (isEnglish) "PIN Lock First" else "আগে পিন (PIN) লক"

    // Password Lock Screen
    fun enterPinToUnlock(isEnglish: Boolean) = if (isEnglish) "Enter 4-Digit PIN to Unlock" else "৪-সংখ্যার গোপন পিন নম্বর দিয়ে আনলক করুন"
    fun unlock(isEnglish: Boolean) = if (isEnglish) "Unlock" else "আনলক"
    fun cloudSync(isEnglish: Boolean) = if (isEnglish) "Firebase Realtime Sync" else "রিয়েল-টাইম ক্লাউড সিঙ্ক"
    fun syncNow(isEnglish: Boolean) = if (isEnglish) "Sync All Data" else "সকল ডাটা সিঙ্ক করুন"

    // In-App Update
    fun appUpdateAvailable(isEnglish: Boolean) = if (isEnglish) "New Update Available!" else "নতুন আপডেট পাওয়া গেছে!"
    fun updateNow(isEnglish: Boolean) = if (isEnglish) "Update Now" else "এখনই আপডেট করুন"
    fun updateLater(isEnglish: Boolean) = if (isEnglish) "Later" else "পরে"
    fun checkForUpdates(isEnglish: Boolean) = if (isEnglish) "Check for Updates" else "নতুন আপডেট চেক করুন"

    // User Auth & Google Drive
    fun googleSignIn(isEnglish: Boolean) = if (isEnglish) "Sign in with Google" else "গুগল একাউন্ট দিয়ে লগইন"
    fun googleDriveBackup(isEnglish: Boolean) = if (isEnglish) "Google Drive Cloud Backup" else "গুগল ড্রাইভ ও ক্লাউড ব্যাকআপ"
    fun exportToDrive(isEnglish: Boolean) = if (isEnglish) "Backup to Google Drive" else "গুগল ড্রাইভে ব্যাকআপ রাখুন"
    fun restoreFromBackup(isEnglish: Boolean) = if (isEnglish) "Restore from Backup JSON" else "ব্যাকআপ ফাইল থেকে রিস্টোর"
}

// Utility extension to convert both English ('0'-'9') and Bengali ('০'-'৯') numerals to standard ASCII digits
fun String.normalizeDigits(): String {
    return this.map { ch ->
        when (ch) {
            '০' -> '0'
            '১' -> '1'
            '২' -> '2'
            '৩' -> '3'
            '৪' -> '4'
            '৫' -> '5'
            '৬' -> '6'
            '৭' -> '7'
            '৮' -> '8'
            '৯' -> '9'
            else -> ch
        }
    }.joinToString("")
}
