package com.example.util

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log

object SoundHapticHelper {
    private const val TAG = "SoundHapticHelper"
    private var toneGenerator: ToneGenerator? = null

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85)
        } catch (e: Exception) {
            Log.w(TAG, "ToneGenerator init failed: ${e.message}")
        }
    }

    /**
     * Subtle, pleasant beep and quick tick when any barcode is detected by CameraX
     */
    fun playScanTick(context: Context) {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 70)
        } catch (e: Exception) {
            try {
                val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70)
                tg.startTone(ToneGenerator.TONE_PROP_BEEP, 70)
            } catch (_: Exception) {}
        }
        triggerHaptic(context, durationMs = 35)
    }

    /**
     * Confirmatory, affirmative sound and haptic when barcode scanner successfully matches/identifies a product
     */
    fun playProductIdentifiedSuccess(context: Context) {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 140)
        } catch (e: Exception) {
            try {
                val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90)
                tg.startTone(ToneGenerator.TONE_PROP_ACK, 140)
            } catch (_: Exception) {}
        }
        triggerHaptic(context, durationMs = 60)
    }

    private fun triggerHaptic(context: Context, durationMs: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(durationMs)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Haptic trigger error: ${e.message}")
        }
    }
}
