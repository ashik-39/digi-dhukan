package com.example.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.CustomerDue
import com.example.data.OfflineBackupData
import com.example.data.Product
import com.example.data.SaleTransaction
import com.example.data.StoreProfile
import com.example.data.SupplierMemo
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfReportGenerator {

    /**
     * 1-Click Comprehensive 1-Month Monthly Report Export
     * Exports:
     * - Full 1-Month Store Ledger & Sales Summary
     * - Cash Memos & Supplier Memo slips with attached photos
     * - Detailed Customer Due Book breakdown
     */
    fun generateComprehensiveMonthlyReportPdf(
        context: Context,
        storeProfile: StoreProfile,
        transactions: List<SaleTransaction>,
        dues: List<CustomerDue>,
        memos: List<SupplierMemo>,
        products: List<Product>,
        isEnglish: Boolean = false
    ) {
        try {
            val pdfDocument = PdfDocument()
            val pageWidth = 595
            val pageHeight = 842
            var pageNumber = 1

            var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            var page = pdfDocument.startPage(pageInfo)
            var canvas = page.canvas

            val paint = Paint().apply { isAntiAlias = true }
            val boldPaint = Paint().apply {
                isAntiAlias = true
                typeface = Typeface.DEFAULT_BOLD
            }

            fun drawHeader(canv: Canvas, title: String) {
                paint.color = Color.parseColor("#E2136E")
                canv.drawRect(0f, 0f, pageWidth.toFloat(), 110f, paint)

                boldPaint.color = Color.WHITE
                boldPaint.textSize = 22f
                canv.drawText(storeProfile.shopName.ifBlank { "Digi Dhukan" }, 30f, 40f, boldPaint)

                paint.color = Color.WHITE
                paint.textSize = 11f
                val sub = "${storeProfile.address} | মোবাইল: ${storeProfile.phone} | স্বত্বাধিকারী: ${storeProfile.bossName}"
                canv.drawText(sub, 30f, 62f, paint)

                boldPaint.textSize = 13f
                canv.drawText(title, 30f, 85f, boldPaint)

                val currentDate = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date())
                paint.textSize = 9.5f
                canv.drawText(if (isEnglish) "Generated: $currentDate (Page $pageNumber)" else "রিপোর্ট তৈরির সময়: $currentDate (পৃষ্ঠা $pageNumber)", 30f, 100f, paint)
            }

            drawHeader(canvas, if (isEnglish) "Comprehensive 1-Month Store Ledger & Sales Summary" else "১ মাসের পূর্ণাঙ্গ বিক্রয় ও দোকান হিসাব রিপোর্ট")

            var y = 135f

            // KPI Summary Boxes
            val totalSales = transactions.sumOf { it.totalAmount }
            val totalProfit = transactions.sumOf { it.totalProfit }
            val totalDue = dues.sumOf { it.amount }
            val totalPurchase = memos.sumOf { it.amount }

            paint.color = Color.parseColor("#F8F9FA")
            canvas.drawRoundRect(25f, y, (pageWidth - 25).toFloat(), y + 60f, 8f, 8f, paint)

            val colW = (pageWidth - 60) / 4f

            // Col 1: Sales
            paint.color = Color.parseColor("#E2136E")
            paint.textSize = 9.5f
            canvas.drawText(if (isEnglish) "TOTAL SALES" else "মোট বিক্রি", 35f, y + 20f, paint)
            boldPaint.color = Color.parseColor("#E2136E")
            boldPaint.textSize = 14f
            canvas.drawText("৳ ${totalSales.toInt()}", 35f, y + 44f, boldPaint)

            // Col 2: Profit
            paint.color = Color.parseColor("#15803D")
            paint.textSize = 9.5f
            canvas.drawText(if (isEnglish) "NET PROFIT" else "নিট লাভ", 35f + colW, y + 20f, paint)
            boldPaint.color = Color.parseColor("#15803D")
            boldPaint.textSize = 14f
            canvas.drawText("৳ ${totalProfit.toInt()}", 35f + colW, y + 44f, boldPaint)

            // Col 3: Dues
            paint.color = Color.parseColor("#B91C1C")
            paint.textSize = 9.5f
            canvas.drawText(if (isEnglish) "TOTAL DUES" else "মোট বাকি", 35f + colW * 2, y + 20f, paint)
            boldPaint.color = Color.parseColor("#B91C1C")
            boldPaint.textSize = 14f
            canvas.drawText("৳ ${totalDue.toInt()}", 35f + colW * 2, y + 44f, boldPaint)

            // Col 4: Wholesale Purchases
            paint.color = Color.parseColor("#1D4ED8")
            paint.textSize = 9.5f
            canvas.drawText(if (isEnglish) "WHOLESALE" else "পাইকারি ক্রয়", 35f + colW * 3, y + 20f, paint)
            boldPaint.color = Color.parseColor("#1D4ED8")
            boldPaint.textSize = 14f
            canvas.drawText("৳ ${totalPurchase.toInt()}", 35f + colW * 3, y + 44f, boldPaint)

            y += 80f

            fun checkPageBreak(neededHeight: Float, title: String) {
                if (y + neededHeight > pageHeight - 40f) {
                    pdfDocument.finishPage(page)
                    pageNumber++
                    pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                    page = pdfDocument.startPage(pageInfo)
                    canvas = page.canvas
                    drawHeader(canvas, title)
                    y = 130f
                }
            }

            // SECTION 1: Sales Transactions & Cash Memos
            boldPaint.color = Color.parseColor("#0F172A")
            boldPaint.textSize = 12f
            canvas.drawText(if (isEnglish) "1. Sales Ledger & Invoices (${transactions.size})" else "১. বিক্রয় হিসাব ও মেমোর তালিকা (${transactions.size} টি)", 30f, y, boldPaint)
            y += 12f

            paint.color = Color.parseColor("#E2E8F0")
            canvas.drawRect(25f, y, (pageWidth - 25).toFloat(), y + 18f, paint)
            boldPaint.color = Color.parseColor("#1E293B")
            boldPaint.textSize = 9f
            canvas.drawText("#", 30f, y + 12f, boldPaint)
            canvas.drawText(if (isEnglish) "Date & Time" else "তারিখ ও সময়", 55f, y + 12f, boldPaint)
            canvas.drawText(if (isEnglish) "Items & Customer" else "পণ্য ও কাস্টমার", 170f, y + 12f, boldPaint)
            canvas.drawText(if (isEnglish) "Total" else "মোট বিল", 440f, y + 12f, boldPaint)
            canvas.drawText(if (isEnglish) "Profit" else "লাভ", 505f, y + 12f, boldPaint)

            y += 22f
            paint.color = Color.parseColor("#334155")
            paint.textSize = 8.5f
            val itemLinePaint = Paint().apply { color = Color.parseColor("#F8FAFC") }

            transactions.take(25).forEachIndexed { index, txn ->
                checkPageBreak(20f, if (isEnglish) "Sales Transactions (Cont.)" else "বিক্রয় হিসাব (চলমান)")
                if (index % 2 == 0) {
                    canvas.drawRect(25f, y - 2f, (pageWidth - 25).toFloat(), y + 14f, itemLinePaint)
                }
                canvas.drawText("${index + 1}", 30f, y + 10f, paint)
                canvas.drawText(txn.dateFormatted, 55f, y + 10f, paint)
                val summary = txn.itemsSummary.replace("\n", ", ").take(45)
                canvas.drawText(summary, 170f, y + 10f, paint)
                canvas.drawText("৳ ${txn.totalAmount.toInt()}", 440f, y + 10f, paint)
                canvas.drawText("৳ ${txn.totalProfit.toInt()}", 505f, y + 10f, paint)
                y += 18f
            }

            y += 20f

            // SECTION 2: Detailed Customer Due Ledger
            checkPageBreak(65f, if (isEnglish) "Customer Due Ledger Summary" else "বাকি খাতার সংক্ষিপ্ত বিবরণ")
            boldPaint.color = Color.parseColor("#0F172A")
            boldPaint.textSize = 12f
            canvas.drawText(if (isEnglish) "2. Customer Due Book Details (${dues.size})" else "২. কাস্টমার বাকি খাতার পূর্ণ বিবরণ (${dues.size} জন)", 30f, y, boldPaint)
            y += 12f

            paint.color = Color.parseColor("#FEE2E2")
            canvas.drawRect(25f, y, (pageWidth - 25).toFloat(), y + 18f, paint)
            boldPaint.color = Color.parseColor("#991B1B")
            boldPaint.textSize = 9f
            canvas.drawText(if (isEnglish) "Customer" else "কাস্টমার", 30f, y + 12f, boldPaint)
            canvas.drawText(if (isEnglish) "Phone" else "মোবাইল নম্বর", 160f, y + 12f, boldPaint)
            canvas.drawText(if (isEnglish) "Note / Items" else "পণ্যের বিবরণ", 260f, y + 12f, boldPaint)
            canvas.drawText(if (isEnglish) "Due (৳)" else "বাকি (৳)", 470f, y + 12f, boldPaint)

            y += 22f
            paint.color = Color.parseColor("#1F2937")

            dues.take(20).forEach { due ->
                checkPageBreak(18f, if (isEnglish) "Customer Due Book (Cont.)" else "বাকি খাতা (চলমান)")
                canvas.drawText(due.customerName, 30f, y + 10f, paint)
                canvas.drawText(due.phone, 160f, y + 10f, paint)
                canvas.drawText(due.note.take(35), 260f, y + 10f, paint)
                boldPaint.color = Color.parseColor("#DC2626")
                boldPaint.textSize = 9f
                canvas.drawText("৳ ${due.amount.toInt()}", 470f, y + 10f, boldPaint)
                y += 18f
            }

            y += 20f

            // SECTION 3: Supplier Wholesale Memos with Attached Photos
            checkPageBreak(90f, if (isEnglish) "Supplier Memos & Photo Slips" else "মহাজন মেমো ও রসিদের ছবি")
            boldPaint.color = Color.parseColor("#0F172A")
            boldPaint.textSize = 12f
            canvas.drawText(if (isEnglish) "3. Wholesale Supplier Memos & Slip Images (${memos.size})" else "৩. মহাজন পাইকারি মেমো ও ভাউচারের ছবি (${memos.size} টি)", 30f, y, boldPaint)
            y += 14f

            memos.take(15).forEachIndexed { i, memo ->
                val hasPhoto = memo.photoUri.isNotBlank()
                val cardHeight = if (hasPhoto) 175f else 55f

                checkPageBreak(cardHeight + 10f, if (isEnglish) "Supplier Memos (Cont.)" else "মহাজন মেমো তালিকা (চলমান)")

                val cardRect = RectF(25f, y, pageWidth - 25f, y + cardHeight)
                paint.color = Color.parseColor("#F8FAFC")
                paint.style = Paint.Style.FILL
                canvas.drawRoundRect(cardRect, 6f, 6f, paint)

                paint.color = Color.parseColor("#CBD5E1")
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 0.8f
                canvas.drawRoundRect(cardRect, 6f, 6f, paint)
                paint.style = Paint.Style.FILL

                // Ribbon
                paint.color = Color.parseColor("#1E88E5")
                canvas.drawRoundRect(RectF(25f, y, pageWidth - 25f, y + 20f), 6f, 6f, paint)
                boldPaint.color = Color.WHITE
                boldPaint.textSize = 9.5f
                canvas.drawText("${i + 1}. মেমো নং: #${memo.memoNo} | মহাজন: ${memo.supplierName}", 32f, y + 14f, boldPaint)
                canvas.drawText("৳ ${memo.amount.toInt()}", pageWidth - 90f, y + 14f, boldPaint)

                paint.color = Color.DKGRAY
                paint.textSize = 9f
                canvas.drawText("তারিখ: ${memo.date} | বিবরণ: ${memo.note.ifBlank { "বিবরণ নেই" }}", 32f, y + 36f, paint)

                if (hasPhoto) {
                    val bitmap = loadSampledBitmapFromUri(context, memo.photoUri, 250, 160)
                    if (bitmap != null) {
                        val photoLeft = 32f
                        val photoTop = y + 48f
                        val destRect = RectF(photoLeft, photoTop, photoLeft + 190f, photoTop + 115f)
                        canvas.drawBitmap(bitmap, null, destRect, null)
                        paint.color = Color.GRAY
                        paint.textSize = 8.5f
                        canvas.drawText("সংযুক্ত মেমো রসিদের ছবি", photoLeft + 200f, photoTop + 25f, paint)
                        canvas.drawText("কোম্পানি: ${memo.supplierName}", photoLeft + 200f, photoTop + 45f, paint)
                        canvas.drawText("মোট ক্রয়: ৳ ${memo.amount.toInt()}", photoLeft + 200f, photoTop + 65f, paint)
                        bitmap.recycle()
                    }
                }

                y += cardHeight + 8f
            }

            pdfDocument.finishPage(page)

            val fileName = "DigiDhukan_Monthly_Summary_${System.currentTimeMillis()}.pdf"
            val cacheDir = File(context.cacheDir, "reports").apply { mkdirs() }
            val file = File(cacheDir, fileName)
            FileOutputStream(file).use { pdfDocument.writeTo(it) }
            pdfDocument.close()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    val contentValues = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                        put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/DigiDhukan")
                    }
                    val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                    if (uri != null) {
                        context.contentResolver.openOutputStream(uri)?.use { os ->
                            file.inputStream().use { input -> input.copyTo(os) }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "দোকানের পূর্ণাঙ্গ মাসিক হিসাব - ${storeProfile.shopName}")
                putExtra(Intent.EXTRA_TEXT, "${storeProfile.shopName} এর সম্পূর্ণ হিসাব রিপোর্ট (PDF)")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "রিপোর্ট শেয়ার করুন (PDF)"))

            Toast.makeText(context, if (isEnglish) "Download complete! 1-Month Summary saved." else "১ মাসের পূর্ণাঙ্গ রিপোর্ট সফলভাবে সংরক্ষিত হয়েছে!", Toast.LENGTH_LONG).show()
            NotificationHelper.sendExportCompleteNotification(context, if (isEnglish) "1-Month Summary Report (PDF)" else "১ মাসের পূর্ণাঙ্গ রিপোর্ট (PDF)", isEnglish)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "ত্রুটি: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    /**
     * Inventory Stock List Export (PDF)
     */
    fun generateInventoryStockPdf(
        context: Context,
        storeProfile: StoreProfile,
        products: List<Product>,
        isEnglish: Boolean = false
    ) {
        try {
            val pdfDocument = PdfDocument()
            val pageWidth = 595
            val pageHeight = 842
            var pageNumber = 1

            var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            var page = pdfDocument.startPage(pageInfo)
            var canvas = page.canvas

            val paint = Paint().apply { isAntiAlias = true }
            val boldPaint = Paint().apply {
                isAntiAlias = true
                typeface = Typeface.DEFAULT_BOLD
            }

            var y = 40f

            fun drawHeader() {
                paint.color = Color.parseColor("#E2136E")
                canvas.drawRect(0f, 0f, pageWidth.toFloat(), 105f, paint)

                boldPaint.color = Color.WHITE
                boldPaint.textSize = 20f
                canvas.drawText(storeProfile.shopName.ifBlank { "Digi Dhukan" }, 30f, 38f, boldPaint)

                paint.color = Color.WHITE
                paint.textSize = 10.5f
                canvas.drawText("${storeProfile.address} | মোবাইল: ${storeProfile.phone} | স্বত্বাধিকারী: ${storeProfile.bossName}", 30f, 58f, paint)

                boldPaint.textSize = 13f
                canvas.drawText(if (isEnglish) "INVENTORY STOCK REPORT" else "দোকানের সকল পণ্যের স্টক রিপোর্ট", 30f, 80f, boldPaint)

                val dateStr = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date())
                paint.textSize = 9f
                canvas.drawText(if (isEnglish) "Generated: $dateStr" else "রিপোর্ট তৈরির তারিখ: $dateStr", 30f, 96f, paint)
            }

            fun drawTableHeader(curY: Float) {
                paint.color = Color.parseColor("#E0E7FF")
                canvas.drawRect(25f, curY, (pageWidth - 25).toFloat(), curY + 22f, paint)

                boldPaint.color = Color.parseColor("#1E3A8A")
                boldPaint.textSize = 8.5f
                canvas.drawText("#", 28f, curY + 15f, boldPaint)
                canvas.drawText(if (isEnglish) "Product Name" else "পণ্যের নাম", 48f, curY + 15f, boldPaint)
                canvas.drawText(if (isEnglish) "Barcode" else "বারকোড (SKU)", 195f, curY + 15f, boldPaint)
                canvas.drawText(if (isEnglish) "Stock" else "বর্তমান স্টক", 280f, curY + 15f, boldPaint)
                canvas.drawText(if (isEnglish) "Last Restock" else "সর্বশেষ যোগ", 355f, curY + 15f, boldPaint)
                canvas.drawText(if (isEnglish) "Buy (৳)" else "ক্রয়মূল্য (৳)", 430f, curY + 15f, boldPaint)
                canvas.drawText(if (isEnglish) "Sell (৳)" else "বিক্রয়মূল্য (৳)", 485f, curY + 15f, boldPaint)
                canvas.drawText(if (isEnglish) "Total (৳)" else "মোট মূল্য (৳)", 540f, curY + 15f, boldPaint)
            }

            drawHeader()
            y = 125f

            // Summary KPI
            val totalProducts = products.size
            val totalStockQty = products.sumOf { it.stock }
            val totalBuyValue = products.sumOf { it.buyPrice * it.stock }
            val totalSellValue = products.sumOf { it.sellPrice * it.stock }

            paint.color = Color.parseColor("#F8FAFC")
            canvas.drawRoundRect(25f, y, (pageWidth - 25).toFloat(), y + 48f, 8f, 8f, paint)

            val colW = (pageWidth - 50) / 4f

            boldPaint.textSize = 10f
            boldPaint.color = Color.parseColor("#1E293B")
            paint.textSize = 9f
            paint.color = Color.GRAY

            canvas.drawText(if (isEnglish) "Total Items" else "মোট পণ্য সংখ্যা", 35f, y + 18f, paint)
            canvas.drawText("$totalProducts টি", 35f, y + 36f, boldPaint)

            canvas.drawText(if (isEnglish) "Total Stock Units" else "মোট স্টক পরিমাণ", 35f + colW, y + 18f, paint)
            canvas.drawText("$totalStockQty পিস", 35f + colW, y + 36f, boldPaint)

            canvas.drawText(if (isEnglish) "Cost Valuation" else "মোট কেনা মূল্য", 35f + colW * 2, y + 18f, paint)
            canvas.drawText("৳ ${totalBuyValue.toInt()}", 35f + colW * 2, y + 36f, boldPaint)

            canvas.drawText(if (isEnglish) "Retail Valuation" else "মোট বিক্রয় মূল্য", 35f + colW * 3, y + 18f, paint)
            boldPaint.color = Color.parseColor("#E2136E")
            canvas.drawText("৳ ${totalSellValue.toInt()}", 35f + colW * 3, y + 36f, boldPaint)

            y += 65f
            drawTableHeader(y)
            y += 26f
            paint.textSize = 8.5f

            products.forEachIndexed { index, product ->
                if (y > 780f) {
                    pdfDocument.finishPage(page)
                    pageNumber++
                    pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                    page = pdfDocument.startPage(pageInfo)
                    canvas = page.canvas
                    y = 40f
                    drawTableHeader(y)
                    y += 26f
                }

                if (index % 2 == 1) {
                    paint.color = Color.parseColor("#F8FAFC")
                    canvas.drawRect(25f, y - 12f, (pageWidth - 25).toFloat(), y + 8f, paint)
                }

                paint.color = Color.parseColor("#334155")
                canvas.drawText("${index + 1}", 28f, y, paint)

                val displayName = if (product.name.length > 20) product.name.take(19) + ".." else product.name
                canvas.drawText(displayName, 48f, y, paint)

                val barcodeStr = if (product.barcode.length > 13) product.barcode.take(12) + ".." else product.barcode
                canvas.drawText(barcodeStr, 195f, y, paint)

                if (product.stock <= 5) {
                    boldPaint.color = Color.RED
                    boldPaint.textSize = 8.5f
                    canvas.drawText("${product.stock}", 285f, y, boldPaint)
                } else {
                    paint.color = Color.parseColor("#334155")
                    canvas.drawText("${product.stock}", 285f, y, paint)
                }

                paint.color = Color.parseColor("#1565C0")
                canvas.drawText(if (product.lastAddedQty > 0) "+${product.lastAddedQty}" else "-", 365f, y, paint)

                paint.color = Color.parseColor("#334155")
                canvas.drawText("৳ ${product.buyPrice.toInt()}", 430f, y, paint)
                canvas.drawText("৳ ${product.sellPrice.toInt()}", 485f, y, paint)
                canvas.drawText("৳ ${(product.stock * product.sellPrice).toInt()}", 540f, y, paint)

                y += 20f
            }

            pdfDocument.finishPage(page)

            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val fileName = "DigiDhukan_Stock_${timeStamp}.pdf"
            val file = File(context.cacheDir, fileName)
            val outputStream = FileOutputStream(file)
            pdfDocument.writeTo(outputStream)
            pdfDocument.close()
            outputStream.flush()
            outputStream.close()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    val contentValues = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                        put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/DigiDhukan")
                    }
                    val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                    if (uri != null) {
                        context.contentResolver.openOutputStream(uri)?.use { os ->
                            file.inputStream().use { input -> input.copyTo(os) }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "স্টকের পূর্ণাঙ্গ তালিকা - ${storeProfile.shopName}")
                putExtra(Intent.EXTRA_TEXT, "${storeProfile.shopName} এর স্টক রিপোর্ট (PDF)")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "স্টক রিপোর্ট (PDF) শেয়ার"))

            Toast.makeText(context, if (isEnglish) "Download complete! Stock PDF saved." else "স্টক তালিকা PDF সফলভাবে ডাউনলোড হয়েছে!", Toast.LENGTH_SHORT).show()
            NotificationHelper.sendExportCompleteNotification(context, if (isEnglish) "Inventory Stock Report (PDF)" else "স্টক তালিকা (PDF)", isEnglish)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "স্টক তালিকা PDF তৈরিতে ত্রুটি: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Export full Inventory Stock List as real CSV file
     */
    fun exportInventoryStockCsv(
        context: Context,
        products: List<Product>,
        isEnglish: Boolean = false
    ) {
        try {
            val sb = java.lang.StringBuilder()
            sb.append("\uFEFF") // UTF-8 BOM
            if (isEnglish) {
                sb.append("Sl,Product Name,SKU / Barcode,Category,Total Current Stock,Last Added Quantity,Buying Price (BDT),Selling Price (BDT),Total Valuation (BDT)\n")
            } else {
                sb.append("ক্রম,পণ্যের নাম,বারকোড (SKU),ক্যাটেগরি,বর্তমান মোট স্টক,সর্বশেষ যোগকৃত স্টক,ক্রয়মূল্য (টাকা),বিক্রয়মূল্য (টাকা),মোট মূল্য (টাকা)\n")
            }

            var totalQty = 0
            var totalCost = 0.0
            var totalRetail = 0.0

            products.forEachIndexed { index, p ->
                val lineTotal = p.stock * p.sellPrice
                totalQty += p.stock
                totalCost += (p.stock * p.buyPrice)
                totalRetail += lineTotal

                val cleanName = p.name.replace("\"", "\"\"")
                val cleanBarcode = p.barcode.replace("\"", "\"\"")
                val cleanCategory = p.category.replace("\"", "\"\"")

                sb.append("${index + 1},\"$cleanName\",\"$cleanBarcode\",\"$cleanCategory\",${p.stock},${p.lastAddedQty},${p.buyPrice},${p.sellPrice},${lineTotal}\n")
            }

            if (isEnglish) {
                sb.append("TOTAL,\"Total ${products.size} Products\",\"--\",\"--\",$totalQty,--,${totalCost},${totalRetail},${totalRetail}\n")
            } else {
                sb.append("সর্বমোট,\"মোট ${products.size} টি পণ্য\",\"--\",\"--\",$totalQty,--,${totalCost},${totalRetail},${totalRetail}\n")
            }

            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val fileName = "DigiDhukan_Stock_${timeStamp}.csv"
            val file = File(context.cacheDir, fileName)
            file.writeText(sb.toString(), Charsets.UTF_8)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    val contentValues = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                        put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/DigiDhukan")
                    }
                    val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                    if (uri != null) {
                        context.contentResolver.openOutputStream(uri)?.use { os ->
                            file.inputStream().use { input -> input.copyTo(os) }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "দোকানের স্টক CSV")
                putExtra(Intent.EXTRA_TEXT, "স্টকের পূর্ণাঙ্গ তালিকা (CSV)")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "স্টক CSV ফাইল শেয়ার"))

            Toast.makeText(context, if (isEnglish) "Download complete! Stock CSV saved." else "স্টক তালিকা CSV ডাউনলোড সম্পন্ন হয়েছে!", Toast.LENGTH_SHORT).show()
            NotificationHelper.sendExportCompleteNotification(context, if (isEnglish) "Inventory Stock (CSV)" else "স্টক তালিকা (CSV)", isEnglish)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "CSV তৈরিতে ত্রুটি: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Offline Database Backup Exporter (JSON)
     */
    fun exportOfflineDatabaseJson(
        context: Context,
        backupData: OfflineBackupData,
        isEnglish: Boolean = false,
        onFileGenerated: ((File) -> Unit)? = null
    ) {
        try {
            val jsonBuilder = StringBuilder()
            val timeStamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            val fileStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())

            jsonBuilder.append("{\n")
            jsonBuilder.append("  \"app\": \"Digi Dhukan\",\n")
            jsonBuilder.append("  \"backup_timestamp\": \"$timeStamp\",\n")
            jsonBuilder.append("  \"store_profile\": {\n")
            jsonBuilder.append("    \"shopName\": \"${backupData.profile.shopName}\",\n")
            jsonBuilder.append("    \"bossName\": \"${backupData.profile.bossName}\",\n")
            jsonBuilder.append("    \"phone\": \"${backupData.profile.phone}\",\n")
            jsonBuilder.append("    \"email\": \"${backupData.profile.email}\",\n")
            jsonBuilder.append("    \"userUid\": \"${backupData.profile.userUid}\",\n")
            jsonBuilder.append("    \"address\": \"${backupData.profile.address}\"\n")
            jsonBuilder.append("  },\n")

            // Products
            jsonBuilder.append("  \"products\": [\n")
            backupData.products.forEachIndexed { i, p ->
                jsonBuilder.append("    {\"id\": ${p.id}, \"barcode\": \"${p.barcode}\", \"name\": \"${p.name.replace("\"", "\\\"")}\", \"stock\": ${p.stock}, \"lastAddedQty\": ${p.lastAddedQty}, \"buyPrice\": ${p.buyPrice}, \"sellPrice\": ${p.sellPrice}, \"category\": \"${p.category}\"}")
                if (i < backupData.products.size - 1) jsonBuilder.append(",")
                jsonBuilder.append("\n")
            }
            jsonBuilder.append("  ],\n")

            // Dues
            jsonBuilder.append("  \"dues\": [\n")
            backupData.dues.forEachIndexed { i, d ->
                jsonBuilder.append("    {\"id\": ${d.id}, \"name\": \"${d.customerName.replace("\"", "\\\"")}\", \"phone\": \"${d.phone}\", \"amount\": ${d.amount}, \"date\": \"${d.date}\", \"note\": \"${d.note.replace("\"", "\\\"")}\"}")
                if (i < backupData.dues.size - 1) jsonBuilder.append(",")
                jsonBuilder.append("\n")
            }
            jsonBuilder.append("  ],\n")

            // Memos
            jsonBuilder.append("  \"memos\": [\n")
            backupData.memos.forEachIndexed { i, m ->
                jsonBuilder.append("    {\"id\": ${m.id}, \"supplier\": \"${m.supplierName.replace("\"", "\\\"")}\", \"memoNo\": \"${m.memoNo}\", \"amount\": ${m.amount}, \"date\": \"${m.date}\"}")
                if (i < backupData.memos.size - 1) jsonBuilder.append(",")
                jsonBuilder.append("\n")
            }
            jsonBuilder.append("  ],\n")

            // Transactions
            jsonBuilder.append("  \"transactions\": [\n")
            backupData.transactions.forEachIndexed { i, t ->
                jsonBuilder.append("    {\"id\": ${t.id}, \"total\": ${t.totalAmount}, \"profit\": ${t.totalProfit}, \"date\": \"${t.dateFormatted}\"}")
                if (i < backupData.transactions.size - 1) jsonBuilder.append(",")
                jsonBuilder.append("\n")
            }
            jsonBuilder.append("  ]\n")
            jsonBuilder.append("}")

            val fileName = "DigiDhukan_Backup_${fileStamp}.json"
            val file = File(context.cacheDir, fileName)
            file.writeText(jsonBuilder.toString(), Charsets.UTF_8)

            onFileGenerated?.invoke(file)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    val contentValues = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                        put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/DigiDhukan")
                    }
                    val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                    if (uri != null) {
                        context.contentResolver.openOutputStream(uri)?.use { os ->
                            file.inputStream().use { input -> input.copyTo(os) }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "দোকানের ডাটা ব্যাকআপ (JSON)")
                putExtra(Intent.EXTRA_TEXT, "ডিজি দোকান এর সম্পূর্ণ ডাটাবেজ ব্যাকআপ (JSON)")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "ডাটা ব্যাকআপ JSON শেয়ার"))

            Toast.makeText(context, if (isEnglish) "Download complete! Offline backup saved." else "অফলাইন ডাটা ব্যাকআপ (JSON) সফলভাবে সংরক্ষিত হয়েছে!", Toast.LENGTH_LONG).show()
            NotificationHelper.sendExportCompleteNotification(context, if (isEnglish) "Offline Database Backup (JSON)" else "অফলাইন ডাটা ব্যাকআপ (JSON)", isEnglish)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "ত্রুটি: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadSampledBitmapFromUri(context: Context, uriString: String, reqWidth: Int, reqHeight: Int): Bitmap? {
        if (uriString.isBlank()) return null
        return try {
            val uri = Uri.parse(uriString)
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeStream(stream, null, options)
                var inSampleSize = 1
                if (options.outHeight > reqHeight || options.outWidth > reqWidth) {
                    val halfHeight = options.outHeight / 2
                    val halfWidth = options.outWidth / 2
                    while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                        inSampleSize *= 2
                    }
                }
                val decodeOptions = BitmapFactory.Options().apply {
                    this.inSampleSize = inSampleSize
                    inPreferredConfig = Bitmap.Config.RGB_565
                }
                context.contentResolver.openInputStream(uri)?.use { stream2 ->
                    BitmapFactory.decodeStream(stream2, null, decodeOptions)
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    fun generateReceiptPdf(context: Context, receipt: ReceiptData, isEnglish: Boolean = false) {
        try {
            val pdfDocument = PdfDocument()
            val pageWidth = 400
            val itemHeight = 24
            val baseHeight = 440
            val pageHeight = baseHeight + (receipt.items.size * itemHeight)

            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            val paint = Paint().apply { isAntiAlias = true }
            val boldPaint = Paint().apply {
                isAntiAlias = true
                typeface = Typeface.DEFAULT_BOLD
            }

            paint.color = Color.parseColor("#E91E63")
            canvas.drawRect(0f, 0f, pageWidth.toFloat(), 60f, paint)

            boldPaint.color = Color.WHITE
            boldPaint.textSize = 16f
            canvas.drawText(receipt.shopName.ifBlank { "Digi Dhukan" }, 20f, 28f, boldPaint)

            paint.color = Color.WHITE
            paint.textSize = 9.5f
            canvas.drawText(receipt.address, 20f, 44f, paint)

            var y = 84f
            boldPaint.color = Color.parseColor("#1E293B")
            boldPaint.textSize = 13f
            canvas.drawText("বিক্রয় চালান (Cash Memo)", 20f, y, boldPaint)

            paint.color = Color.GRAY
            paint.textSize = 9.5f
            canvas.drawText("তারিখ: ${receipt.dateFormatted}", 20f, y + 18f, paint)
            if (receipt.customerPhone.isNotBlank()) {
                canvas.drawText("কাস্টমার: ${receipt.customerPhone}", 220f, y + 18f, paint)
            }

            y += 36f
            paint.color = Color.parseColor("#F1F5F9")
            canvas.drawRect(20f, y, pageWidth - 20f, y + 24f, paint)
            boldPaint.color = Color.parseColor("#334155")
            boldPaint.textSize = 10f
            canvas.drawText("পণ্যের নাম", 26f, y + 16f, boldPaint)
            canvas.drawText("পরিমাণ", 220f, y + 16f, boldPaint)
            canvas.drawText("মূল্য (৳)", 310f, y + 16f, boldPaint)

            y += 24f
            paint.color = Color.parseColor("#1E293B")
            paint.textSize = 9.5f

            receipt.items.forEachIndexed { i, item ->
                if (i % 2 == 1) {
                    val rowBg = Paint().apply { color = Color.parseColor("#FAFAFA") }
                    canvas.drawRect(20f, y, pageWidth - 20f, y + 22f, rowBg)
                }
                canvas.drawText(item.product.name.take(24), 26f, y + 15f, paint)
                canvas.drawText("${item.quantity}", 230f, y + 15f, paint)
                boldPaint.color = Color.parseColor("#2E7D32")
                canvas.drawText("৳ ${item.totalCost.toInt()}", 310f, y + 15f, boldPaint)

                val linePaint = Paint().apply {
                    color = Color.parseColor("#E2E8F0")
                    strokeWidth = 0.5f
                }
                canvas.drawLine(20f, y + 22f, pageWidth - 20f, y + 22f, linePaint)
                y += 22f
            }

            y += 14f
            paint.color = Color.parseColor("#E8F5E9")
            canvas.drawRoundRect(20f, y, pageWidth - 20f, y + 36f, 6f, 6f, paint)

            boldPaint.color = Color.parseColor("#1B5E20")
            boldPaint.textSize = 13f
            canvas.drawText("সর্বমোট বিল:", 32f, y + 24f, boldPaint)
            canvas.drawText("৳ ${receipt.totalAmount.toInt()}", 290f, y + 24f, boldPaint)

            y += 50f
            val barcodeBitmap = BarcodeUtil.generateBarcodeBitmap("RCPT-${System.currentTimeMillis() % 1000000}", width = 320, height = 55)
            if (barcodeBitmap != null) {
                canvas.drawBitmap(barcodeBitmap, 40f, y, null)
                barcodeBitmap.recycle()
            }

            y += 75f
            paint.color = Color.GRAY
            paint.textSize = 9f
            canvas.drawText("ধন্যবাদ! আবার আসবেন।", 130f, y, paint)

            pdfDocument.finishPage(page)

            val dir = File(context.cacheDir, "receipt_pdfs").apply { mkdirs() }
            val fileName = "Cash_Memo_${System.currentTimeMillis()}.pdf"
            val file = File(dir, fileName)
            FileOutputStream(file).use { pdfDocument.writeTo(it) }
            pdfDocument.close()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    val contentValues = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                        put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/DigiDhukan")
                    }
                    val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                    if (uri != null) {
                        context.contentResolver.openOutputStream(uri)?.use { os ->
                            file.inputStream().use { input -> input.copyTo(os) }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "ক্যাশ মেমো - ${receipt.shopName}")
                putExtra(Intent.EXTRA_TEXT, "${receipt.shopName} এর বিক্রয় রশিদ (PDF) - মোট বিল: ৳${receipt.totalAmount.toInt()}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "ক্যাশ মেমো (PDF) শেয়ার"))

            Toast.makeText(context, if (isEnglish) "Download complete! PDF saved." else "ক্যাশ মেমো PDF তৈরি হয়েছে!", Toast.LENGTH_SHORT).show()
            NotificationHelper.sendExportCompleteNotification(context, if (isEnglish) "Cash Memo Receipt (PDF)" else "ক্যাশ মেমো রসিদ (PDF)", isEnglish)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "PDF তৈরিতে সমস্যা: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun generateAllMemosPdf(
        context: Context,
        storeProfile: StoreProfile,
        memos: List<SupplierMemo>,
        isEnglish: Boolean = false
    ) {
        try {
            val pdfDocument = PdfDocument()
            val pageWidth = 595
            val pageHeight = 842
            var pageNumber = 1

            var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            var page = pdfDocument.startPage(pageInfo)
            var canvas = page.canvas

            val paint = Paint().apply { isAntiAlias = true }
            val boldPaint = Paint().apply {
                isAntiAlias = true
                typeface = Typeface.DEFAULT_BOLD
            }

            paint.color = Color.parseColor("#1976D2")
            canvas.drawRect(0f, 0f, pageWidth.toFloat(), 65f, paint)

            boldPaint.color = Color.WHITE
            boldPaint.textSize = 18f
            canvas.drawText(storeProfile.shopName.ifBlank { "Digi Dhukan" }, 24f, 32f, boldPaint)

            paint.color = Color.WHITE
            paint.textSize = 10f
            val subText = listOfNotNull(
                storeProfile.address.takeIf { it.isNotBlank() },
                storeProfile.phone.takeIf { it.isNotBlank() }?.let { "মোবাইল: $it" }
            ).joinToString(" | ")
            canvas.drawText(subText.ifBlank { "পাইকারি মেমো তালিকা" }, 24f, 50f, paint)

            var y = 90f
            boldPaint.color = Color.parseColor("#1E293B")
            boldPaint.textSize = 14f
            val title = if (isEnglish) "Wholesale Supplier Memos Report" else "মহাজন পাইকারি ক্রয় মেমো তালিকা"
            canvas.drawText(title, 24f, y, boldPaint)

            paint.color = Color.GRAY
            paint.textSize = 9.5f
            val printDate = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date())
            canvas.drawText("তারিখ: $printDate", pageWidth - 160f, y, paint)

            y += 18f
            paint.color = Color.parseColor("#F1F5F9")
            canvas.drawRoundRect(20f, y, pageWidth - 20f, y + 44f, 6f, 6f, paint)

            val totalAmount = memos.sumOf { it.amount }
            boldPaint.textSize = 11f
            boldPaint.color = Color.parseColor("#0F172A")
            canvas.drawText(if (isEnglish) "Total Memos: ${memos.size}" else "মোট মেমো: ${memos.size} টি", 32f, y + 26f, boldPaint)

            boldPaint.color = Color.parseColor("#1976D2")
            canvas.drawText(if (isEnglish) "Total Purchase:  ৳ ${totalAmount.toInt()}" else "মোট ক্রয়: ৳ ${totalAmount.toInt()}", 250f, y + 26f, boldPaint)

            y += 60f
            paint.color = Color.parseColor("#1976D2")
            canvas.drawRect(20f, y, pageWidth - 20f, y + 24f, paint)
            boldPaint.color = Color.WHITE
            boldPaint.textSize = 9.5f
            canvas.drawText("ক্রম", 26f, y + 16f, boldPaint)
            canvas.drawText("তারিখ", 55f, y + 16f, boldPaint)
            canvas.drawText("কোম্পানি / মহাজন", 145f, y + 16f, boldPaint)
            canvas.drawText("মেমো নং", 275f, y + 16f, boldPaint)
            canvas.drawText("বিবরণ", 355f, y + 16f, boldPaint)
            canvas.drawText("বিল (টাকা)", 500f, y + 16f, boldPaint)

            y += 24f
            paint.color = Color.parseColor("#1E293B")
            paint.textSize = 9f

            memos.forEachIndexed { index, memo ->
                if (y > pageHeight - 50) {
                    pdfDocument.finishPage(page)
                    pageNumber++
                    pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                    page = pdfDocument.startPage(pageInfo)
                    canvas = page.canvas
                    y = 40f
                }

                if (index % 2 == 1) {
                    val bgPaint = Paint().apply { color = Color.parseColor("#F8FAFC") }
                    canvas.drawRect(20f, y, pageWidth - 20f, y + 22f, bgPaint)
                }

                paint.color = Color.DKGRAY
                canvas.drawText("${index + 1}", 26f, y + 15f, paint)
                canvas.drawText(memo.date.take(12), 55f, y + 15f, paint)
                canvas.drawText(memo.supplierName.take(18), 145f, y + 15f, paint)
                canvas.drawText("#${memo.memoNo.take(12)}", 275f, y + 15f, paint)
                canvas.drawText(memo.note.ifBlank { "-" }.take(22), 355f, y + 15f, paint)

                boldPaint.color = Color.parseColor("#1976D2")
                boldPaint.textSize = 9.5f
                canvas.drawText("৳ ${memo.amount.toInt()}", 500f, y + 15f, boldPaint)

                val linePaint = Paint().apply {
                    color = Color.parseColor("#E2E8F0")
                    strokeWidth = 0.5f
                }
                canvas.drawLine(20f, y + 22f, pageWidth - 20f, y + 22f, linePaint)
                y += 22f
            }

            paint.color = Color.GRAY
            paint.textSize = 8.5f
            canvas.drawText("Digi Dhukan - Smart POS & Inventory Management System", 24f, pageHeight - 20f, paint)

            pdfDocument.finishPage(page)

            val dir = File(context.cacheDir, "pdf_reports").apply { mkdirs() }
            val fileName = "All_Memos_Report_${System.currentTimeMillis()}.pdf"
            val file = File(dir, fileName)
            FileOutputStream(file).use { pdfDocument.writeTo(it) }
            pdfDocument.close()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    val contentValues = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                        put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/DigiDhukan")
                    }
                    val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                    if (uri != null) {
                        context.contentResolver.openOutputStream(uri)?.use { os ->
                            file.inputStream().use { input -> input.copyTo(os) }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "মেমো তালিকা - ${storeProfile.shopName}")
                putExtra(Intent.EXTRA_TEXT, "${storeProfile.shopName} এর সকল মেমোর তালিকা (PDF)")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "মেমো রিপোর্ট (PDF) শেয়ার"))

            Toast.makeText(context, if (isEnglish) "Download complete! PDF saved." else "মেমো রিপোর্ট PDF তৈরি হয়েছে!", Toast.LENGTH_SHORT).show()
            NotificationHelper.sendExportCompleteNotification(context, if (isEnglish) "All Memos Report (PDF)" else "মেমো রিপোর্ট (PDF)", isEnglish)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "PDF তৈরিতে সমস্যা: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }
}
