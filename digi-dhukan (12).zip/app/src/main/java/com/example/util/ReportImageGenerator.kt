package com.example.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.CustomerDue
import com.example.data.Product
import com.example.data.SaleTransaction
import com.example.data.StoreProfile
import com.example.data.SupplierMemo
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ReportImageGenerator {

    /**
     * Generates a high-resolution, full-page JPG image of the sales and store account report.
     */
    fun generateReportBitmap(
        storeProfile: StoreProfile,
        transactions: List<SaleTransaction>,
        dues: List<CustomerDue>,
        memos: List<SupplierMemo>,
        products: List<Product>,
        isEnglish: Boolean = false,
        reportTitle: String = if (isEnglish) "1-Month Sales & Store Account Report" else "১ মাসের পূর্ণাঙ্গ বিক্রয় ও দোকান হিসাব রিপোর্ট",
        startDate: String = "",
        endDate: String = ""
    ): Bitmap {
        val width = 900
        val headerHeight = 220
        val kpiHeight = 160
        val txnItemHeight = 44
        val dueItemHeight = 38
        val maxTxnCount = minOf(transactions.size, 20)
        val maxDueCount = minOf(dues.size, 15)
        val txnsTotalHeight = 60 + (maxTxnCount * txnItemHeight)
        val duesTotalHeight = 60 + (maxDueCount * dueItemHeight)
        val footerHeight = 120
        val totalHeight = headerHeight + kpiHeight + txnsTotalHeight + duesTotalHeight + footerHeight

        val bitmap = Bitmap.createBitmap(width, totalHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val paint = Paint().apply { isAntiAlias = true }
        val boldPaint = Paint().apply {
            isAntiAlias = true
            typeface = Typeface.DEFAULT_BOLD
        }

        // 1. Header Banner
        paint.color = Color.parseColor("#E2136E")
        canvas.drawRect(0f, 0f, width.toFloat(), headerHeight.toFloat(), paint)

        boldPaint.color = Color.WHITE
        boldPaint.textSize = 34f
        canvas.drawText(storeProfile.shopName.ifBlank { "Digi Dhukan" }, 40f, 60f, boldPaint)

        paint.color = Color.WHITE
        paint.textSize = 17f
        val addressLine = buildString {
            if (storeProfile.address.isNotBlank()) append("${storeProfile.address}  |  ")
            if (storeProfile.phone.isNotBlank()) append("মোবাইল: ${storeProfile.phone}  |  ")
            if (storeProfile.bossName.isNotBlank()) append("স্বত্বাধিকারী: ${storeProfile.bossName}")
        }.ifBlank { "ডিজিটাল দোকান ও পিওএস সিস্টেম" }
        canvas.drawText(addressLine, 40f, 96f, paint)

        boldPaint.textSize = 21f
        val periodText = if (startDate.isNotBlank() && endDate.isNotBlank()) {
            "$reportTitle ($startDate থেকে $endDate)"
        } else if (startDate.isNotBlank()) {
            "$reportTitle ($startDate)"
        } else {
            reportTitle
        }
        canvas.drawText(periodText, 40f, 138f, boldPaint)

        val dateStr = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date())
        paint.textSize = 14f
        canvas.drawText(if (isEnglish) "Generated: $dateStr" else "রিপোর্ট তৈরির সময়: $dateStr", 40f, 172f, paint)

        var y = headerHeight.toFloat() + 30f

        // 2. KPI Summary Boxes
        val totalSales = transactions.sumOf { it.totalAmount }
        val totalProfit = transactions.sumOf { it.totalProfit }
        val totalDue = dues.sumOf { it.amount }
        val totalPurchase = memos.sumOf { it.amount }

        paint.color = Color.parseColor("#F8FAFC")
        canvas.drawRoundRect(30f, y, (width - 30).toFloat(), y + 100f, 16f, 16f, paint)

        val colW = (width - 80) / 4f

        fun drawKpi(index: Int, label: String, amount: Double, colorHex: String) {
            val startX = 45f + (index * colW)
            paint.color = Color.parseColor(colorHex)
            paint.textSize = 15f
            canvas.drawText(label, startX, y + 36f, paint)
            boldPaint.color = Color.parseColor(colorHex)
            boldPaint.textSize = 24f
            canvas.drawText("৳ ${amount.toInt()}", startX, y + 74f, boldPaint)
        }

        drawKpi(0, if (isEnglish) "TOTAL SALES" else "মোট বিক্রি", totalSales, "#E2136E")
        drawKpi(1, if (isEnglish) "NET PROFIT" else "নিট লাভ", totalProfit, "#15803D")
        drawKpi(2, if (isEnglish) "TOTAL DUES" else "মোট বাকি", totalDue, "#B91C1C")
        drawKpi(3, if (isEnglish) "WHOLESALE" else "পাইকারি ক্রয়", totalPurchase, "#1D4ED8")

        y += 135f

        // 3. Transactions Section
        boldPaint.color = Color.parseColor("#0F172A")
        boldPaint.textSize = 19f
        canvas.drawText(
            if (isEnglish) "Sales Transactions & Invoices (${transactions.size})" else "বিক্রয় চালান ও ক্যাশ মেমো (${transactions.size} টি)",
            35f,
            y,
            boldPaint
        )
        y += 18f

        // Table Header
        paint.color = Color.parseColor("#E2E8F0")
        canvas.drawRect(30f, y, (width - 30).toFloat(), y + 32f, paint)
        boldPaint.color = Color.parseColor("#1E293B")
        boldPaint.textSize = 14f
        canvas.drawText("#", 45f, y + 22f, boldPaint)
        canvas.drawText(if (isEnglish) "Date & Time" else "তারিখ ও সময়", 90f, y + 22f, boldPaint)
        canvas.drawText(if (isEnglish) "Purchased Items" else "বিক্রিত পণ্যের তালিকা", 280f, y + 22f, boldPaint)
        canvas.drawText(if (isEnglish) "Total Bill" else "মোট বিল", 670f, y + 22f, boldPaint)
        canvas.drawText(if (isEnglish) "Profit" else "লাভ", 790f, y + 22f, boldPaint)

        y += 40f
        val linePaint = Paint().apply { color = Color.parseColor("#F8FAFC") }
        paint.color = Color.parseColor("#334155")
        paint.textSize = 13.5f

        transactions.take(maxTxnCount).forEachIndexed { i, txn ->
            if (i % 2 == 0) {
                canvas.drawRect(30f, y - 6f, (width - 30).toFloat(), y + 28f, linePaint)
            }
            canvas.drawText("${i + 1}", 45f, y + 16f, paint)
            canvas.drawText(txn.dateFormatted, 90f, y + 16f, paint)
            val summary = txn.itemsSummary.replace("\n", ", ").take(50)
            canvas.drawText(summary, 280f, y + 16f, paint)
            canvas.drawText("৳ ${txn.totalAmount.toInt()}", 670f, y + 16f, paint)
            boldPaint.color = Color.parseColor("#16A34A")
            boldPaint.textSize = 13.5f
            canvas.drawText("৳ ${txn.totalProfit.toInt()}", 790f, y + 16f, boldPaint)
            y += txnItemHeight
        }

        y += 24f

        // 4. Customer Due Ledger Section
        boldPaint.color = Color.parseColor("#0F172A")
        boldPaint.textSize = 19f
        canvas.drawText(
            if (isEnglish) "Customer Due Ledger Summary (${dues.size})" else "কাস্টমার বাকি খাতা বিবরণী (${dues.size} জন)",
            35f,
            y,
            boldPaint
        )
        y += 18f

        paint.color = Color.parseColor("#FEE2E2")
        canvas.drawRect(30f, y, (width - 30).toFloat(), y + 32f, paint)
        boldPaint.color = Color.parseColor("#991B1B")
        boldPaint.textSize = 14f
        canvas.drawText(if (isEnglish) "Customer Name" else "কাস্টমারের নাম", 45f, y + 22f, boldPaint)
        canvas.drawText(if (isEnglish) "Phone" else "মোবাইল নম্বর", 280f, y + 22f, boldPaint)
        canvas.drawText(if (isEnglish) "Note / Items" else "পণ্যের বিবরণ", 460f, y + 22f, boldPaint)
        canvas.drawText(if (isEnglish) "Outstanding Due" else "বাকি পরিমাণ", 740f, y + 22f, boldPaint)

        y += 40f
        paint.color = Color.parseColor("#1F2937")
        paint.textSize = 13.5f

        dues.take(maxDueCount).forEachIndexed { i, due ->
            if (i % 2 == 0) {
                canvas.drawRect(30f, y - 6f, (width - 30).toFloat(), y + 24f, linePaint)
            }
            canvas.drawText(due.customerName, 45f, y + 14f, paint)
            canvas.drawText(due.phone, 280f, y + 14f, paint)
            canvas.drawText(due.note.take(38), 460f, y + 14f, paint)
            boldPaint.color = Color.parseColor("#DC2626")
            boldPaint.textSize = 14f
            canvas.drawText("৳ ${due.amount.toInt()}", 740f, y + 14f, boldPaint)
            y += dueItemHeight
        }

        y += 35f

        // 5. Footer Sign-off
        paint.color = Color.parseColor("#E2136E")
        paint.strokeWidth = 2f
        canvas.drawLine(40f, y, (width - 40).toFloat(), y, paint)

        y += 30f
        paint.color = Color.GRAY
        paint.textSize = 13f
        val signOff = if (storeProfile.bossName.isNotBlank()) {
            "ডিজি দোকান (Digi Dhukan) স্বত্বাধিকারী: ${storeProfile.bossName} | মোবাইল: ${storeProfile.phone}"
        } else {
            "ডিজি দোকান (Digi Dhukan) - ডিজিটাল পিওএস ও ইনভেন্টরি ম্যানেজমেন্ট"
        }
        canvas.drawText(signOff, 40f, y, paint)

        return bitmap
    }

    fun saveAndShareReportJpg(
        context: Context,
        storeProfile: StoreProfile,
        transactions: List<SaleTransaction>,
        dues: List<CustomerDue>,
        memos: List<SupplierMemo>,
        products: List<Product>,
        isEnglish: Boolean = false,
        reportTitle: String = if (isEnglish) "1-Month Sales & Store Account Report" else "১ মাসের পূর্ণাঙ্গ বিক্রয় ও দোকান হিসাব রিপোর্ট",
        startDate: String = "",
        endDate: String = ""
    ) {
        try {
            val bitmap = generateReportBitmap(
                storeProfile = storeProfile,
                transactions = transactions,
                dues = dues,
                memos = memos,
                products = products,
                isEnglish = isEnglish,
                reportTitle = reportTitle,
                startDate = startDate,
                endDate = endDate
            )
            val fileName = "DigiDhukan_Report_${System.currentTimeMillis()}.jpg"
            var uri: Uri? = null

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/DigiDhukan_Reports")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { stream ->
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
                    }
                    contentValues.clear()
                    contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, contentValues, null, null)
                }
            } else {
                val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                val appDir = File(picturesDir, "DigiDhukan_Reports").apply { mkdirs() }
                val imageFile = File(appDir, fileName)
                FileOutputStream(imageFile).use { stream ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
                }
                uri = Uri.fromFile(imageFile)
                val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE).apply {
                    data = uri
                }
                context.sendBroadcast(mediaScanIntent)
            }

            val cacheDir = File(context.cacheDir, "reports").apply { mkdirs() }
            val shareFile = File(cacheDir, "share_report_${System.currentTimeMillis()}.jpg")
            FileOutputStream(shareFile).use { stream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
            }
            val shareUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", shareFile)

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, shareUri)
                putExtra(Intent.EXTRA_SUBJECT, "$reportTitle - ${storeProfile.shopName}")
                putExtra(Intent.EXTRA_TEXT, "${storeProfile.shopName} এর সম্পূর্ণ হিসাব রিপোর্ট (JPG)")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "রিপোর্ট শেয়ার করুন (JPG)"))

            Toast.makeText(context, "দোকানের পূর্ণাঙ্গ রিপোর্ট JPG সফলভাবে ডাউনলোড হয়েছে!", Toast.LENGTH_LONG).show()
            NotificationHelper.sendExportCompleteNotification(context, if (isEnglish) "Monthly Summary Report (JPG)" else "মাসিক সারাংশ রিপোর্ট (JPG)", isEnglish)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "JPG তৈরিতে সমস্যা: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    fun saveAllMemosJpg(
        context: Context,
        storeProfile: StoreProfile,
        memos: List<SupplierMemo>,
        isEnglish: Boolean = false
    ) {
        try {
            val width = 900
            val headerHeight = 180
            val summaryHeight = 120
            val itemHeight = 48
            val footerHeight = 100
            val totalHeight = headerHeight + summaryHeight + (memos.size * itemHeight).coerceAtLeast(100) + footerHeight

            val bitmap = Bitmap.createBitmap(width, totalHeight, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.WHITE)

            val paint = Paint().apply { isAntiAlias = true }
            val boldPaint = Paint().apply {
                isAntiAlias = true
                typeface = Typeface.DEFAULT_BOLD
            }

            paint.color = Color.parseColor("#1976D2")
            canvas.drawRect(0f, 0f, width.toFloat(), 130f, paint)

            boldPaint.color = Color.WHITE
            boldPaint.textSize = 34f
            canvas.drawText(storeProfile.shopName.ifBlank { "Digi Dhukan" }, 40f, 60f, boldPaint)

            paint.color = Color.WHITE
            paint.textSize = 18f
            val subText = listOfNotNull(
                storeProfile.address.takeIf { it.isNotBlank() },
                storeProfile.phone.takeIf { it.isNotBlank() }?.let { "মোবাইল: $it" }
            ).joinToString(" | ")
            canvas.drawText(subText.ifBlank { "পাইকারি মেমো হিসাব" }, 40f, 96f, paint)

            var y = 165f
            boldPaint.color = Color.parseColor("#1E293B")
            boldPaint.textSize = 24f
            canvas.drawText(if (isEnglish) "Wholesale Purchase Memos Report" else "মহাজন পাইকারি ক্রয় মেমোর পূর্ণ তালিকা", 40f, y, boldPaint)

            paint.color = Color.GRAY
            paint.textSize = 16f
            val printDate = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date())
            canvas.drawText("তারিখ: $printDate", width - 260f, y, paint)

            y = 200f
            paint.color = Color.parseColor("#F1F5F9")
            canvas.drawRoundRect(40f, y, width - 40f, y + 80f, 16f, 16f, paint)

            val totalAmount = memos.sumOf { it.amount }
            boldPaint.color = Color.parseColor("#0F172A")
            boldPaint.textSize = 20f
            canvas.drawText(if (isEnglish) "Total Memos: ${memos.size}" else "মোট মেমো: ${memos.size} টি", 65f, y + 48f, boldPaint)

            boldPaint.color = Color.parseColor("#1976D2")
            boldPaint.textSize = 22f
            canvas.drawText(if (isEnglish) "Total Purchase:  ৳ ${totalAmount.toInt()}" else "মোট ক্রয়: ৳ ${totalAmount.toInt()}", 420f, y + 48f, boldPaint)

            y = 305f
            paint.color = Color.parseColor("#1976D2")
            canvas.drawRect(40f, y, width - 40f, y + 40f, paint)
            boldPaint.color = Color.WHITE
            boldPaint.textSize = 17f
            canvas.drawText("ক্রম", 55f, y + 26f, boldPaint)
            canvas.drawText("তারিখ", 110f, y + 26f, boldPaint)
            canvas.drawText("কোম্পানি / মহাজন", 250f, y + 26f, boldPaint)
            canvas.drawText("মেমো নং", 450f, y + 26f, boldPaint)
            canvas.drawText("বিবরণ", 580f, y + 26f, boldPaint)
            canvas.drawText("বিল (টাকা)", 760f, y + 26f, boldPaint)

            y += 40f
            paint.color = Color.DKGRAY
            paint.textSize = 16f

            memos.forEachIndexed { index, memo ->
                if (index % 2 == 1) {
                    val rowBg = Paint().apply { color = Color.parseColor("#F8FAFC") }
                    canvas.drawRect(40f, y, width - 40f, y + itemHeight.toFloat(), rowBg)
                }
                canvas.drawText("${index + 1}", 55f, y + 30f, paint)
                canvas.drawText(memo.date.take(12), 110f, y + 30f, paint)
                canvas.drawText(memo.supplierName.take(16), 250f, y + 30f, paint)
                canvas.drawText("#${memo.memoNo.take(10)}", 450f, y + 30f, paint)
                canvas.drawText(memo.note.ifBlank { "-" }.take(16), 580f, y + 30f, paint)

                boldPaint.color = Color.parseColor("#1976D2")
                boldPaint.textSize = 18f
                canvas.drawText("৳ ${memo.amount.toInt()}", 760f, y + 30f, boldPaint)

                val linePaint = Paint().apply {
                    color = Color.parseColor("#E2E8F0")
                    strokeWidth = 1f
                }
                canvas.drawLine(40f, y + itemHeight, width - 40f, y + itemHeight, linePaint)
                y += itemHeight
            }

            paint.color = Color.GRAY
            paint.textSize = 14f
            canvas.drawText("ডিজি দোকান - স্মার্ট পিওএস ও ইনভেন্টরি ম্যানেজমেন্ট সিস্টেম", 40f, totalHeight - 30f, paint)

            val fileName = "All_Memos_Report_${System.currentTimeMillis()}.jpg"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/DigiDhukan_Memos")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { stream ->
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
                    }
                    contentValues.clear()
                    contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, contentValues, null, null)
                }
            }

            val cacheDir = File(context.cacheDir, "reports").apply { mkdirs() }
            val shareFile = File(cacheDir, "memos_report_${System.currentTimeMillis()}.jpg")
            FileOutputStream(shareFile).use { stream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
            }
            val shareUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", shareFile)

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, shareUri)
                putExtra(Intent.EXTRA_SUBJECT, "মেমো রিপোর্ট (JPG) - ${storeProfile.shopName}")
                putExtra(Intent.EXTRA_TEXT, "${storeProfile.shopName} এর সকল পাইকারি মেমোর তালিকা (JPG)")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "মেমো রিপোর্ট (JPG)"))

            Toast.makeText(context, "সকল মেমোর JPG তালিকা ডাউনলোড হয়েছে!", Toast.LENGTH_LONG).show()
            NotificationHelper.sendExportCompleteNotification(context, "মেমো রিপোর্ট (JPG)", isEnglish)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "JPG তৈরিতে সমস্যা: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }
}
