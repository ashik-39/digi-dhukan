package com.example.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R

object NotificationHelper {
    const val CHANNEL_ID = "low_stock_alerts_channel"
    const val CHANNEL_NAME = "Digi Dhukan Alerts"

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts for low stock, sales, and exports"
                enableVibration(true)
            }
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun checkPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return false
            }
        }
        return true
    }

    // Low stock warning (stock <= 5) - REQUIREMENT 11: "পণ্য শেষের দিকে... X টি পণ্য stock এ আছে"
    fun sendLowStockNotification(
        context: Context,
        productName: String,
        currentStock: Int,
        isEnglish: Boolean = false
    ) {
        createNotificationChannel(context)
        if (!checkPermission(context)) return

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            productName.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (isEnglish) "⚠️ Low Stock Alert: $productName" else "⚠️ স্টক সতর্কতা: $productName"
        val message = if (currentStock <= 0) {
            if (isEnglish) "'$productName' is completely out of stock (0 left)!"
            else "'$productName' পণ্যটি স্টক আউট হয়ে গেছে!"
        } else {
            if (isEnglish) "Low Stock: Only $currentStock items left for '$productName'!"
            else "পণ্য শেষের দিকে... $currentStock টি পণ্য stock এ আছে ('$productName')"
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        try {
            val notificationManager = NotificationManagerCompat.from(context)
            notificationManager.notify((System.currentTimeMillis() % 100000).toInt(), notification)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun sendSaleNotification(
        context: Context,
        invoiceTitle: String,
        totalAmount: Double,
        itemCount: Int,
        isEnglish: Boolean = false
    ) {
        createNotificationChannel(context)
        if (!checkPermission(context)) return

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            ("sale" + System.currentTimeMillis()).hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (isEnglish) "🛍️ Sale Completed ($invoiceTitle)" else "🛍️ বিক্রয় সম্পন্ন হয়েছে"
        val message = if (isEnglish)
            "Total Amount: ৳${totalAmount.toInt()} ($itemCount items sold)"
        else
            "মোট বিল: ৳${totalAmount.toInt()} (বিক্রয়: $itemCount টি পণ্য)"

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        try {
            val notificationManager = NotificationManagerCompat.from(context)
            notificationManager.notify((System.currentTimeMillis() % 100000).toInt() + 10, notification)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun sendBuyNotification(
        context: Context,
        supplierName: String,
        memoNo: String,
        amount: Double,
        isEnglish: Boolean = false
    ) {
        createNotificationChannel(context)
        if (!checkPermission(context)) return

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            ("buy" + System.currentTimeMillis()).hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (isEnglish) "📦 Purchase / Memo Recorded" else "📦 পাইকারি মেমো সংরক্ষিত হয়েছে"
        val message = if (isEnglish)
            "Supplier: $supplierName, Memo #$memoNo - Total: ৳${amount.toInt()}"
        else
            "মহাজন: $supplierName, মেমো: #$memoNo, বিল: ৳${amount.toInt()}"

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        try {
            val notificationManager = NotificationManagerCompat.from(context)
            notificationManager.notify((System.currentTimeMillis() % 100000).toInt() + 20, notification)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun sendExportCompleteNotification(
        context: Context,
        reportName: String,
        isEnglish: Boolean = false
    ) {
        createNotificationChannel(context)
        if (!checkPermission(context)) return

        val title = if (isEnglish) "✅ Download Complete" else "✅ ডাউনলোড সম্পন্ন হয়েছে"
        val message = if (isEnglish)
            "'$reportName' has been exported and saved to device!"
        else
            "'$reportName' সফলভাবে ডিভাইসে সেভ হয়েছে!"

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        try {
            val notificationManager = NotificationManagerCompat.from(context)
            notificationManager.notify((System.currentTimeMillis() % 10000).toInt(), notification)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
